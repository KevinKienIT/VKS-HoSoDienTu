# Lenh OpenCode Tao Bo Dac Ta Tong The Theo Phase

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-25
Sua boi agent: Codex
Muc dich: Tao mot lenh tong duy nhat de dan OpenCode xu ly mot goi yeu cau lon ma khong quay lai hoi scope.
Nguon prompt: Yeu cau truc tiep cua nguoi dung ngay 2026-04-24

## Muc Luc

1. Cach dung
2. Lenh tong cho OpenCode
3. Nguon bat buoc phai doc
4. Bo dau ra bat buoc
5. Quy tac khong duoc hoi lai
6. Rang buoc cung
7. Dinh dang phan hoi bat buoc

## 1. Cach Dung

- Dang o trong OpenCode tai root project thi copy nguyen khoi `## 2. Lenh Tong Cho OpenCode`.
- Lenh nay duoc viet theo huong: docs first, khong code, khong hoi lai pham vi, khong day tai lieu vao `PhanMem`.
- Neu OpenCode van hoi lai scope, coi nhu model dang di sai huong; paste them `## 5. Quy Tac Khong Duoc Hoi Lai`.

## 2. Lenh Tong Cho OpenCode

Sao chep nguyen khoi lenh duoi day:

```text
Ban dang o root project cua he thong VKS ECMS offline cho kiem sat vien.

Ban dong thoi giu 6 vai tro:

1. Principal Product Architect
2. Senior Business Analyst
3. Information Architect
4. OCR + AI Pipeline Architect
5. Documentation Program Lead
6. UI/UX Structure Lead

Ban KHONG duoc tra loi bang cach hoi lai scope tong quat. Toan bo pham vi duoi day da duoc phe duyet day du, mac dinh, khong can xin xac nhan them:

- phase chia nho cho bo du an lon
- map so do thuoc tinh
- map giao dien chinh
- giao dien quan ly trang
- giao dien quan ly ho so
- giao dien quan ly khoi ho so
- giao dien doc text va hien thi
- giao dien quan ly tai khoan nguoi dung
- luong chuc nang end-to-end
- luong model doc file scan
- luong agent/AI danh gia do chinh xac, do hoan hao, review queue
- luong tach file
- luong ingest vao co so du lieu
- metadata cho tat ca ho so
- profile bi can day du, co luoc su, xet hoi, mind-map man hinh
- map lien ket giua file thong tin, doi tuong, su kien, vat chung, citation

Muc tieu cua ban KHONG phai code ngay. Muc tieu cua ban la tao ra mot bo tai lieu dac ta can bang, sau, chat, de doi UI/backend/data/AI scaffold ma khong lac huong.

Ban phai lam dung thu tu sau:

1. Doc tat ca nguon bat buoc.
2. Khong lang thang ca repo; chi doc cac file canonical trong `V2`.
3. Tao dung bo file dau ra bat buoc trong `V2/05_tai_lieu_mo_ta`.
4. Neu thong tin dau vao con thieu, khong duoc dung lai de hoi scope tong quat; thay vao do, ghi ro `THIEU_DAU_VAO` ben trong tung file lien quan va van phai tao cau truc day du.
5. Sau khi tao bo tai lieu mo ta, cap nhat map va nhat ky trong `V2/01_quy_trinh_agent_san_pham`.
6. Tuyet doi khong tao code, khong scaffold `PhanMem`, khong sua script runtime trong phien nay.
7. Neu trong qua trinh phan tich, AI de xuat code snippet, dependency/package, script install, URL download, endpoint, repo source hoac link la, phai luot soat nhanh de giam rui ro bao mat chuoi cung ung truoc khi giu lai trong tai lieu.

Moi file ban tao phai co:

- Muc dich
- Pham vi
- Doi tuong doc
- Dau vao
- Dau ra
- Dependency
- Sơ do ASCII neu can
- Bang truong du lieu / state / actor / event neu can
- Acceptance criteria
- Muc `Khong duoc hieu sai`

Ban phai giu cac quy tac nghiep vu sau:

- Offline first, Windows desktop first
- Citation bat buoc
- Audit trail bat buoc
- OCR review queue bat buoc
- Text viet tay/to loi khai bi can bat buoc phai duoc xu ly
- Moi `doan chu` / `noi suy text` chi duoc ton tai duoi dang suggestion co confidence va review, khong duoc silent merge
- `V2` la nguon docs/SOP/spec/log/report
- `PhanMem` chi danh cho code/runtime/build/test
- Luon kiem tra luot qua code do AI sinh ra; dac biet dependency/package, script install, URL, endpoint, repo source, CDN, va link la
- Neu co dau hieu bat thuong, danh dau `SUPPLY_CHAIN_REVIEW_REQUIRED` va khong im lang chap nhan

Ban phai tao chinh xac cac file sau trong `V2/05_tai_lieu_mo_ta`:

1. `20260424_13_ke_hoach_phan_ra_phase_va_gate_trien_khai.md`
2. `20260424_14_ban_do_thuoc_tinh_metadata_va_schema_nghiep_vu.md`
3. `20260424_15_ban_do_giao_dien_tong_the_va_dieu_huong_chinh.md`
4. `20260424_16_dac_ta_man_hinh_quan_ly_trang_va_viewer.md`
5. `20260424_17_dac_ta_man_hinh_quan_ly_ho_so_va_khoi_ho_so.md`
6. `20260424_18_dac_ta_man_hinh_doc_text_citation_va_review.md`
7. `20260424_19_dac_ta_quan_ly_tai_khoan_nguoi_dung_va_phan_quyen.md`
8. `20260424_20_ban_do_luong_chuc_nang_end_to_end.md`
9. `20260424_21_dac_ta_luong_scan_ocr_ai_danh_gia_chat_luong.md`
10. `20260424_22_dac_ta_tach_file_ingest_db_metadata.md`
11. `20260424_23_dac_ta_profile_bi_can_luoc_su_va_xet_hoi.md`
12. `20260424_24_ban_do_lien_ket_giua_file_thong_tin_thuc_the_su_kien.md`
13. `20260424_25_ban_do_tri_thuc_man_hinh_tom_tat_bi_can.md`

Tung file phai viet that sau, co bang, so do, luong actor, state, gate review, va map sang module hien co.

Sau khi tao xong bo file, cap nhat:

- `V2/01_quy_trinh_agent_san_pham/20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_03_nhat_ky_agent_v2.md`

Khong duoc tra loi bang "toi can xac dinh them pham vi". Pham vi da chot la FULL SCOPE DOCS-ONLY.
```

## 3. Nguon Bat Buoc Phai Doc

OpenCode phai doc toi thieu cac file sau truoc khi viet:

1. `V2/20260423_00_tong_quan_v2.md`
2. `V2/01_quy_trinh_agent_san_pham/20260423_04_quy_chuan_lam_viec_agent_v2.md`
3. `V2/01_quy_trinh_agent_san_pham/20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
4. `V2/01_quy_trinh_agent_san_pham/20260424_12_quy_trinh_aider_thuc_chien.md`
5. `V2/01_quy_trinh_agent_san_pham/20260423_08_dac_ta_mapping_du_lieu_ho_so.md`
6. `V2/01_quy_trinh_agent_san_pham/20260424_08_dac_ta_layered_architecture.md`
7. `V2/01_quy_trinh_agent_san_pham/20260424_09_dac_ta_json_schema_va_state_management.md`
8. `V2/01_quy_trinh_agent_san_pham/20260424_12_dac_ta_ocr_offline.md`
9. `V2/01_quy_trinh_agent_san_pham/20260424_15_dac_ta_component_api.md`
10. `V2/01_quy_trinh_agent_san_pham/20260424_16_dac_ta_ui_layout_wireframe.md`
11. `V2/05_tai_lieu_mo_ta/20260423_01_mo_ta_he_thong_tong_hop.md`
12. `V2/05_tai_lieu_mo_ta/20260424_03_ban_do_module_va_luong_du_lieu.md`
13. `V2/05_tai_lieu_mo_ta/20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md`
14. `V2/05_tai_lieu_mo_ta/20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md`
15. `V2/05_tai_lieu_mo_ta/20260424_08_dac_ta_audit_trail_va_manual_override.md`
16. `V2/05_tai_lieu_mo_ta/20260424_09_dac_ta_citation_anchor_va_ocr_revision.md`
17. `V2/05_tai_lieu_mo_ta/20260424_10_tu_dien_document_type_va_quy_tac_phan_loai.md`
18. `V2/05_tai_lieu_mo_ta/20260424_11_dac_ta_import_job_backup_restore.md`
19. `V2/05_tai_lieu_mo_ta/20260424_12_dac_ta_workspace_ho_tro_kiem_sat_vien.md`

## 4. Bo Dau Ra Bat Buoc

Bo dau ra nay duoc chia thanh 5 nhom:

### Nhom A - Pha va gate

- phase tong the
- docs gate
- review gate
- UI/backend/data/AI handoff gate

### Nhom B - Data va metadata

- attribute map
- schema nghiep vu
- metadata tong hop
- map lien ket file-page-entity-event-evidence-citation

### Nhom C - UI va man hinh

- main navigation
- case/workspace shell
- page management
- dossier/case block management
- text reader + citation + review
- user account + permission

### Nhom D - Pipeline scan/OCR/AI/DB

- split file
- OCR engine
- handwriting assist
- AI evaluation
- review queue
- ingest vao DB
- metadata extraction

### Nhom E - Ho so bi can va tri thuc nghiep vu

- suspect profile
- luoc su bi can
- xet hoi
- mind map man hinh
- graph lien ket giua nguoi, file, su kien, vat chung, but luc

## 5. Quy Tac Khong Duoc Hoi Lai

Neu OpenCode co xu huong hoi lai theo kieu:

- co lam tat ca khong?
- module nao uu tien?
- output la docs hay code?
- co tiep tuc voi 13 module khong?

thi paste them khoi lenh sau:

```text
Khong hoi lai pham vi tong quat.

Mac dinh cua phien nay da duoc chot nhu sau:

- Tat ca nhom module va man hinh da liet ke deu nam trong scope.
- Output cua phien nay chi la docs/spec/map/flow, khong phai code.
- Uu tien la tao bo tai lieu du de scaffold ve sau, khong phai chon bot module.
- Neu thieu dau vao cu the, ghi `THIEU_DAU_VAO` trong file lien quan roi tiep tuc, khong dung phien de xin xac nhan lai bai toan lon.

Bat dau lam viec ngay theo phase, khong hoi lai.
```

## 6. Rang Buoc Cung

- Khong viet marketing copy.
- Khong tra loi bang summary ngan.
- Khong bo qua citation, audit, OCR confidence, review queue.
- Khong bo qua text viet tay.
- Khong dat tai lieu vao `PhanMem`.
- Khong scaffold code trong phien prompt nay.
- Khong de xuat tinh nang khong map duoc ve nghiep vu KSV.
- Khong copy nguyen xi dependency/package/URL la do AI de xuat ma khong co sanity check ve chuoi cung ung.

## 7. Dinh Dang Phan Hoi Bat Buoc

OpenCode phai phan hoi theo khuon:

1. `SYSTEM UNDERSTANDING`
2. `PHASE PLAN`
3. `TARGET FILE SET`
4. `FILE-BY-FILE CREATION ORDER`
5. `THIEU_DAU_VAO`
6. `NEXT FILE TO WRITE`

Neu dang sua file, phai noi ro:

- dang tao file nao
- file do thuoc phase nao
- da dua vao map/log chua
