# Bo Lenh OpenCode Theo Phase

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-25
Sua boi agent: Codex
Muc dich: Cung cap cac lenh nho hon de dan OpenCode tao bo dac ta lon theo tung phase, tranh lac de va tranh hoi scope lai.
Nguon prompt: Yeu cau truc tiep cua nguoi dung ngay 2026-04-24

## Muc Luc

1. Cach dung
2. Phase 0
3. Phase 1
4. Phase 2
5. Phase 3
6. Phase 4
7. Phase 5
8. Lenh khoa chot cuoi

## 1. Cach Dung

- Neu muon danh theo tung dot nho trong OpenCode, paste tung phase theo thu tu.
- Khong bo qua `Phase 0`.
- Moi phase duoc viet theo huong docs-only.
- Neu trong bat ky phase nao AI de xuat code snippet, dependency/package, script install, URL, endpoint hoac link la, phai luot soat nhanh de phong ngua rui ro bao mat chuoi cung ung truoc khi giu lai.

## 2. Phase 0

```text
Phase 0 - Docs Lock Va Planning

Ban dang trong che do docs-only.

Nhiem vu:

1. Doc tat ca nguon canonical trong `V2` theo thu tu uu tien.
2. Khong tao code.
3. Tao file `V2/05_tai_lieu_mo_ta/20260424_13_ke_hoach_phan_ra_phase_va_gate_trien_khai.md`.
4. File nay phai chia toan bo bai toan thanh phase nho, owner role, dau vao, dau ra, gate review, gate handoff, done criteria.
5. File nay phai map ro phase nao lam docs, phase nao chuan bi scaffold, phase nao moi duoc vao `PhanMem`.
6. Them gate `SUPPLY_CHAIN_SANITY_CHECK` cho cac phase co de xuat code/dependency/URL.
7. Sau khi tao xong, cap nhat map va nhat ky.

Khong hoi lai scope. Toan bo scope da duoc chot.
```

## 3. Phase 1

```text
Phase 1 - Data, Metadata, Schema, Lien Ket

Nhiem vu:

1. Tao `20260424_14_ban_do_thuoc_tinh_metadata_va_schema_nghiep_vu.md`
2. Tao `20260424_21_dac_ta_luong_scan_ocr_ai_danh_gia_chat_luong.md`
3. Tao `20260424_22_dac_ta_tach_file_ingest_db_metadata.md`
4. Tao `20260424_24_ban_do_lien_ket_giua_file_thong_tin_thuc_the_su_kien.md`

Bat buoc trong cac file tren:

- map attribute case/document/page/entity/evidence/event/citation/user/work_product
- metadata tong hop cho tat ca ho so
- luong split file -> OCR -> handwriting assist -> AI evaluation -> review -> ingest DB
- cach danh gia do chinh xac, do hoan hao, khi nao pending review
- map giua file thong tin, but luc, thuc the, su kien, vat chung
- bang field, actor, state, gate

Khong scaffold code.
```

## 4. Phase 2

```text
Phase 2 - Main UI, Navigation, Case And Page Management

Nhiem vu:

1. Tao `20260424_15_ban_do_giao_dien_tong_the_va_dieu_huong_chinh.md`
2. Tao `20260424_16_dac_ta_man_hinh_quan_ly_trang_va_viewer.md`
3. Tao `20260424_17_dac_ta_man_hinh_quan_ly_ho_so_va_khoi_ho_so.md`
4. Tao `20260424_18_dac_ta_man_hinh_doc_text_citation_va_review.md`
5. Tao `20260424_19_dac_ta_quan_ly_tai_khoan_nguoi_dung_va_phan_quyen.md`

Bat buoc:

- main shell
- navigation
- dashboard/case list
- quan ly khoi ho so
- quan ly ho so chi tiet
- quan ly trang/page
- viewer
- OCR text panel
- citation/review panel
- user account + permission
- quick actions cho KSV
- keyboard flow, panel state, empty state, warning state

Phai co so do ASCII, bang state, bang action, bang actor.
```

## 5. Phase 3

```text
Phase 3 - Functional Flows

Nhiem vu:

1. Tao `20260424_20_ban_do_luong_chuc_nang_end_to_end.md`

File nay phai co:

- import case flow
- split/ocr/review flow
- search/sort/filter flow
- dossier/profile flow
- contradiction/timeline flow
- AI ask-and-cite flow
- user management flow
- audit/fix/report flow
- resume session flow

Moi flow phai chi ro:

- actor
- trigger
- input
- processing
- output
- review gate
- failure path
- recovery path
```

## 6. Phase 4

```text
Phase 4 - Suspect Profile, Luoc Su, Xet Hoi, Knowledge Map

Nhiem vu:

1. Tao `20260424_23_dac_ta_profile_bi_can_luoc_su_va_xet_hoi.md`
2. Tao `20260424_25_ban_do_tri_thuc_man_hinh_tom_tat_bi_can.md`

Bat buoc:

- profile bi can day du
- luoc su nhan than, hanh vi, tai lieu lien quan
- muc xet hoi / cau hoi / van de can lam ro
- map lien ket giua bi can va file/tai lieu/su kien/vat chung/loi khai
- man hinh tom tat nhanh de KSV nhin mot lan la nam
- mind map / knowledge panel / dossier graph

Phai viet theo huong hien thi duoc tren man hinh, khong chi la model data.
```

## 7. Phase 5

```text
Phase 5 - Consistency Pass Va Map Update

Nhiem vu:

1. Doc lai toan bo file da tao trong phase 0-4.
2. Kiem tra xem co trung lap, xung dot thuat ngu, xung dot field, xung dot state hay khong.
3. Cap nhat `V2/01_quy_trinh_agent_san_pham/20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
4. Cap nhat `V2/01_quy_trinh_agent_san_pham/20260423_03_nhat_ky_agent_v2.md`
5. Tong hop danh sach `THIEU_DAU_VAO` con lai.
6. Luot soat danh sach code snippet, dependency/package, script install, URL, endpoint hoac link la do AI de xuat; danh dau `SUPPLY_CHAIN_REVIEW_REQUIRED` neu co nghi van.

Khong viet code.
Khong scaffold `PhanMem`.
```

## 8. Lenh Khoa Chot Cuoi

Neu OpenCode bat dau di sai huong, paste:

```text
WRONG_DIRECTION_DETECTED

Dung ngay cong viec hien tai.
Quay lai docs canonical trong `V2`.
Khong hoi lai pham vi tong quat.
Khong nhay sang code.
Chi tiep tuc khi dang tao mot trong cac file output da duoc chot trong bo phase.
```
