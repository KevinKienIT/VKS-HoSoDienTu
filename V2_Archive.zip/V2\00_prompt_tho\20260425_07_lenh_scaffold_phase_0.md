# Lenh Scaffold Phase 0 — Project Setup

Ngay tao: 2026-04-25
Ngay cap nhat gan nhat: 2026-04-25
Sua boi agent: Antigravity
Muc dich: Prompt chinh thuc de agent thuc thi Phase 0 — khoi tao project Tauri + React + TypeScript trong PhanMem/.
Nguon prompt: Tong hop tu implementation checklist va build config spec.

---

## Lenh Cho Agent

```text
Ban dang thuc hien Phase 0 — Project Setup cho VKS ECMS.

Vai tro cua ban: agent_backend + agent_kien_truc.

KHONG doc lai toan bo 50 file spec. Chi doc 3 file sau:

1. `V2/04_case_dang_lam_viec/20260425_phase0_task_board.md` — task board Phase 0
2. `V2/01_quy_trinh_agent_san_pham/20260424_11_build_and_deployment_config.md` — spec build/deploy
3. `V2/01_quy_trinh_agent_san_pham/20260424_08_dac_ta_layered_architecture.md` — kien truc 4 lop

Muc tieu: Tao scaffold Tauri v2 + React + TypeScript trong `PhanMem/` sao cho `cargo tauri dev` chay thanh cong.

Thu tu thuc hien (lam tuan tu, khong nhay):

1. Kiem tra `PhanMem/` hien tai — chi co .gitkeep, chua co code.

2. Khoi tao Tauri v2 project:
   - Chay `npx -y create-tauri-app@latest` tai thu muc `PhanMem/`
   - Template: React + TypeScript + Vite
   - Identifier: `vn.vks.ecms`
   - Product name: `VKS ECMS`

3. Cau hinh package.json:
   - Them dependencies: zustand, react-router-dom, framer-motion
   - Them devDependencies: @types/react, @types/react-dom
   - Verify voi `npm install`

4. Cau hinh vite.config.ts:
   - Path alias: `@/` → `src/`
   - Server port: 1420

5. Cau hinh tsconfig.json:
   - strict: true
   - paths: { "@/*": ["./src/*"] }

6. Cau hinh Cargo.toml:
   - Them: tauri-plugin-sql (sqlite), tauri-plugin-log, tauri-plugin-dialog, tauri-plugin-fs, serde, serde_json

7. Cau hinh tauri.conf.json:
   - Window: title "VKS ECMS", width 1400, height 900, resizable true, center true
   - Security: khong cho navigate ra ngoai

8. Tao src-tauri/capabilities/main.json:
   - Allow: fs (scope app data), dialog (open/save), shell (open url)

9. Tao cau truc thu muc trong src/:
   - src/components/     (them index.ts)
   - src/constants/      (them index.ts)
   - src/hooks/          (them index.ts)
   - src/lib/            (them index.ts)
   - src/services/       (them index.ts)
   - src/store/          (them index.ts)
   - src/types/          (them index.ts)

10. Tao 1 dummy Zustand store trong src/store/uiStore.ts:
    - State: { sidebarOpen: boolean, theme: 'light' | 'dark' }
    - Actions: toggleSidebar, setTheme

11. Setup React Router trong src/App.tsx:
    - Route /: trang Dashboard (placeholder)
    - Route /settings: trang Settings (placeholder)

12. Verify:
    - `npm run dev` khong loi
    - `cargo tauri dev` mo window voi React content
    - Navigate giua / va /settings thanh cong

Sau khi xong:
- Cap nhat tung task trong `V2/04_case_dang_lam_viec/20260425_phase0_task_board.md` thanh DONE
- Cap nhat `V2/NEXT_ACTION.md` sang Phase 1, Task 1.1
- Ghi 1 entry vao `V2/01_quy_trinh_agent_san_pham/20260423_03_nhat_ky_agent_v2.md`

RANG BUOC:
- Khong tao code nghiep vu (case CRUD, OCR, AI). Day chi la scaffold.
- Khong sua file nao trong V2/ ngoai 3 file cap nhat o tren.
- Neu gap loi build, ghi bug vao `V2/03_bao_cao/01_bug/` truoc khi tiep tuc.
- Kiem tra nhanh moi dependency truoc khi install — khong chap nhan package la.
```

## Ghi Chu Su Dung

- Copy khoi lenh trong fence code tren va paste cho agent bat ky.
- Agent chi can doc 3 file (thay vi 50) de bat dau lam.
- Prompt nay la buoc chuyen tu docs-only sang code-first.
- Phase 0 xong thi docs gate cua Phase 1 tu dong mo.
