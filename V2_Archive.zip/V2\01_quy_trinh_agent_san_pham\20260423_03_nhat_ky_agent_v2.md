# Nhat Ky Agent V2

Ngay tao: 2026-04-23
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Ghi lai lich su can chinh, dua tai lieu sang V2 va cac quyet dinh van hanh lien quan.
Nguon prompt: `V2/00_prompt_tho/20260423_02_len_v2.md`

## Muc Luc

1. Mau ghi nhat ky
2. Nhat ky hien tai
3. Diem agent sau phai ton trong

## 1. Mau Ghi Nhat Ky

```text
Ngay gio:
Agent:
Da doc:
Da tao:
Da sao chep:
Ket luan:
Rui ro:
Can review:
```

## 2. Nhat Ky Hien Tai

### 2026-04-23 - Codex

Ngay gio: 2026-04-23
Agent: Codex
Da doc:

- `V1/00PromptTho/260423_LenV2.md`
- `V1/00PromptTho/260423_BuildMoTa.md`
- `V1/01_quy_trinh_agent_san_pham/20260423_04_quy_chuan_lam_viec_agent.md`
- `he_thong_quan_ly_ho_so.md`
- `V1/docs/architecture.md`
- `V1/docs/classification_rules.md`
- `V1/docs/user_guide.md`
- `V1/README.md`

Da tao:

- `V2/20260423_00_tong_quan_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_01_ke_hoach_chuyen_len_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_03_nhat_ky_agent_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_04_quy_chuan_lam_viec_agent_v2.md`
- `V2/02_quy_dinh_bug_test_fix/20260423_01_quy_dinh_check_bug_ghi_bug_test_fix.md`
- `V2/02_quy_dinh_bug_test_fix/20260423_02_mau_bao_cao_bug_test_fix.md`
- `V2/03_bao_cao/20260423_01_quy_dinh_bao_cao.md`
- `V2/04_case_dang_lam_viec/20260423_01_quy_dinh_case_dang_lam_viec.md`
- `V2/98_thung_rac/20260423_01_quy_dinh_thung_rac.md`

Da sao chep:

- Prompt tho tu `V1/00PromptTho` sang `V2/00_prompt_tho`
- Tai lieu mo ta, kien truc, quy tac, huong dan, setup dang tai lieu sang `V2/05_tai_lieu_mo_ta`

Ket luan:

- `V2` da duoc dinh nghia thanh khong gian lam viec tai lieu doc lap.
- Trong `V2`, agent phai tu doc dieu lenh va prompt tho truoc khi xu ly.
- `V2` khong chua code hoac runtime data.
- Da tao luong rieng cho bug, test, fix, report, case dang lam viec va thung rac.

Rui ro:

- Tai lieu tham chieu da sao chep tu V1 co noi dung lich su, khong phai moi file deu la lenh hien hanh.
- Neu agent bo qua `01_quy_trinh_agent_san_pham`, V2 se bi dung nhu kho tai lieu thu dong thay vi luong xu ly.

Can review:

- Xac nhan cach dua prompt tho moi vao `V2/00_prompt_tho`.
- Xac nhan co can tach them nhieu nhom bao cao chi tiet hon trong tuong lai khong.

### 2026-04-23 - Antigravity

Ngay gio: 2026-04-23
Agent: Antigravity
Da doc:

- Toan bo 21 file trong V2 (00 den 98)
- `he_thong_quan_ly_ho_so.md` (file goc ngoai V2)
- Tat ca 3 prompt tho trong `00_prompt_tho`
- Tat ca 6 file SOP trong `01_quy_trinh_agent_san_pham`
- Tat ca 3 file quy dinh trong `02_quy_dinh_bug_test_fix`
- Tat ca file quy dinh trong `03_bao_cao`, `04_case`, `98_thung_rac`
- Tat ca 5 file tai lieu tham chieu trong `05_tai_lieu_mo_ta`

Da tao:

- He quy chuan V2 (artifact phan tich)

Da cap nhat:

- `20260423_00_tong_quan_v2.md` → nang cap thanh entry-point chinh thuc voi chuoi doc 8 buoc, quy chuan dat ten, header, trang thai task/bug/prompt, pham vi cho phep/cam
- `01.../20260423_02_ban_do_tai_lieu_va_lenh_v2.md` → them mapping cho prompt 03
- `00_prompt_tho/260423_03_...` → doi ten thanh `20260423_03_lenh_quy_chuan_ai_thong_minh.md` cho dung quy chuan
- File nhat ky nay → ghi phien lam viec hien tai

Ket luan:

- Nhan dien 7 lo hong trong bo SOP hien tai.
- Da bo sung vao entry-point: quy chuan dat ten file, header bat buoc, dinh nghia trang thai (task 7 trang thai, bug 6, prompt 4), pham vi cho phep/cam.
- Da sua loi dat ten prompt 03.
- Da map prompt 03 vao ban do tai lieu.
- Khong tao code hay file phan mem nao.

Rui ro:

- Tai lieu `05_tai_lieu_mo_ta` van dung lan tieng Viet co dau va khong dau. Can chuan hoa nhung doi pham vi lon (5 file).
- Cac file SOP con (04, 05, 06) chua duoc cap nhat de phan anh quy chuan trang thai moi. Can xem xet bo sung sau.

Can review:

- Xac nhan entry-point moi co du thong tin cho agent moi khong.
- ~~Quyet dinh chuan hoa ngon ngu trong 05_tai_lieu_mo_ta (co dau hay khong dau).~~ DA XONG: chuan hoa khong dau.

### 2026-04-23 - Antigravity (phien 2)

Ngay gio: 2026-04-23
Agent: Antigravity

Da thuc hien:

- So sanh `he_thong_quan_ly_ho_so.md` (root) voi `V2/05.../20260423_01_he_thong_quan_ly_ho_so.md` → trung 100% → xoa file root.
- Hop nhat 5 file trong `05_tai_lieu_mo_ta` thanh 1 file duy nhat: `20260423_01_mo_ta_he_thong_tong_hop.md`.
- Bo sung vao file tong hop: yeu cau giao dien (muc 10), yeu cau AI offline (muc 11), yeu cau da nguoi dung (muc 12), dong goi (muc 13) — lay tu prompt tho 01.
- Chuan hoa toan bo sang tieng Viet khong dau, co header V2 day du.
- Cap nhat ban do tai lieu: ghi ro 5 file da gop, chi con 1 file hien tai.
- Xoa 5 file cu trong `05_tai_lieu_mo_ta`.

Ket luan:

- `05_tai_lieu_mo_ta` gon lai con 1 file duy nhat, day du, khong dau, san sang lam co so cho thiet ke giao dien.
- Root khong con file tai lieu rac.
- Ban do tai lieu da cap nhat phan anh trang thai moi.

Rui ro:

- Khong con rui ro ngon ngu lon lon trong V2.
- File `install.ps1` va `onboard_help.txt` o root la file he thong, khong thuoc V2, de nguyen.

### 2026-04-24 - Codex

Ngay gio: 2026-04-24
Agent: Codex

Da doc:

- `V2/20260423_00_tong_quan_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_03_nhat_ky_agent_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_04_quy_chuan_lam_viec_agent_v2.md`
- Cac file mo ta va dac ta dang dat sai trong `PhanMem`

Da di chuyen:

- `PhanMem/01_mo_ta_san_pham/20260424_02_nghiep_vu_kiem_sat_vien_va_user_story.md` -> `V2/05_tai_lieu_mo_ta/20260424_02_nghiep_vu_kiem_sat_vien_va_user_story.md`
- `PhanMem/01_mo_ta_san_pham/20260424_03_ban_do_module_va_luong_du_lieu.md` -> `V2/05_tai_lieu_mo_ta/20260424_03_ban_do_module_va_luong_du_lieu.md`
- `PhanMem/01_mo_ta_san_pham/20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md` -> `V2/05_tai_lieu_mo_ta/20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md`
- `PhanMem/01_mo_ta_san_pham/20260424_05_ho_so_nguon_tai_lieu_va_chien_luoc_ingest.md` -> `V2/05_tai_lieu_mo_ta/20260424_05_ho_so_nguon_tai_lieu_va_chien_luoc_ingest.md`
- `PhanMem/01_mo_ta_san_pham/20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md` -> `V2/05_tai_lieu_mo_ta/20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md`

Da cap nhat:

- Chep noi dung `PhanMem/01_mo_ta_san_pham/20260423_01_mo_ta_he_thong_tong_hop.md` ve `V2/05_tai_lieu_mo_ta/20260423_01_mo_ta_he_thong_tong_hop.md`
- Xoa cac thu muc tai lieu trong `PhanMem`
- Sua lien ket `Nguon prompt` va tham chieu noi bo tu `PhanMem/...` sang `V2/...`
- Bo sung quy dinh ro rang: `PhanMem` chi duoc chua file truc tiep giup phan mem chay duoc; moi tai lieu prompt/SOP/mo ta/report/log phai o `V2`
- Sua cac file map/phuong phap lam viec trong `01_quy_trinh_agent_san_pham` de khong tro sai sang `PhanMem` nua

Ket luan:

- `PhanMem` khong duoc dung de chua tai lieu khong phuc vu phan mem chay.
- Toan bo tai lieu phan tich, quy trinh, dac ta va huong dan agent da duoc dua ve dung khu vuc `V2`.
- Tu thoi diem nay, agent nao dat nham tai lieu vao `PhanMem` la sai quy trinh.

Rui ro:

- `PhanMem` hien de trong cho den khi co code, script build/run, test code hoac cau hinh runtime that su.
- Cac file lich su cu co the van nhac den `V1` trong phan ngu canh; day la dau vet lich su, khong phai nguon van hanh hien tai.

Can review:

- Khi tao code thuc te, phai xac dinh cau truc con cua `PhanMem` truoc khi sinh file chay.

### 2026-04-24 - Codex (phien 2)

Ngay gio: 2026-04-24
Agent: Codex

Da doc:

- `V2/01_quy_trinh_agent_san_pham/20260424_12_quy_trinh_aider_thuc_chien.md`
- `V2/05_tai_lieu_mo_ta/20260423_01_mo_ta_he_thong_tong_hop.md`
- Mapping prompt hien tai trong `V2/00_prompt_tho`

Da tao:

- `V2/00_prompt_tho/20260424_04_lenh_viet_lai_nghiep_vu_va_quan_ly_aider_cho_model_manh.md`

Da cap nhat:

- `20260423_02_ban_do_tai_lieu_va_lenh_v2.md` de map prompt moi

Ket luan:

- Da tao mot lenh manh de dua cho model ngoai refactor lai nghiep vu va bo quan tri Aider theo vai tro ro rang.
- Prompt moi ep model doc dung nguon trong `V2`, giu ranh gioi `V2` va `PhanMem`, va neu can thi de xuat noi dung cho bo `Ops/*.md` ma khong bien `PhanMem` thanh noi chua tai lieu.

Rui ro:

- Cac file `Ops/CONVENTIONS.md`, `Ops/AGENT_STANDARD_AIDER_CONTINUE_PILOT.md`, `Ops/PROJECT_RULES.md`, `Ops/PROMPT_SEQUENCE.md` hien chi duoc nhac den nhu dich de viet lai cho moi truong Aider ben ngoai; chua duoc tao trong workspace nay.

Can review:

- Neu can, buoc tiep theo la tao thang bo `Ops/*.md` trong mot khu vuc rieng ngoai `PhanMem`, dong bo tu prompt moi nay.

### 2026-04-24 - Codex (phien 3)

Ngay gio: 2026-04-24
Agent: Codex

Da doc:

- Toan bo bo mo ta chinh trong `V2/05_tai_lieu_mo_ta`
- Cac spec ky thuat trong `V2/01_quy_trinh_agent_san_pham`
- Corpus thuc te trong `TaiLieu` (68 PDF, scan-image heavy)

Da tao:

- `V2/05_tai_lieu_mo_ta/20260424_07_dac_ta_case_lifecycle_va_work_product.md`
- `V2/05_tai_lieu_mo_ta/20260424_08_dac_ta_audit_trail_va_manual_override.md`
- `V2/05_tai_lieu_mo_ta/20260424_09_dac_ta_citation_anchor_va_ocr_revision.md`
- `V2/05_tai_lieu_mo_ta/20260424_10_tu_dien_document_type_va_quy_tac_phan_loai.md`
- `V2/05_tai_lieu_mo_ta/20260424_11_dac_ta_import_job_backup_restore.md`
- `V2/05_tai_lieu_mo_ta/20260424_12_dac_ta_workspace_ho_tro_kiem_sat_vien.md`

Da cap nhat:

- `20260423_01_mo_ta_he_thong_tong_hop.md`
- `20260424_02_nghiep_vu_kiem_sat_vien_va_user_story.md`
- `20260424_03_ban_do_module_va_luong_du_lieu.md`
- `20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md`
- `20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md`
- `20260423_04_quy_chuan_lam_viec_agent_v2.md`
- `20260423_05_quy_trinh_team_ai_tu_dong.md`
- `20260424_12_quy_trinh_aider_thuc_chien.md`
- `20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
- `20260423_07_tech_stack_va_setup_moi_truong.md`
- `20260423_08_dac_ta_mapping_du_lieu_ho_so.md`
- `20260424_08_dac_ta_layered_architecture.md`
- `20260424_09_dac_ta_json_schema_va_state_management.md`
- `20260424_10_dac_ta_ui_animation_va_transitions.md`
- `20260424_11_build_and_deployment_config.md`
- `20260424_14_implementation_checklist.md`
- `20260424_15_dac_ta_component_api.md`
- `20260424_16_dac_ta_ui_layout_wireframe.md`
- `20260424_18_event_bus_va_state_patterns.md`
- `20260424_13_repo_map_vks_ecms.md`

Ket luan:

- Da bo sung du 6 khoang trong nghiep vu lon nhat truoc khi scaffold.
- Da khoa huong build theo `Tauri + SQLite + PaddleOCR + Ollama adapter`, desktop-first.
- Da bo sung co che `WRONG_DIRECTION_DETECTED` de agent di sai huong phai dung va quay lai entry point.
- Da giam xung dot giua business docs va implementation specs.

Rui ro:

- Bo spec hien da du de scaffold co kiem soat, nhung van can mot luot code review khi tao `PhanMem/` thuc te.
- Chua tao bo `Ops/*.md` rieng cho moi truong Aider ngoai workspace nay.

Can review:

- Neu bat dau scaffold, phai thuc hien `Phase -1: Docs Lock Va Canonical Gate` truoc.

### 2026-04-24 - Codex (phien 4)

Ngay gio: 2026-04-24
Agent: Codex

Da doc:

- `20260424_12_dac_ta_ocr_offline.md`
- `20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md`
- `20260423_01_mo_ta_he_thong_tong_hop.md`
- `20260424_09_dac_ta_citation_anchor_va_ocr_revision.md`
- `20260424_08_dac_ta_audit_trail_va_manual_override.md`
- `20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md`
- `20260423_08_dac_ta_mapping_du_lieu_ho_so.md`
- `20260424_09_dac_ta_json_schema_va_state_management.md`
- `20260424_14_implementation_checklist.md`
- `20260423_04_quy_chuan_lam_viec_agent_v2.md`

Da cap nhat:

- Them yeu cau bat buoc: OCR/AI phai ho tro doc text viet tay trong to loi khai bi can, don viet tay, ghi chu tay.
- Khoa quy tac: `doan chu` va `noi suy text` chi la suggestion bundle, khong duoc silent-merge vao text chinh.
- Bo sung `transcription_state`, `candidate_texts`, `uncertain_spans`, `region_bbox`, `ocr_revision_id` vao cac dac ta lien quan.
- Mo rong review queue, audit trail, citation anchor, search va checklist scaffold de bao dam yeu cau nay duoc thuc thi o muc du lieu + UI + pipeline.

Ket luan:

- Yeu cau doc text viet tay da tro thanh canonical requirement cua project, khong con la tinh nang tuy chon.
- Agent nao scaffold ma bo qua hoac ha cap yeu cau nay duoc xem la `WRONG_DIRECTION_DETECTED`.

### 2026-04-24 - Codex (phien 5)

Ngay gio: 2026-04-24
Agent: Codex

Da doc:

- `scripts/silent_run.cmd`
- `restart_ai_tools.cmd`
- `V2/00_prompt_tho/20260424_04_lenh_viet_lai_nghiep_vu_va_quan_ly_aider_cho_model_manh.md`
- `V2/01_quy_trinh_agent_san_pham/20260424_12_quy_trinh_aider_thuc_chien.md`
- `V2/01_quy_trinh_agent_san_pham/20260424_15_dac_ta_component_api.md`
- `V2/01_quy_trinh_agent_san_pham/20260424_16_dac_ta_ui_layout_wireframe.md`
- `V2/05_tai_lieu_mo_ta/20260424_03_ban_do_module_va_luong_du_lieu.md`
- `V2/05_tai_lieu_mo_ta/20260424_12_dac_ta_workspace_ho_tro_kiem_sat_vien.md`

Da tao:

- `V2/00_prompt_tho/20260424_05_lenh_opencode_tao_bo_dac_ta_tong_the_theo_phase.md`
- `V2/00_prompt_tho/20260424_06_bo_lenh_opencode_theo_phase.md`
- `V2/01_quy_trinh_agent_san_pham/20260424_19_ban_do_dau_ra_bo_dac_ta_cho_opencode.md`

Da cap nhat:

- `20260423_02_ban_do_tai_lieu_va_lenh_v2.md`

Ket luan:

- Da dong goi mot prompt tong cho OpenCode de xu ly bai toan docs lon ma khong hoi lai pham vi.
- Da chia thanh bo lenh theo phase de co the paste tung dot trong OpenCode.
- Da chot ro danh sach file dau ra ma OpenCode phai tao, tranh model tao file lung tung hoac nhay sang code som.

Rui ro:

- `debug_opencode.log` hien khong ton tai trong workspace nen khong co du lieu thuc te de doi chieu hanh vi session.
- OpenCode van co the hoi lai neu model khong tuan thu; khi do can paste them khoi "Khong duoc hoi lai" da duoc tao san.

Can review:

- Neu muon, buoc tiep theo la dung chinh bo lenh nay de tao tiep 13 file dac ta moi trong `V2/05_tai_lieu_mo_ta`.

### 2026-04-24 - Codex (phien 6)

Ngay gio: 2026-04-24
Agent: Codex

Da doc:

- 19 file nguon bat buoc trong V2 (toan bo file tu quy chuan den spec)
- `20260423_00_tong_quan_v2.md`
- `20260423_04_quy_chuan_lam_viec_agent_v2.md`
- `20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
- `20260424_12_quy_trinh_aider_thuc_chien.md`
- `20260423_08_dac_ta_mapping_du_lieu_ho_so.md`
- `20260424_08_dac_ta_layered_architecture.md`
- `20260424_09_dac_ta_json_schema_va_state_management.md`
- `20260424_12_dac_ta_ocr_offline.md`
- `20260423_01_mo_ta_he_thong_tong_hop.md`
- `20260424_03_ban_do_module_va_luong_du_lieu.md`
- `20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md`
- `20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md`
- `20260424_08_dac_ta_audit_trail_va_manual_override.md`
- `20260424_09_dac_ta_citation_anchor_va_ocr_revision.md`
- `20260424_10_tu_dien_document_type_va_quy_tac_phan_loai.md`
- `20260424_11_dac_ta_import_job_backup_restore.md`
- `20260424_12_dac_ta_workspace_ho_tro_kiem_sat_vien.md`

Da tao:

13 file dac ta trong `V2/05_tai_lieu_mo_ta/`:

| # | File | Nhom | Mo ta |
|---|------|-----|-------|
| 1 | `20260424_13_ke_hoach_phan_ra_phase_va_gate_trien_khai.md` | A | Phase chia nho, gate trien khai |
| 2 | `20260424_14_ban_do_thuoc_tinh_metadata_va_schema_nghiep_vu.md` | B | Attribute map, metadata schema |
| 3 | `20260424_15_ban_do_giao_dien_tong_the_va_dieu_huong_chinh.md` | C | Main navigation, screen hierarchy |
| 4 | `20260424_16_dac_ta_man_hinh_quan_ly_trang_va_viewer.md` | C | Page management, document viewer |
| 5 | `20260424_17_dac_ta_man_hinh_quan_ly_ho_so_va_khoi_ho_so.md` | C | Case management, dossier |
| 6 | `20260424_18_dac_ta_man_hinh_doc_text_citation_va_review.md` | C | OCR display, review queue |
| 7 | `20260424_19_dac_ta_quan_ly_tai_khoan_nguoi_dung_va_phan_quyen.md` | C | User account, permission system |
| 8 | `20260424_20_ban_do_luong_chuc_nang_end_to_end.md` | D | End-to-end functional flows |
| 9 | `20260424_21_dac_ta_luong_scan_ocr_ai_danh_gia_chat_luong.md` | D | Scan/OCR/AI pipeline |
| 10 | `20260424_22_dac_ta_tach_file_ingest_db_metadata.md` | D | File splitting, DB ingest |
| 11 | `20260424_23_dac_ta_profile_bi_can_luoc_su_va_xet_hoi.md` | E | Suspect profile, interrogation records |
| 12 | `20260424_24_ban_do_lien_ket_giua_file_thong_tin_thuc_the_su_kien.md` | E | Entity relationship graph |
| 13 | `20260424_25_ban_do_tri_thuc_man_hinh_tom_tat_bi_can.md` | E | Mind map dashboard |

Da cap nhat:

- `20260423_02_ban_do_tai_lieu_va_lenh_v2.md` - them 13 file vao danh sach

Ket luan:

- Da tao day du 13 file dac ta theo yeu cau trong prompt tho.
- Moi file co: muc dich, pham vi, doi tuong doc, dau vao, dau ra, dependency, so do ASCII, bang truong du lieu, acceptance criteria, muc "Khong duoc hieu sai".
- Cac file thuoc 5 nhom: A (Phase/Gate), B (Data/Metadata), C (UI/Man hinh), D (Pipeline), E (Nghiep vu).
- Output chi la docs/spec/map/flow, khong co code.

Rui ro:

- Cac file chi la mo ta/dac ta, chua co implementation.
- Can code review khi bat dau scaffold `PhanMem`.

Can review:

- Xac nhan 13 file da tao day du, khong thieu.
- Khong co THIEU_DAU_VAO trong cac file - thong tin du lay tu 19 file nguon da doc.

### 2026-04-25 - Codex (phien 7)

Ngay gio: 2026-04-25
Agent: Codex

Da doc:

- `V2/20260423_00_tong_quan_v2.md`
- `V2/agents.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_04_quy_chuan_lam_viec_agent_v2.md`
- `V2/01_quy_trinh_agent_san_pham/20260423_02_ban_do_tai_lieu_va_lenh_v2.md`
- `V2/00_prompt_tho/20260424_04_lenh_viet_lai_nghiep_vu_va_quan_ly_aider_cho_model_manh.md`
- `V2/00_prompt_tho/20260424_05_lenh_opencode_tao_bo_dac_ta_tong_the_theo_phase.md`
- `V2/00_prompt_tho/20260424_06_bo_lenh_opencode_theo_phase.md`

Da cap nhat:

- Them dieu khoan dac biet: luon kiem tra luot qua code do AI sinh ra, dac biet dependency/package, script install, URL, endpoint, repo source, CDN va link la.
- Khoa quy tac `SUPPLY_CHAIN_REVIEW_REQUIRED` neu phat hien de xuat co dau hieu bat thuong hoac khong ro nguon goc.
- Dong bo dieu khoan nay vao prompt OpenCode, prompt model manh, `agents.md`, tong quan V2, quy chuan agent va map van hanh.

Ket luan:

- Dieu khoan bao mat chuoi cung ung da tro thanh mot phan chinh thuc cua bo lenh va quy chuan agent.
- Agent sau nay neu bo qua sanity check cho dependency/URL la do AI de xuat se bi coi la di sai huong.

### 2026-04-25 - Antigravity (phien 1)

Ngay gio: 2026-04-25
Agent: Antigravity

Da doc:

- Toan bo 50+ file trong V2 (entry point, agents.md, 22 file SOP, 26 file spec, 3 prompt tho, nhat ky 7 phien)
- Toan bo `PhanMem/` — xac nhan chi co `.gitkeep`, 0 dong code
- `04_case_dang_lam_viec` — xac nhan chi co file quy dinh va mau, khong co case thuc

Da tao:

- `V2/NEXT_ACTION.md` — file chi duong duy nhat de agent biet ngay task tiep theo
- `V2/04_case_dang_lam_viec/20260425_phase0_task_board.md` — task board Phase 0 voi 9 micro-task co owner, gate, dependency, estimate
- `V2/00_prompt_tho/20260425_07_lenh_scaffold_phase_0.md` — prompt code-first dau tien cho Phase 0

Da cap nhat:

- `20260423_02_ban_do_tai_lieu_va_lenh_v2.md` — them 3 file moi vao map
- File nhat ky nay — ghi phien hien tai

Ket luan:

- Nhan dien 4 lo hong chinh khien agent bi sao nhang: (1) thieu task board thuc, (2) thieu prompt scaffold cho code, (3) `04_case_dang_lam_viec` trong, (4) chua map task sang agent cu the.
- Da khac phuc 3/4 lo hong bang cach tao NEXT_ACTION, task board, va prompt scaffold.
- Lo hong (4) — map task sang agent cu the — can nguoi dung quyet dinh agent nao (Codex, Antigravity, Cline, OpenCode) se lam Phase 0.
- Du an san sang chuyen tu Phase -1 (docs lock) sang Phase 0 (project setup).

Rui ro:

- `PhanMem` chua co `package.json` hay `Cargo.toml` — chua qua Phase 0.
- Prompt scaffold Phase 0 dung `create-tauri-app` — can verify version moi nhat khi thuc thi.

Can review:

- Quyet dinh agent nao se thuc thi Phase 0.
- Xac nhan co muon bat dau scaffold ngay hay chua.

## 3. Diem Agent Sau Phai Ton Trong

- V2 la ban dang lam viec, khong duoc xem la ban sao luu cu.
- Prompt tho moi phai duoc doc truoc, khong duoc chi dua vao mo ta mieng.
- Bao cao bug, test, fix phai vao dung thu muc.
- Task, plan, lenh da xong khong de lai trong luong chinh; phai dua sang `98_thung_rac` theo quy dinh.

