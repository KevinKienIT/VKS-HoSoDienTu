# TECH STACK VA SETUP MOI TRUONG

Ngay tao: 2026-04-23
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Dinh nghia ha tang ky thuat de team AI bat dau code du an VKS ECMS (Tauri).

---

## 1. Core Stack (Offline-First, Tauri)

| Thanh phan | Cong nghe | Ly do chon |
| --- | --- | --- |
| **Frontend Framework** | **React.js (Vite)** | Hien dai, component-based, hot-reload nhanh, ho tro tot cho AI team. |
| **Desktop Framework** | **Tauri 2.x** | Nhe hon Electron 96%, RAM it hon 75%, khoi dong nhanh 3-4x. |
| **UI Library** | **Vanilla CSS + Lucide Icons + Framer Motion** | Animation muot, giao dien web-like. |
| **Database** | **SQLite (rusqlite)** | CSDL dang file, khong can cai dat server, qua tauri-plugin-sql. |
| **PDF Processing** | **PDF.js (frontend) + Poppler (backend)** | Doc va hien thi PDF nang, tach page sang anh. |
| **OCR Engine** | **PaddleOCR PP-OCRv5** | Ho tro tieng Viet, nhan dien dau/chu ky, offline. |
| **AI Engine** | **Ollama (Local, default adapter)** | Chay model Qwen / Gemma / Llama local, offline hoan toan. |

Windows desktop la dich chinh cho phase scaffold dau. Mobile/tablet khong nam trong pham vi build dau tien.

---

## 2. Cau Truc Thu Muc Du An (Codebase)

Doi voi team AI, cau truc phai nhat quan de agent de tim file:
```
/src
  /assets          ← Icon, hinh anh
  /components      ← UI Components (Viewer, Sidebar, Timeline)
  /hooks           ← Logic xu ly state
  /services        ← Goi API Tauri, truy van SQLite
  /store           ← Quan ly du lieu ho so (Zustand/Context)
  /lib             ← Tauri API wrapper
/utils             ← Ham tro giup (OCR parser, date formatter)
/src-tauri
  /src             ← Rust backend (main, menu, tray, ocr)
  /icons           ← App icons
  /capabilities    ← Permission configs
```

---

## 3. Quy Trinh Setup Moi Truong (Cho Agent)

Agent khi nhan task code phai tu kiem tra:

### 3.1 Frontend
```bash
node -v  # Yeu cau v18+
npm install
npm run dev
```

### 3.2 Backend (Rust)
```bash
# Kiem tra Rust
rustc --version
cargo --version

# Build Tauri
npm run build
```

### 3.3 Python (OCR)
```bash
python --version  # Yeu cau Python 3.8+
pip install paddlepaddle paddleocr pdf2image opencv-python
```

### 3.4 AI (Optional)
```bash
ollama --version  # Kiem tra Ollama
ollama pull qwen2.5:3b  # Download model
```

---

## 4. Acceptance Criteria cho Framework

Giao dien phai dat cac tieu chi:
- **Zero-latency:** Chuyen giua cac file PDF khong duoc treo.
- **Persistent State:** Dong app mo lai phai quay dung trang dang doc.
- **Search-driven:** Moi du lieu phai duoc tim thay trong < 1 giay.
- **Small Bundle:** App size < 15MB (vs 150MB Electron).
- **Low RAM:** Memory usage < 100MB khi idle.

---

**TEAM AI STATUS: INFRASTRUCTURE DEFINED. TAURI + PADDLEOCR. WAITING FOR IMPLEMENTATION START.**
