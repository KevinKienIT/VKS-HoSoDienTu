# Dac Ta Mapping Du Lieu Ho So

Ngay tao: 2026-04-23
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Chot cach anh xa tu PDF scan tho sang du lieu nghiep vu chuan, phu hop voi taxonomy, citation va review queue hien hanh.

## Muc Luc

1. Vai tro cua tai lieu
2. Nguon chuan can doi chieu
3. Pipeline mapping chuan
4. Truong du lieu bat buoc
5. Gate review va override
6. Acceptance criteria

## 1. Vai Tro Cua Tai Lieu

Tai lieu nay khong con la ghi chu mapping don gian. Day la note ky thuat ho tro cho:

- ingest,
- metadata extraction,
- classification,
- citation,
- review queue,
- audit trail.

Khong duoc dung tai lieu nay de bien he thong thanh:

- OCR trang 1 roi doan loai van ban,
- mapping bang keyword don,
- schema toi gian khong du cho nghiep vu.

## 2. Nguon Chuan Can Doi Chieu

Khi code mapping, bat buoc doi chieu them:

- `V2/05_tai_lieu_mo_ta/20260423_01_mo_ta_he_thong_tong_hop.md`
- `V2/05_tai_lieu_mo_ta/20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md`
- `V2/05_tai_lieu_mo_ta/20260424_09_dac_ta_citation_anchor_va_ocr_revision.md`
- `V2/05_tai_lieu_mo_ta/20260424_10_tu_dien_document_type_va_quy_tac_phan_loai.md`
- `V2/05_tai_lieu_mo_ta/20260424_11_dac_ta_import_job_backup_restore.md`
- `V2/01_quy_trinh_agent_san_pham/20260424_12_dac_ta_ocr_offline.md`

Neu noi dung file nay mau thuan voi cac file tren, uu tien cac file tren.

## 3. Pipeline Mapping Chuan

1. Quet toan bo folder case.
2. Tao `import_job`.
3. Tao `case record` va `document records`.
4. Tach page.
5. OCR tung page.
6. Tach region text may / text viet tay, tao `ocr_revision` dau tien.
7. Trich:
   - `document_type`,
   - `display_name`,
   - `document_title`,
   - `issued_date`,
   - `person/entity/evidence`,
   - `summary_short`,
   - `candidate_readings`,
   - `transcription_state`.
8. Tao citation anchor o muc page/revision.
9. Day item confidence thap vao review queue.
10. Chi sau gate review toi thieu moi coi du lieu la san sang nghiep vu.

## 4. Truong Du Lieu Bat Buoc

Document-level:

- `original_filename`
- `import_sequence`
- `file_hash`
- `display_name`
- `document_type`
- `issued_date`
- `summary_short`
- `ocr_confidence_avg`
- `has_handwriting`
- `classification_confidence`
- `needs_review`

Page-level:

- `page_id`
- `page_index`
- `ocr_text`
- `but_luc`
- `active_revision_id`
- `transcription_state`
- `uncertain_spans`
- `candidate_texts`

Citation-level:

- `citation_id`
- `source_document_id`
- `source_page_id`
- `ocr_revision_id`
- `quote_excerpt`
- `confidence`

## 5. Gate Review Va Override

- OCR confidence thap -> vao review queue.
- `transcription_state != direct` hoac co `uncertain_spans` -> vao review queue.
- `document_type = khong_xac_dinh` -> vao review queue.
- Manual override bat buoc co:
  - `before_value`,
  - `after_value`,
  - `reason_code`,
  - `actor`,
  - `created_at`.

## 6. Acceptance Criteria

- Khong con logic chi OCR trang 1 de phan loai.
- Khong con schema toi gian thieu truong nghiep vu.
- Mapping dung taxonomy chuan duy nhat.
- Citation tro nguoc duoc ve revision OCR.
- Override sau review co audit trail day du.
- Khong co doan chu/noi suy text nao duoc merge vao du lieu chinh ma khong co review state ro rang.
