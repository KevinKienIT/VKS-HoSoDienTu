# BUILD AND DEPLOYMENT CONFIG - TAURI

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Dinh nghia cau hinh Tauri, build script, single instance enforcement, va deployment cho VKS ECMS.
Nguon prompt: Tu yeu cau nguoi dung ve file chay kieu exe, single instance, nhe va nhanh.

---

## 1. Tai Vi Sao Chon Tauri

| Metric | Electron | Tauri | Loi ich |
|--------|----------|-------|--------|
| Bundle Size | 80-244 MB | 3-10 MB | Nhe hon 96% |
| RAM Usage | 150-300 MB | 20-80 MB | Tiết kiệm 75% |
| Cold Start | 1-2s | 200-500ms | Nhanh hơn 3-4x |
| CPU Idle | 1-5% | <1% | Batery-friendly |

**Phu hop cho:**
- Máy không internet, cần di chuyển USB
- KSV cần mở app nhanh
- Môi trường offline 100%

---

## 2. Tauri Configuration

### 2.1 Tauri Main (src-tauri/src/main.rs)

```rust
// src-tauri/src/main.rs
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri::{Manager, AppHandle, Wry};
use std::sync::Mutex;

fn main() {
    // Enable single instance
    let builder = tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _argv, _cwd| {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.set_focus();
            }
        }))
        .plugin(tauri_plugin_log::Builder::new()
            .target(tauri_plugin_log::Target::new(
                tauri_plugin_log::TargetKind::LogDir { file_name: Some("vks-ecms.log".into()) }
            ))
            .build())
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_sql::Builder::default().build())
        .setup(|app| {
            // Create main window
            let window = tauri::WebviewWindowBuilder::new(
                app,
                "main",
                tauri::WebviewUrl::App("index.html".into())
            )
            .title("VKS Ho So Dien Tu")
            .inner_size(1400.0, 900.0)
            .min_inner_size(1024.0, 700.0)
            .center()
            .build()
            .unwrap();

            // Set window state
            window.show().unwrap();

            Ok(())
        });

    builder.run(tauri::generate_context!()).expect("error while running tauri application");
}
```

### 2.2 Capabilities (src-tauri/capabilities/main.json)

```json
{
  "$schema": "https://schema.tauri.app/v2/capabilities",
  "identifier": "main-capability",
  "description": "Main window capabilities",
  "windows": ["main"],
  "permissions": [
    "core:default",
    "core:window:allow-close",
    "core:window:allow-minimize",
    "core:window:allow-maximize",
    "core:window:allow-unmaximize",
    "core:window:allow-set-focus",
    "shell:allow-open",
    "dialog:allow-open",
    "dialog:allow-save",
    "fs:allow-read",
    "fs:allow-write",
    "fs:allow-exists",
    "sql:allow-load",
    "sql:allow-execute",
    "sql:allow-select",
    "log:default"
  ]
}
```

### 2.3 Tauri Config (src-tauri/tauri.conf.json)

```json
{
  "$schema": "https://schema.tauri.app/v2/config",
  "productName": "VKS ECMS",
  "version": "1.0.0",
  "identifier": "com.vks.ecms",
  "build": {
    "beforeDevCommand": "npm run dev",
    "devUrl": "http://localhost:5173",
    "beforeBuildCommand": "npm run build",
    "frontendDist": "../dist"
  },
  "bundle": {
    "active": true,
    "targets": ["nsis"],
    "icon": ["icons/icon.ico"],
    "windows": {
      "nsis": {
        "installMode": "perMachine"
      }
    }
  },
  "app": {
    "windows": [
      {
        "title": "VKS Ho So Dien Tu",
        "width": 1400,
        "height": 900,
        "minWidth": 1024,
        "minHeight": 700,
        "resizable": true,
        "fullscreen": false,
        "center": true
      }
    ],
    "security": {
      "csp": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"
    }
  },
  "plugins": {
    "sql": {
      "preload": ["sqlite:vks-ecms.db"]
    }
  }
}
```

---

## 3. Build Configuration

### 3.1 package.json

```json
{
  "name": "vks-ecms",
  "version": "1.0.0",
  "description": "VKS Ho So Dien Tu - Desktop Application",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build && cargo tauri build",
    "build:win": "npm run build",
    "preview": "vite preview",
    "tauri": "tauri"
  },
  "dependencies": {
    "@tauri-apps/api": "^2.0.0",
    "@tauri-apps/plugin-dialog": "^2.0.0",
    "@tauri-apps/plugin-fs": "^2.0.0",
    "@tauri-apps/plugin-log": "^2.0.0",
    "@tauri-apps/plugin-shell": "^2.0.0",
    "@tauri-apps/plugin-sql": "^2.0.0",
    "pdfjs-dist": "^4.0.0",
    "zustand": "^4.5.0",
    "framer-motion": "^11.0.0",
    "uuid": "^9.0.0"
  },
  "devDependencies": {
    "@tauri-apps/cli": "^2.0.0",
    "@types/node": "^20.0.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@types/uuid": "^9.0.0",
    "@vitejs/plugin-react": "^4.0.0",
    "typescript": "^5.0.0",
    "vite": "^5.0.0",
    "vite-plugin-tauri": "^2.0.0"
  }
}
```

### 3.2 Vite Config

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { tauri } from 'vite-plugin-tauri';
import * as path from 'path';

export default defineConfig({
  plugins: [
    react(),
    tauri()
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src')
    }
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true
  }
});
```

### 3.3 Cargo.toml

```toml
[package]
name = "vks-ecms"
version = "1.0.0"
description = "VKS Ho So Dien Tu"
authors = ["VKS Team"]
edition = "2021"

[lib]
name = "vks_ecms_lib"
crate-type = ["staticlib", "cdylib", "rlib"]

[build-dependencies]
tauri-build = { version = "2", features = [] }

[dependencies]
tauri = { version = "2", features = [] }
tauri-plugin-dialog = "2"
tauri-plugin-fs = "2"
tauri-plugin-log = "2"
tauri-plugin-shell = "2"
tauri-plugin-sql = { version = "2", features = ["sqlite"] }
tauri-plugin-single-instance = "2"
serde = { version = "1", features = ["derive"] }
serde_json = "1"
rusqlite = { version = "0.31", features = ["bundled"] }
log = "0.4"

[profile.release]
panic = "abort"
codegen-units = 1
lto = true
opt-level = "s"
strip = true
```

---

## 4. Application Menu

### 4.1 Menu Definition (Rust)

```rust
// src-tauri/src/menu.rs
use tauri::menu::{MenuBuilder, MenuItemBuilder, SubmenuBuilder};

pub fn create_menu(app: &tauri::AppHandle) -> tauri::Result<tauri::menu::Menu<tauri::Wry>> {
    let file_menu = SubmenuBuilder::new(app, "File")
        .item(&MenuItemBuilder::with_id("new-case", "New Case")
            .accelerator("CmdOrCtrl+N")
            .build(app)?)
        .item(&MenuItemBuilder::with_id("open-folder", "Open Folder...")
            .accelerator("CmdOrCtrl+O")
            .build(app)?)
        .separator()
        .item(&MenuItemBuilder::with_id("export", "Export...")
            .accelerator("CmdOrCtrl+E")
            .build(app)?)
        .separator()
        .item(&MenuItemBuilder::with_id("quit", "Exit")
            .accelerator("Alt+F4")
            .build(app)?)
        .build()?;

    let edit_menu = SubmenuBuilder::new(app, "Edit")
        .undo()
        .redo()
        .separator()
        .cut()
        .copy()
        .paste()
        .select_all()
        .build()?;

    let view_menu = SubmenuBuilder::new(app, "View")
        .item(&MenuItemBuilder::with_id("toggle-sidebar", "Sidebar")
            .accelerator("CmdOrCtrl+B")
            .build(app)?)
        .separator()
        .reload()
        .force_reload()
        .toggle_dev_tools()
        .separator()
        .reset_zoom()
        .zoom_in()
        .zoom_out()
        .separator()
        .fullscreen()
        .build()?;

    let window_menu = SubmenuBuilder::new(app, "Window")
        .minimize()
        .zoom()
        .separator()
        .close()
        .build()?;

    let help_menu = SubmenuBuilder::new(app, "Help")
        .item(&MenuItemBuilder::with_id("about", "About")
            .build(app)?)
        .build()?;

    let menu = MenuBuilder::new(app)
        .item(&file_menu)
        .item(&edit_menu)
        .item(&view_menu)
        .item(&window_menu)
        .item(&help_menu)
        .build()?;

    Ok(menu)
}
```

### 4.2 Menu Event Handler

```rust
// src-tauri/src/main.rs - menu handler
.use_plugin(tauri_plugin_menu::init())

// In setup:
let menu = create_menu(app.handle())?;
app.set_menu(menu)?;

app.on_menu_event(|app, event| {
    match event.id().0.as_str() {
        "quit" => {
            app.exit(0);
        }
        "toggle-sidebar" => {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.emit("menu:toggle-sidebar", ());
            }
        }
        "about" => {
            // Show about dialog
        }
        _ => {}
    }
});
```

---

## 5. System Tray

### 5.1 Tray Configuration (Rust)

```rust
// src-tauri/src/tray.rs
use tauri::{
    menu::{Menu, MenuItem},
    tray::{TrayIcon, TrayIconBuilder, TrayIconEvent},
    AppHandle, Manager,
};

pub fn create_tray(app: &AppHandle) -> tauri::Result<TrayIcon> {
    let open_item = MenuItem::with_id(app, "open", "Open VKS ECMS", true, None::<&str>)?;
    let new_case_item = MenuItem::with_id(app, "new-case", "New Case", true, None::<&str>)?;
    let separator = tauri::menu::PredefinedMenuItem::separator(app)?;
    let quit_item = MenuItem::with_id(app, "quit", "Exit", true, None::<&str>)?;

    let menu = Menu::with_items(app, &[&open_item, &separator, &new_case_item, &separator, &quit_item])?;

    let tray = TrayIconBuilder::new()
        .icon(app.default_window_icon().unwrap().clone())
        .menu(&menu)
        .tooltip("VKS ECMS")
        .on_menu_event(|app, event| match event.id.as_ref() {
            "open" => {
                if let Some(window) = app.get_webview_window("main") {
                    let _ = window.show();
                    let _ = window.set_focus();
                }
            }
            "new-case" => {
                if let Some(window) = app.get_webview_window("main") {
                    let _ = window.emit("menu:new-case", ());
                }
            }
            "quit" => {
                app.exit(0);
            }
            _ => {}
        })
        .on_tray_icon_event(|tray, event| {
            if let TrayIconEvent::DoubleClick { .. } = event {
                if let Some(window) = tray.app_handle().get_webview_window("main") {
                    let _ = window.show();
                    let _ = window.set_focus();
                }
            }
        })
        .build(app)?;

    Ok(tray)
}
```

### 5.2 Global Shortcuts

```rust
// src-tauri/src/main.rs
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Modifiers, Shortcut};

fn setup_shortcuts(app: &AppHandle) -> tauri::Result<()> {
    // Ctrl+Shift+V to show/hide app
    let shortcut = Shortcut::new(Some(Modifiers::CONTROL | Modifiers::SHIFT), Code::KeyV);
    
    app.global_shortcut().on_shortcut(shortcut, |app, _shortcut, _event| {
        if let Some(window) = app.get_webview_window("main") {
            if window.is_visible().unwrap_or(false) {
                let _ = window.hide();
            } else {
                let _ = window.show();
                let _ = window.set_focus();
            }
        }
    })?;
    
    Ok(())
}
```

---

## 6. Frontend API (TypeScript)

```typescript
// src/lib/tauri.ts
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { open, save } from '@tauri-apps/plugin-dialog';
import { readFile, writeFile, exists } from '@tauri-apps/plugin-fs';
import Database from '@tauri-apps/plugin-sql';

let db: Database | null = null;

export async function initDatabase() {
  db = await Database.load('sqlite:vks-ecms.db');
  await db.execute(`
    CREATE TABLE IF NOT EXISTS cases (
      case_id TEXT PRIMARY KEY,
      case_code TEXT NOT NULL,
      case_display_name TEXT,
      source_folder_name TEXT,
      primary_person_name TEXT,
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);
}

export async function query<T>(sql: string, params: any[] = []): Promise<T[]> {
  if (!db) throw new Error('Database not initialized');
  return db.select(sql, params);
}

export async function execute(sql: string, params: any[] = []): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  await db.execute(sql, params);
}

export async function openFolderDialog() {
  return open({
    directory: true,
    multiple: false,
    title: 'Chon thu muc ho so'
  });
}

export async function saveFileDialog(defaultPath: string) {
  return save({
    defaultPath,
    title: 'Luu file'
  });
}

export function onMenuEvent(callback: (action: string) => void) {
  listen('menu:toggle-sidebar', () => callback('toggle-sidebar'));
  listen('menu:new-case', () => callback('new-case'));
  listen('menu:export', () => callback('export'));
}
```

---

## 7. File Structure After Build

```
/src-tauri/
  /src/
    main.rs          # Entry point
    menu.rs         # Menu definition
    tray.rs         # Tray icon
    lib.rs          # Library exports
  /icons/          # App icons
  /capabilities/    # Permission configs
  tauri.conf.json  # Tauri config
  Cargo.toml       # Rust dependencies

/src/
  /components      # React components
  /hooks           # Custom hooks
  /services        # Business logic
  /store           # Zustand stores
  /lib/
    tauri.ts       # Tauri API wrapper
    db.ts         # Database operations
  App.tsx
  main.tsx

/dist/             # Built frontend
/target/release/   # Built Tauri app
/src-tauri/target/release/bundle/nsis/
  VKS ECMS Setup 1.0.0.exe  # Installer
```

---

## 8. Acceptance Criteria

- [ ] Single instance enforced (tauri-plugin-single-instance)
- [ ] System tray with context menu
- [ ] Application menu fully configured
- [ ] Global shortcut (Ctrl+Shift+V)
- [ ] Logging via tauri-plugin-log
- [ ] SQLite via tauri-plugin-sql
- [ ] Build to .exe via Tauri bundler
- [ ] Bundle size < 15MB (vs 150MB+ Electron)

---

## 9. Windows Requirements

**WebView2 Runtime:**
- Windows 11: Co san
- Windows 10: Can cai dat WebView2 Runtime
- Link: https://developer.microsoft.com/en-us/microsoft-edge/webview2/

---

**STATUS: SPECIFICATION DEFINED. WAITING FOR IMPLEMENTATION.**
