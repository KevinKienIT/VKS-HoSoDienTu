# DAC TA OCR OFFLINE

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Dinh nghia giai phap OCR offline cho doc tai lieu PDF (text may, text viet tay, text trong con dau).
Nguon prompt: Tu yeu cau nguoi dung ve doc PDF, OCR offline.

---

## 1. Tong Quan OCR Pipeline

```
PDF Page
  |
  v
Image Preprocessing (denoise, contrast, deskew)
  |
  v
Layout Analysis (detect regions, columns)
  |
  v
Text Detection (bounding boxes)
  |
  v
Text Recognition (per line)
  |                    |
  v                    v
Printed Text      Handwritten Text
  |                    |
  v                    v
Confidence / Type   Ambiguity Scoring + Candidate Bundle
  |
  v
Stamp/Seal Detection
  |
  v
Vietnamese Post-processing
  |
  v
Output (text + confidence + bounding boxes)
```

---

## 2. Lua Chon OCR Engine

### 2.1 Bang So Sanh

| Engine | Text May | Text Tay | Dau/chu Ky | Tieng Viet | Offline | De tich hop |
|--------|----------|----------|------------|------------|---------|-------------|
| **PaddleOCR** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ | ⭐⭐⭐⭐ |
| VietOCR (Tesseract) | ⭐⭐⭐ | ⭐⭐ | ⭐ | ⭐⭐⭐⭐⭐ | ✅ | ⭐⭐⭐⭐⭐ |
| EasyOCR | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ | ✅ | ⭐⭐⭐ |
| Tesseract | ⭐⭐⭐ | ⭐⭐ | ⭐ | ⭐⭐⭐⭐ | ✅ | ⭐⭐⭐⭐⭐ |

### 2.2 Khuyen Nghi: PaddleOCR

**Ly do chon PaddleOCR:**

1. **Seal/Stamp Recognition** - Tich hop san, nhan dien text trong con dau
2. **Vietnamese Support** - `lang='vie'` ho tro tot tieng Viet
3. **PP-OCRv5** - Phien ban moi nhat voi 13% cai thien do chinh xac
4. **Offline** - Chay hoan toan locally, khong can internet
5. **Layout Analysis** - Tu dong phat hien cau truc tai lieu
6. **Python API** - De goi tu Rust backend

---

## 3. Cau Hinh PaddleOCR

### 3.1 Python Service (ocr_service.py)

```python
# ocr_service.py
from paddleocr import PaddleOCR
import cv2
import numpy as np
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class OCRService:
    def __init__(self, use_angle_cls=True, lang='vie', use_gpu=False):
        self.ocr = PaddleOCR(
            use_angle_cls=use_angle_cls,
            lang=lang,
            use_gpu=use_gpu,
            show_log=False,
            det_db_score_mode='fast',
            rec_batch_num=16
        )
        
    def process_pdf_page(self, image: np.ndarray) -> Dict[str, Any]:
        """Xu ly mot trang PDF"""
        # Tien xu ly
        processed = self._preprocess(image)
        
        # Chay OCR
        result = self.ocr.ocr(processed, cls=True)
        
        # Trich xuat ket qua
        lines = []
        for line in result[0] if result and result[0] else []:
            bbox, (text, confidence) = line
            lines.append({
                'text': text,
                'confidence': confidence,
                'bbox': bbox,
                'type': self._classify_line(text, confidence)
            })
        
        # Tim dau/chu ky
        seals = self._detect_seals(processed)
        
        return {
            'lines': lines,
            'seals': seals,
            'full_text': '\n'.join([l['text'] for l in lines]),
            'avg_confidence': sum(l['confidence'] for l in lines) / len(lines) if lines else 0
        }
    
    def _preprocess(self, image: np.ndarray) -> np.ndarray:
        """Tien xu ly anh truoc OCR"""
        # Chuyen sang gray neu can
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
            
        # Adaptive thresholding
        binary = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 11, 2
        )
        
        # Denoise
        denoised = cv2.fastNlMeansDenoising(binary, None, 10, 7, 21)
        
        return denoised
    
    def _classify_line(self, text: str, confidence: float) -> str:
        """Phan loai loai text"""
        if confidence < 0.6:
            return 'low_confidence'
        elif len(text) < 5:
            return 'fragment'
        else:
            return 'normal'
    
    def _detect_seals(self, image: np.ndarray) -> List[Dict]:
        """Phat hien dau/chu ky"""
        # Su dung seal detection model cua PaddleOCR
        # PaddleOCR-VL co tich hop seal recognition
        seals = []
        # ... implementation
        return seals
```

### 3.2 Rust Backend (ocr.rs)

```rust
// src-tauri/src/ocr.rs
use std::process::Command;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct OCRResult {
    pub lines: Vec<OCRLine>,
    pub seals: Vec<Seal>,
    pub full_text: String,
    pub avg_confidence: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct OCRLine {
    pub text: String,
    pub confidence: f64,
    pub bbox: Vec<Vec<f64>>,
    pub line_type: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Seal {
    pub text: String,
    pub confidence: f64,
    pub bbox: Vec<Vec<f64>>,
}

pub fn process_page(image_path: &str) -> Result<OCRResult, String> {
    let output = Command::new("python")
        .args([
            "-c",
            &format!(
                "from ocr_service import OCRService; \
                 import json, sys; \
                 import cv2; \
                 img = cv2.imread(r'{}'); \
                 svc = OCRService(); \
                 result = svc.process_pdf_page(img); \
                 print(json.dumps(result))",
                image_path
            )
        ])
        .output()
        .map_err(|e| e.to_string())?;
    
    if !output.status.success() {
        return Err(String::from_utf8_lossy(&output.stderr).to_string());
    }
    
    let json_str = String::from_utf8_lossy(&output.stdout);
    let result: OCRResult = serde_json::from_str(&json_str)
        .map_err(|e| e.to_string())?;
    
    Ok(result)
}

pub fn process_pdf(pdf_path: &str, output_dir: &str) -> Result<Vec<OCRResult>, String> {
    // 1. Tach PDF thanh anh
    let pages = extract_pdf_pages(pdf_path, output_dir)?;
    
    // 2. OCR tung trang
    let mut results = Vec::new();
    for page_path in pages {
        let result = process_page(&page_path)?;
        results.push(result);
    }
    
    Ok(results)
}

fn extract_pdf_pages(pdf_path: &str, output_dir: &str) -> Result<Vec<String>, String> {
    // Su dung pdf2image hoac poppler
    let output = Command::new("pdftoppm")
        .args(["-png", "-r", "300", pdf_path, &format!("{}/page", output_dir)])
        .output()
        .map_err(|e| e.to_string())?;
    
    if !output.status.success() {
        return Err(String::from_utf8_lossy(&output.stderr).to_string());
    }
    
    // Doc cac file anh da tao
    let mut pages = Vec::new();
    for entry in std::fs::read_dir(output_dir).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();
        if path.extension().map_or(false, |e| e == "png") {
            pages.push(path.to_string_lossy().to_string());
        }
    }
    
    pages.sort();
    Ok(pages)
}
```

### 3.3 cai dat Dependencies

```bash
# Python environment
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# PaddlePaddle CPU
pip install paddlepaddle

# PaddleOCR
pip install paddleocr

# PDF processing
pip install pdf2image poppler

# Scientific computing
pip install opencv-python numpy
```

---

## 4. Chiến Luoc OCR Theo Loai Tai Lieu

### 4.1 Tai Lieu Quy Phạm (Van Ban May)

| Yeu cau | Cau hinh |
|---------|----------|
| Do chinh xac | Cao nhat |
| Mode | PP-OCRv5 server |
| Preprocessing | Standard |

**Quy trinh:**
1. PDF → Image (300 DPI)
2. Preprocess (grayscale, contrast)
3. OCR (PP-OCRv5 server)
4. Post-process (Vietnamese spellcheck)

### 4.2 Tai Lieu Hinh Su (Chu Ky, Dau)

| Yeu cau | Cau hinh |
|---------|----------|
| Phat hien vi tri | Bắt buộc |
| Model | PP-OCRv5 + Seal Recognition |
| Preprocessing | Enhanced contrast |

**Quy trinh:**
1. PDF → Image
2. Layout detection (tim vung chua dau)
3. Seal region isolation
4. Seal OCR (PaddleOCR-VL seal_recognition)
5. Text extraction (noi dung trong dau)

### 4.3 Ban Ghi Tay (To Loi Khai, Don Viet Tay, Ghi Chu Tay)

| Yeu cau | Cau hinh |
|---------|----------|
| Do chinh xac | Trung binh-cao tren span doc duoc; span mo phai danh dau |
| Mode | PP-OCRv5 + handwriting assist layer |
| Preprocessing | Enhanced, denoise, local crop |
| Review | Bat buoc voi span mo/noi suy |

**Quy trinh:**
1. PDF → Image
2. Detect handwriting zones
3. Heavy preprocessing + line segmentation
4. OCR voi handwritten model
5. Ambiguity scoring theo span
6. Handwriting assist local AI de tao top-k candidate readings va de xuat noi suy
7. Danh dau uncertain spans
8. Review queue

### 4.4 Quy Tac Doan Chu Va Noi Suy Text

Trong du an nay, "doan chu" va "noi suy text" duoc dinh nghia nhu sau:

- `candidate_reading`: OCR/AI dua ra 2-3 cach doc co the dung cho span mo.
- `interpolation_suggestion`: de xuat dien giai phan text khuyet dua tren ngu canh cuc bo, khong phai text da xac nhan.
- `approved_text`: text chi duoc dung lam ket qua chinh thuc sau khi qua review.

Bat buoc:

1. Khong duoc silent-merge `candidate_reading` hay `interpolation_suggestion` vao `approved_text`.
2. Moi span mo trong text viet tay phai co `confidence`, `region_bbox`, `ocr_revision_id`.
3. Moi `interpolation_suggestion` phai di vao review queue voi trang thai `pending_review`.
4. Search index chinh chi dung `approved_text`; neu cho phep tim tren de xuat chua duyet thi phai gan badge `pending_handwriting_review`.

---

## 5. Confidence Va Review Queue

### 5.1 Muc Do Confidence

| Muc do | Diem | Hanh dong |
|--------|------|-----------|
| Cao | >= 0.9 | Tu dong accept |
| Trung binh | 0.7 - 0.9 | Chen vao queue |
| Thap | 0.5 - 0.7 | Bat buoc review |
| Rat thap | < 0.5 | Review + re-scan |

### 5.2 Review Queue Structure

```json
{
  "review_id": "uuid",
  "page_id": "uuid",
  "document_id": "uuid",
  "issue_type": "low_confidence | unclear_text | seal_not_detected | handwritten_poor | handwritten_uncertain | interpolation_pending_review",
  "original_image": "path/to/page.png",
  "ocr_result": {
    "text": "extracted text",
    "confidence": 0.65,
    "bbox": [[x1,y1], [x2,y2]],
    "transcription_state": "candidate_only",
    "candidate_texts": ["text 1", "text 2"],
    "uncertain_spans": [{"start": 12, "end": 18, "reason": "handwriting_blur"}]
  },
  "region_bbox": [0, 0, 100, 40],
  "status": "pending",
  "suggestion": "system suggestion",
  "created_at": "timestamp"
}
```

---

## 6. Database Schema cho OCR

```sql
CREATE TABLE ocr_results (
    page_id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL,
    page_index INTEGER NOT NULL,
    full_text TEXT,
    avg_confidence REAL,
    has_seal BOOLEAN DEFAULT FALSE,
    seal_text TEXT,
    has_handwriting BOOLEAN DEFAULT FALSE,
    handwriting_confidence REAL,
    transcription_state TEXT DEFAULT 'direct',
    candidate_bundle JSON,
    needs_review BOOLEAN DEFAULT FALSE,
    raw_result JSON,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(document_id)
);

CREATE TABLE ocr_lines (
    line_id TEXT PRIMARY KEY,
    page_id TEXT NOT NULL,
    line_index INTEGER NOT NULL,
    text TEXT,
    normalized_text TEXT,
    confidence REAL,
    bbox JSON,
    is_handwritten BOOLEAN DEFAULT FALSE,
    uncertain_spans JSON,
    candidate_texts JSON,
    transcription_state TEXT DEFAULT 'direct',
    line_type TEXT DEFAULT 'normal',
    FOREIGN KEY (page_id) REFERENCES ocr_results(page_id)
);

CREATE TABLE review_queue (
    review_id TEXT PRIMARY KEY,
    page_id TEXT NOT NULL,
    issue_type TEXT,
    original_image TEXT,
    ocr_result JSON,
    region_bbox JSON,
    status TEXT DEFAULT 'pending',
    suggestion TEXT,
    resolution TEXT,
    reviewer TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    resolved_at TEXT,
    FOREIGN KEY (page_id) REFERENCES ocr_results(page_id)
);
```

---

## 7. Performance Optimization

### 7.1 Batch Processing

```python
class OCRBatchProcessor:
    def __init__(self, batch_size=8):
        self.batch_size = batch_size
        self.ocr = PaddleOCR(rec_batch_num=batch_size)
    
    def process_batch(self, images: List[np.ndarray]) -> List[Dict]:
        """Xu ly nhieu anh cung luc"""
        results = []
        for i in range(0, len(images), self.batch_size):
            batch = images[i:i + self.batch_size]
            batch_results = self.ocr.ocr_batch(batch, cls=True)
            results.extend(batch_results)
        return results
```

### 7.2 Caching Strategy

```python
import hashlib

def get_cache_key(image: np.ndarray) -> str:
    """Tao cache key tu image hash"""
    return hashlib.md5(image.tobytes()).hexdigest()

# Cache OCR results
cache_dir = Path("storage/cache/ocr")
cache_dir.mkdir(parents=True, exist_ok=True)
```

---

## 8. Fallback Strategy

### 8.1 OCR Engine Fallback

```
Primary: PaddleOCR (PP-OCRv5)
  ↓ (if handwriting uncertain)
Assist: local handwriting assist via Ollama adapter (candidate only)
  ↓ (if van khong on)
Fallback 1: VietOCR (Tesseract-based)
  ↓ (if fails)
Fallback 2: Tesseract directly
  ↓ (if all fail)
Mark as: OCR_FAILED / INTERPOLATION_PENDING_REVIEW → Manual review
```

### 8.2 Quality Fallback

```
High Quality Scan (>200 DPI)
  ↓
Standard Preprocessing
  ↓
PaddleOCR PP-OCRv5

Low Quality Scan (<200 DPI)
  ↓
Enhanced Preprocessing (denoise, sharpen)
  ↓
PaddleOCR PP-OCRv5

Still Low Confidence
  ↓
Mark for Manual Review
```

---

## 9. Integration voi Tauri

### 9.1 Tauri Command

```rust
// src-tauri/src/commands/ocr.rs
use crate::ocr::{self, OCRResult};

#[tauri::command]
pub async fn ocr_page(image_path: String) -> Result<OCRResult, String> {
    ocr::process_page(&image_path)
}

#[tauri::command]
pub async fn ocr_document(pdf_path: String) -> Result<Vec<OCRResult>, String> {
    let output_dir = std::env::temp_dir()
        .join("vks-ecms")
        .join("ocr_temp");
    std::fs::create_dir_all(&output_dir).map_err(|e| e.to_string())?;
    
    ocr::process_pdf(&pdf_path, output_dir.to_str().unwrap())
}
```

### 9.2 Frontend Hook

```typescript
// src/hooks/useOCR.ts
import { invoke } from '@tauri-apps/api/core';
import { useState, useCallback } from 'react';

interface OCRLine {
  text: string;
  normalized_text?: string;
  confidence: number;
  bbox: number[][];
  is_handwritten?: boolean;
  uncertain_spans?: Array<{ start: number; end: number; reason: string }>;
  candidate_texts?: string[];
  transcription_state?: 'direct' | 'candidate_only' | 'interpolated_pending_review' | 'approved_manual';
  line_type: string;
}

interface OCRResult {
  lines: OCRLine[];
  seals: any[];
  full_text: string;
  avg_confidence: number;
}

export function useOCR() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processPage = useCallback(async (imagePath: string) => {
    setLoading(true);
    setError(null);
    try {
      const result = await invoke<OCRResult>('ocr_page', { imagePath });
      return result;
    } catch (e) {
      setError(e as string);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const processDocument = useCallback(async (pdfPath: string) => {
    setLoading(true);
    setError(null);
    try {
      const results = await invoke<OCRResult[]>('ocr_document', { pdfPath });
      return results;
    } catch (e) {
      setError(e as string);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  return { processPage, processDocument, loading, error };
}
```

---

## 10. Acceptance Criteria

- [ ] PaddleOCR tich hop thanh cong
- [ ] Xu ly duoc PDF 20MB+ (68 trang)
- [ ] Text may tieng Viet chinh xac > 95%
- [ ] Phat hien duoc dau/chu ky
- [ ] Text viet tay trong to loi khai va ghi chu tay nhan dien duoc, co candidate reading bundle khi span mo (confidence muc tieu 70-85%)
- [ ] Moi span doan chu/noi suy deu co confidence, region_bbox va review state
- [ ] Khong co noi suy text nao duoc silent accept vao approved text
- [ ] Low confidence tu dong dua vao review queue
- [ ] Batch processing 8-16 anh cung luc
- [ ] Chay offline hoan toan

---

## 11. Recommended Models

### 11.1 PP-OCRv5 Server (Khuyen nghi)

```python
ocr = PaddleOCR(
    use_angle_cls=True,
    lang='vie',
    use_gpu=False,
    det_model='ch_PP-OCRv4_det_infer',
    rec_model='ch_PP-OCRv4_rec_infer',
    cls_model='ch_ppocr_mobile_v2.0_cls_infer'
)
```

### 11.2 Seal Recognition (PaddleOCR-VL)

```python
from paddlex import create_model

model = create_model('PaddleOCR-VL', device='cpu')
result = model.predict(image_path, use_seal_recognition=True)
```

---

**STATUS: SPECIFICATION DEFINED. WAITING FOR IMPLEMENTATION.**
