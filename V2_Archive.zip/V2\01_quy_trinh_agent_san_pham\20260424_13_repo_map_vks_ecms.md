# 🗺️ REPO MAP (AIDER-STYLE) - VKS ECMS

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Ban do thu nho giup Agent nhan dien nhanh cac thanh phan cot loi cua du an.

---

## 🏗️ CAU TRUC LÕI (CORE STRUCTURE)

### 1. Luong Dieu Phoi (Orchestration) - `V2/`
- `20260423_00_tong_quan_v2.md`: Entry point chinh.
- `01_quy_trinh_agent_san_pham/`: SOP, Plan, Role Matrix, Aider Workflow.
- `00_prompt_tho/`: Yeu cau goc tu nguoi dung.

### 2. Dac Ta San Pham (Specifications) - `V2/05_tai_lieu_mo_ta/`
- `20260423_01_mo_ta_he_thong_tong_hop.md`: Tai lieu "kinh thanh" ve tinh nang.
- `20260423_10_dac_ta_hop_nhat_va_chien_luoc_luu_tru.md`: Chien luoc UI/UX va CSDL.
- `20260424_02_nghiep_vu_kiem_sat_vien_va_user_story.md`: User stories cho KSV.
- `20260424_03_ban_do_module_va_luong_du_lieu.md`: Module map va data flow.
- `20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md`: Tim kiem, sap xep, trich dan.
- `20260424_05_ho_so_nguon_tai_lieu_va_chien_luoc_ingest.md`: Chien luoc ingest tai lieu.
- `20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md`: Luat cho AI Offline.
- `20260424_07_dac_ta_case_lifecycle_va_work_product.md`: Vong doi case va work product nghiep vu.
- `20260424_08_dac_ta_audit_trail_va_manual_override.md`: Audit trail va override co kiem chung.
- `20260424_09_dac_ta_citation_anchor_va_ocr_revision.md`: Citation anchor ben vung khi OCR thay doi.
- `20260424_10_tu_dien_document_type_va_quy_tac_phan_loai.md`: Taxonomy document type chuan.
- `20260424_11_dac_ta_import_job_backup_restore.md`: Pause/resume/retry/restore cho import lon.
- `20260424_12_dac_ta_workspace_ho_tro_kiem_sat_vien.md`: Reading queue, bookmark, compare, contradiction, draft.

### 3. Dac Ta Ky Thuat (Technical Specs) - `V2/01_quy_trinh_agent_san_pham/`
- `20260424_08_dac_ta_layered_architecture.md`: 4-layer architecture (Data → Domain → Application → UI).
- `20260424_09_dac_ta_json_schema_va_state_management.md`: JSON schemas, Zustand stores, persistence.
- `20260424_10_dac_ta_ui_animation_va_transitions.md`: Framer Motion variants, interaction patterns.
- `20260424_11_build_and_deployment_config.md`: Tauri config, Cargo.toml, build scripts, system tray.
- `20260424_12_dac_ta_ocr_offline.md`: PaddleOCR pipeline, Rust-Python bridge, review queue.
- `20260424_12_quy_trinh_aider_thuc_chien.md`: Aider-style SEARCH/REPLACE workflow, git rules.

### 4. Du Lieu Ho So (Case Data) - `TaiLieu/`
- `15. Le Thanh Cong.../`: Thu muc chua 68 file PDF vu an dang xu ly.

### 5. Source Code (Implementation) - `PhanMem/`
- `src/`: React frontend (components, hooks, stores, services).
- `src-tauri/`: Rust backend (Tauri commands, OCR bridge, SQLite).
- `public/`: Static assets (icons, fonts).
- `scripts/`: Build scripts, aider_repo_map.py.

---

## 🛠️ CAC FILE QUAN TRONG (HIGH-PRIORITY FILES)

| File | Muc dich |
|------|----------|
| `V2/20260423_00_tong_quan_v2.md` | Entry point cho moi Agent |
| `V2/01_.../20260424_14_implementation_checklist.md` | Master checklist trien khai |
| `V2/01_.../20260424_08_dac_ta_layered_architecture.md` | Kien truc 4 layer |
| `V2/01_.../20260424_11_build_and_deployment_config.md` | Tauri + build config |
| `V2/01_.../20260424_12_dac_ta_ocr_offline.md` | OCR pipeline |
| `PhanMem/package.json` | Node dependencies |
| `PhanMem/src-tauri/tauri.conf.json` | Tauri runtime config |
| `PhanMem/src-tauri/Cargo.toml` | Rust dependencies |

---

## 🔗 MOI QUAN HE LOGIC (LOGIC MAPPING)

```
Input: TaiLieu/*.pdf
  → Process: PaddleOCR (Python) → Rust bridge → SQLite
  → Output: Structured DB + React UI

UI Style: Antigravity Manager (React + Tauri)
Reference: d:/JOBS/Antigravity-Manager/
```

### Data Flow Tom Tat

```
PDF Import → Image Extract (pdftoppm)
  → OCR (PaddleOCR PP-OCRv5)
  → Classify (AI Offline / Rule-based)
  → Store (SQLite via tauri-plugin-sql)
  → Display (React + Framer Motion)
```

---

## 4. Ranh Gioi Thu Muc

- `V2/` la noi chua prompt, SOP, mo ta, dac ta, report, log. **KHONG CHUA CODE.**
- `PhanMem/` chi duoc dung cho: source code, asset UI, cau hinh runtime, script build/run, test code. **KHONG CHUA TAI LIEU MO TA.**
- `TaiLieu/` chua du lieu ho so PDF goc. **CHI DOC, KHONG GHI.**

---

## 5. Tham Chieu Ngoai (External References)

- **Antigravity Manager** (UI reference): `d:/JOBS/Antigravity-Manager/`
- **Tech stack:** React + TypeScript + Vite + Tauri v2 + Zustand + Framer Motion
- **OCR:** PaddleOCR PP-OCRv5 (Python, offline)
- **DB:** SQLite via `tauri-plugin-sql`

---
**HD CHO AGENT:** Hay doc file nay truoc khi thuc hien lenh `ls -R` de tiet kiem context.
