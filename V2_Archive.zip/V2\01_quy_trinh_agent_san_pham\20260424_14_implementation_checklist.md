# ✅ MASTER IMPLEMENTATION CHECKLIST - VKS ECMS

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Danh sach tong hop thu tu trien khai, giup Agent va nguoi dung theo doi tien do end-to-end.

---

## Nguyen Tac Thu Tu

1. **Scaffolding truoc, logic sau** — Dung cau truc thu muc va config truoc khi viet business code.
2. **Backend truoc, frontend sau** — DB schema va services chay duoc truoc khi lam UI.
3. **Core truoc, polish sau** — CRUD va data flow truoc; animation va UX polish sau cung.

---

## Phase -1: Docs Lock Va Canonical Gate

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| -1.1 | Doc file tong hop + 6 file nghiep vu bo sung trong `V2/05_tai_lieu_mo_ta` | `20260423_01_mo_ta_he_thong_tong_hop.md` + `20260424_07` den `20260424_12` | [ ] |
| -1.2 | Chot stack canonical: Tauri + SQLite + PaddleOCR + Ollama adapter | `20260423_07_tech_stack_va_setup_moi_truong.md` | [ ] |
| -1.3 | Xac nhan khong con spec mau thuan truoc khi scaffold | `20260423_04_quy_chuan_lam_viec_agent_v2.md` | [ ] |
| -1.4 | Ghi `docs lock note` vao log truoc khi tao `PhanMem/` | `20260423_03_nhat_ky_agent_v2.md` | [ ] |

---

## Phase 0: Project Setup (Uu tien cao nhat)

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 0.1 | Khoi tao Tauri v2 project trong `PhanMem/` | `20260424_11_build_and_deployment_config.md` | [ ] |
| 0.2 | Cau hinh `package.json`, `vite.config.ts`, `tsconfig.json` | `20260424_11_build_and_deployment_config.md` §3 | [ ] |
| 0.3 | Cau hinh `Cargo.toml` va `tauri.conf.json` | `20260424_11_build_and_deployment_config.md` §2 | [ ] |
| 0.4 | Cau hinh capabilities (`main.json`) | `20260424_11_build_and_deployment_config.md` §2.2 | [ ] |
| 0.5 | Setup `src/` directory structure (components, hooks, stores, services, lib, constants) | `20260424_08_dac_ta_layered_architecture.md` §5 | [ ] |
| 0.6 | Verify `npm run dev` + `cargo tauri dev` chay thanh cong | — | [ ] |

---

## Phase 1: Data Layer (Layer 1)

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 1.1 | Tao SQLite schema: `cases`, `documents`, `pages`, `entities`, `citations` | `20260424_08_dac_ta_layered_architecture.md` §2.1 | [ ] |
| 1.2 | Tao SQLite schema: `ocr_results`, `ocr_lines`, `review_queue` kem `transcription_state`, `candidate_texts`, `uncertain_spans` | `20260424_12_dac_ta_ocr_offline.md` §6 | [ ] |
| 1.3 | Tao SQLite schema: `work_products`, `audit_events`, `import_jobs` | `20260424_09_dac_ta_json_schema_va_state_management.md` §1.8-1.10 | [ ] |
| 1.4 | Tao `src/lib/tauri.ts` — database init, query helpers | `20260424_11_build_and_deployment_config.md` §6 | [ ] |
| 1.5 | Tao JSON config files: `config.json`, `preferences.json` | `20260424_09_dac_ta_json_schema_va_state_management.md` §1 | [ ] |
| 1.6 | Implement JSON schema validation | `20260424_09_dac_ta_json_schema_va_state_management.md` §3 | [ ] |

---

## Phase 2: Domain Layer (Layer 2)

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 2.1 | Dinh nghia TypeScript entities: `Case`, `Document`, `Page`, `Entity`, `Citation` | `20260424_08_dac_ta_layered_architecture.md` §3.1 | [ ] |
| 2.2 | Implement use cases: `CreateCase`, `ImportDocument`, `SearchDocuments` | `20260424_08_dac_ta_layered_architecture.md` §3.2 | [ ] |
| 2.3 | Implement use cases: `RunOCR`, `ClassifyDocument`, `ExtractMetadata` | `20260424_08_dac_ta_layered_architecture.md` §3.2 | [ ] |
| 2.4 | Implement `Result<T, Error>` pattern cho domain errors | `20260424_08_dac_ta_layered_architecture.md` §8 | [ ] |

---

## Phase 3: Application Layer (Layer 3)

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 3.1 | Tao Zustand stores: `caseStore`, `documentStore`, `viewerStore` | `20260424_09_dac_ta_json_schema_va_state_management.md` §2.2 | [ ] |
| 3.2 | Tao Zustand stores: `searchStore`, `uiStore`, `aiStore` | `20260424_09_dac_ta_json_schema_va_state_management.md` §2.2 | [ ] |
| 3.3 | Implement services: `CaseService`, `DocumentService`, `SearchService` | `20260424_08_dac_ta_layered_architecture.md` §4.1 | [ ] |
| 3.4 | Implement services: `OCRService`, `ExportService`, `ConfigService` va handwriting assist coordination | `20260424_08_dac_ta_layered_architecture.md` §4.1 | [ ] |
| 3.5 | Implement hooks: `useCase`, `useDocument`, `useSearch`, `useViewer` | `20260424_08_dac_ta_layered_architecture.md` §4.3 | [ ] |
| 3.6 | Implement auto-save preferences (debounced 2s) | `20260424_09_dac_ta_json_schema_va_state_management.md` §5.1 | [ ] |

---

## Phase 4: UI Layer (Layer 4) — Core

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 4.1 | `AppLayout` — main layout voi sidebar + content area | `20260424_08_dac_ta_layered_architecture.md` §5 | [ ] |
| 4.2 | `Sidebar` — navigation, case list toggle | `20260424_08_dac_ta_layered_architecture.md` §5 | [ ] |
| 4.3 | `CaseList` — danh sach case voi stagger animation | `20260424_10_dac_ta_ui_animation_va_transitions.md` §3.1 | [ ] |
| 4.4 | `DocumentList` — danh sach tai lieu trong case | `20260424_10_dac_ta_ui_animation_va_transitions.md` §3.1 | [ ] |
| 4.5 | `DocumentViewer` — PDF/image viewer voi zoom, pan, page turn | `20260424_10_dac_ta_ui_animation_va_transitions.md` §4 | [ ] |
| 4.6 | `SearchPanel` — tim kiem voi real-time results | `20260424_04_dac_ta_tim_kiem_sap_xep_va_trich_dan.md` | [ ] |

---

## Phase 5: UI Layer — Advanced

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 5.1 | `AIPanel` — tro ly AI offline (default Ollama adapter) | `20260424_06_dac_ta_ai_offline_phan_tich_tai_lieu.md` | [ ] |
| 5.2 | `DossierPanel` — ho so doi tuong | `20260424_08_dac_ta_layered_architecture.md` §5 | [ ] |
| 5.3 | `WorkspacePanel` — reading queue, bookmark, note, contradiction, draft | `V2/05_tai_lieu_mo_ta/20260424_12_dac_ta_workspace_ho_tro_kiem_sat_vien.md` | [ ] |
| 5.4 | `ReviewQueue` — hang cho review OCR low-confidence, text viet tay nghi van, doan chu/noi suy | `20260424_12_dac_ta_ocr_offline.md` §5 | [ ] |
| 5.5 | Modal/Dialog system voi animation | `20260424_10_dac_ta_ui_animation_va_transitions.md` §6 | [ ] |
| 5.6 | Toast notification system | `20260424_10_dac_ta_ui_animation_va_transitions.md` §6.2 | [ ] |
| 5.7 | Skeleton loading states | `20260424_10_dac_ta_ui_animation_va_transitions.md` §3.3 | [ ] |

---

## Phase 6: OCR Pipeline

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 6.1 | Setup Python venv + PaddleOCR dependencies | `20260424_12_dac_ta_ocr_offline.md` §3.3 | [ ] |
| 6.2 | Implement `ocr_service.py` (preprocess, OCR, classify, handwriting candidate bundle) | `20260424_12_dac_ta_ocr_offline.md` §3.1 | [ ] |
| 6.3 | Implement Rust OCR bridge (`ocr.rs`) | `20260424_12_dac_ta_ocr_offline.md` §3.2 | [ ] |
| 6.4 | Tauri commands: `ocr_page`, `ocr_document` | `20260424_12_dac_ta_ocr_offline.md` §9.1 | [ ] |
| 6.5 | Frontend hook: `useOCR` + uncertain spans/candidate readings | `20260424_12_dac_ta_ocr_offline.md` §9.2 | [ ] |
| 6.6 | Batch processing (8-16 images) | `20260424_12_dac_ta_ocr_offline.md` §7.1 | [ ] |
| 6.7 | OCR caching strategy | `20260424_12_dac_ta_ocr_offline.md` §7.2 | [ ] |
| 6.8 | Fallback strategy (PaddleOCR → local handwriting assist → VietOCR → Tesseract) | `20260424_12_dac_ta_ocr_offline.md` §8 | [ ] |

---

## Phase 7: Desktop Features

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 7.1 | Rust: Application menu (File, Edit, View, Window, Help) | `20260424_11_build_and_deployment_config.md` §4 | [ ] |
| 7.2 | Rust: System tray icon + context menu | `20260424_11_build_and_deployment_config.md` §5 | [ ] |
| 7.3 | Rust: Global shortcut (Ctrl+Shift+V) | `20260424_11_build_and_deployment_config.md` §5.2 | [ ] |
| 7.4 | Rust: Single instance enforcement | `20260424_11_build_and_deployment_config.md` §2.1 | [ ] |
| 7.5 | Rust: Logging via tauri-plugin-log | `20260424_11_build_and_deployment_config.md` §2.1 | [ ] |

---

## Phase 8: Polish & Build

| # | Task | Dac ta tham chieu | Status |
|---|------|--------------------|--------|
| 8.1 | Page transitions (Framer Motion) | `20260424_10_dac_ta_ui_animation_va_transitions.md` §2 | [ ] |
| 8.2 | Button/card hover + tap effects | `20260424_10_dac_ta_ui_animation_va_transitions.md` §5 | [ ] |
| 8.3 | Desktop-window responsive layout (khong mobile-first) | `20260424_10_dac_ta_ui_animation_va_transitions.md` §7 | [ ] |
| 8.4 | `prefers-reduced-motion` support | `20260424_10_dac_ta_ui_animation_va_transitions.md` §8.3 | [ ] |
| 8.5 | Dark/Light theme toggle | `20260424_09_dac_ta_json_schema_va_state_management.md` §1.1 | [ ] |
| 8.6 | Build NSIS installer (.exe) | `20260424_11_build_and_deployment_config.md` §2.3 | [ ] |
| 8.7 | Verify bundle size < 15MB | `20260424_11_build_and_deployment_config.md` §8 | [ ] |
| 8.8 | Test tren Windows 10 + WebView2 | `20260424_11_build_and_deployment_config.md` §9 | [ ] |

---

## Tong Ket

| Phase | So task | Phu thuoc |
|-------|---------|-----------|
| 0 – Setup | 6 | Khong |
| 1 – Data | 5 | Phase 0 |
| 2 – Domain | 4 | Phase 1 |
| 3 – Application | 6 | Phase 2 |
| 4 – UI Core | 6 | Phase 3 |
| 5 – UI Advanced | 6 | Phase 4 |
| 6 – OCR | 8 | Phase 1 |
| 7 – Desktop | 5 | Phase 0 |
| 8 – Polish | 8 | Phase 4-7 |
| **Tong** | **54** | — |

> Phase 6 (OCR) va Phase 7 (Desktop) co the trien khai **song song** voi Phase 2-5.

---
**STATUS: CHECKLIST CREATED. READY FOR PHASE 0.**
