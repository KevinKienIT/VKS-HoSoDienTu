# COMPONENT API SPECIFICATION

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Dinh nghia props, states, events, va interfaces cho tat ca React components.
Nguon prompt: Tu yeu cau nguoi dung ve giao dien web-like, nhieu lop, hieu ung muot.

---

## 1. Component Hierarchy

```
App
├── AppLayout
│   ├── TitleBar (native)
│   ├── Sidebar
│   │   ├── CaseListPanel
│   │   └── NavigationPanel
│   └── MainContent
│       ├── CaseView
│       │   ├── DocumentList
│       │   │   └── DocumentCard[]
│       │   └── DocumentViewer
│       │       ├── ViewerToolbar
│       │       ├── ViewerCanvas
│       │       └── ViewerSidebar (citation/entities)
│       ├── SearchView
│       │   ├── SearchBar
│       │   ├── SearchFilters
│       │   └── SearchResults[]
│       ├── DossierView
│       │   ├── PersonCard
│       │   ├── TimelineView
│       │   └── EvidenceList
│       └── AIPanel (overlay/modal)
├── ReviewQueue (overlay/modal)
├── ToastContainer
└── ModalContainer
```

---

## 2. AppLayout

### 2.1 Props

```typescript
interface AppLayoutProps {
  children: React.ReactNode;
}
```

### 2.2 State (from Zustand)

```typescript
interface AppLayoutState {
  sidebarOpen: boolean;
  sidebarWidth: number;
  currentCaseId: string | null;
  currentView: 'case' | 'search' | 'dossier' | 'ai';
}
```

### 2.3 Styling

```css
.app-layout {
  display: flex;
  height: 100vh;
  overflow: hidden;
}

.sidebar {
  width: var(--sidebar-width, 280px);
  min-width: 240px;
  max-width: 400px;
  background: var(--bg-secondary);
  border-right: 1px solid var(--border-color);
  transition: width 0.2s ease;
}

.main-content {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
```

---

## 3. Sidebar

### 3.1 Props

```typescript
interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  width: number;
  onWidthChange: (width: number) => void;
}
```

### 3.2 Sub-components

```typescript
// CaseListPanel
interface CaseListPanelProps {
  cases: Case[];
  currentCaseId: string | null;
  onSelectCase: (caseId: string) => void;
  onCreateCase: () => void;
}

// NavigationPanel
interface NavigationPanelProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  unreadCount?: number;
}
```

---

## 4. CaseView

### 4.1 Props

```typescript
interface CaseViewProps {
  caseId: string;
}
```

### 4.2 State

```typescript
interface CaseViewState {
  documents: Document[];
  selectedDocumentId: string | null;
  sortBy: SortField;
  sortOrder: 'asc' | 'desc';
  filterBy: FilterState;
}
```

---

## 5. DocumentList

### 5.1 Props

```typescript
interface DocumentListProps {
  documents: Document[];
  selectedId: string | null;
  onSelect: (docId: string) => void;
  onContextMenu?: (doc: Document, event: MouseEvent) => void;
  sortBy: SortField;
  sortOrder: 'asc' | 'desc';
  onSortChange: (field: SortField, order: 'asc' | 'desc') => void;
}
```

### 5.2 Document Types

```typescript
type DocumentType = 
  | 'bien_ban'
  | 'cbien_pham_nguoi'
  | 'cbien_vat_chung'
  | 'ket_luan'
  | 'lenh_dieu_tra'
  | 'ban_cao'
  | 'giay_to_khac'
  | 'chu_ky'
  | 'dau'
  | 'unknown';
```

### 5.3 DocumentCard

```typescript
interface DocumentCardProps {
  document: Document;
  isSelected: boolean;
  onClick: () => void;
  onDoubleClick: () => void;
  onContextMenu: (event: MouseEvent) => void;
}

// Display fields
interface DocumentDisplay {
  icon: DocumentType;
  displayName: string;           // System-generated
  originalFilename: string;
  documentType: string;
  issuedDate: string | null;
  pageCount: number;
  hasSeal: boolean;
  hasSignature: boolean;
  confidence: number;
  needsReview: boolean;
}
```

---

## 6. DocumentViewer

### 6.1 Props

```typescript
interface DocumentViewerProps {
  documentId: string;
  initialPage?: number;
}
```

### 6.2 State

```typescript
interface DocumentViewerState {
  currentPage: number;
  totalPages: number;
  zoom: number;              // 0.25 to 4.0
  rotation: 0 | 90 | 180 | 270;
  mode: 'fit-width' | 'fit-page' | 'custom';
  isSidebarOpen: boolean;
  sidebarTab: 'citations' | 'entities' | 'metadata';
}
```

### 6.3 Viewer Toolbar

```typescript
interface ViewerToolbarProps {
  page: number;
  totalPages: number;
  zoom: number;
  onPageChange: (page: number) => void;
  onZoomChange: (zoom: number) => void;
  onRotate: () => void;
  onToggleSidebar: () => void;
  onDownload: () => void;
  onExport: () => void;
}
```

### 6.4 Viewer Controls

```typescript
// Zoom controls
const ZOOM_PRESETS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4];
const ZOOM_STEP = 0.25;

// Page navigation
const PAGE_NAVIGATE = {
  keyboard: { prev: 'ArrowLeft', next: 'ArrowRight' },
  mouse: { wheel: 'vertical scroll' },
  touch: { swipe: 'horizontal' }
};

// Keyboard shortcuts
const VIEWER_SHORTCUTS = {
  'Ctrl+0': 'fit-page',
  'Ctrl+=': 'zoom-in',
  'Ctrl+-': 'zoom-out',
  'Ctrl+Left': 'prev-page',
  'Ctrl+Right': 'next-page',
  'Ctrl+B': 'toggle-sidebar',
  'Escape': 'close'
};
```

---

## 7. SearchPanel

### 7.1 Props

```typescript
interface SearchPanelProps {
  onSearch: (query: SearchQuery) => void;
  onResultClick: (result: SearchResult) => void;
}
```

### 7.2 Search Query

```typescript
interface SearchQuery {
  query: string;
  filters: SearchFilters;
  sortBy: 'relevance' | 'date' | 'name';
  page: number;
  pageSize: number;
}

interface SearchFilters {
  documentTypes: DocumentType[];
  dateRange: { start: string; end: string } | null;
  hasSeal: boolean | null;
  hasSignature: boolean | null;
  confidenceMin: number;
  needsReview: boolean | null;
}
```

### 7.3 Search Result

```typescript
interface SearchResult {
  caseId: string;
  documentId: string;
  displayName: string;
  originalFilename: string;
  documentType: string;
  matchSnippet: string;
  matchField: 'filename' | 'content' | 'metadata';
  pageIndex: number;
  citationAnchorId?: string;
  ocrRevisionId?: string;
  lineIndex?: number;
  score: number;
}
```

### 7.4 SearchBar Component

```typescript
interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  onClear: () => void;
  placeholder: string;
  autoFocus?: boolean;
  suggestions?: string[];
}

// Debounce: 300ms for real-time suggestions
// Submit on Enter or button click
```

---

## 8. DossierView

### 8.1 Props

```typescript
interface DossierViewProps {
  personName?: string;
  entityId?: string;
}
```

### 8.2 Person Dossier

```typescript
interface PersonDossier {
  entity: Entity;
  role: string;
  lyLichTrichNgang: {
    hoTen: string;
    ngaySinh: string;
    diaChi: string;
    cmnd: string;
  };
  relatedDocuments: Document[];
  evidence: Evidence[];
  timeline: TimelineEvent[];
  citations: Citation[];
}
```

### 8.3 Dossier Panel Component

```typescript
interface DossierPanelProps {
  entity: Entity;
  onDocumentClick: (docId: string) => void;
  onCitationClick: (citation: Citation) => void;
  onExport: () => void;
}
```

---

## 9. AIPanel

### 9.1 Props

```typescript
interface AIPanelProps {
  isOpen: boolean;
  onClose: () => void;
  contextDocument?: Document;
  contextCase?: Case;
}
```

### 9.2 AI Query/Response

```typescript
interface AIQuery {
  question: string;
  mode: 'summary' | 'qa' | 'compare' | 'dossier';
  contextScope: 'document' | 'case' | 'all';
}

interface AIResponse {
  answer: string;
  citations: Citation[];
  confidence: number;
  warnings: string[];
  processingTime: number;
}
```

### 9.3 AI States

```typescript
type AIState = 
  | 'idle'
  | 'thinking'
  | 'typing'        // Streaming response
  | 'complete'
  | 'error';

interface AIStore {
  state: AIState;
  query: AIQuery | null;
  response: AIResponse | null;
  error: string | null;
}
```

---

## 10. ReviewQueue

### 10.1 Props

```typescript
interface ReviewQueueProps {
  items: ReviewItem[];
  onResolve: (itemId: string, resolution: Resolution) => void;
  onBatchResolve: (itemIds: string[], resolution: Resolution) => void;
}
```

### 10.2 Review Item

```typescript
interface ReviewItem {
  reviewId: string;
  pageId: string;
  documentId: string;
  issueType: 'low_confidence' | 'unclear_text' | 'type_unknown' | 'seal_missing' | 'metadata_missing';
  originalImage: string;
  ocrText: string;
  suggestedText?: string;
  ocrConfidence: number;
  createdAt: string;
}

type Resolution = 
  | 'accept'
  | 'edit'
  | 'reject'
  | 'skip';
```

### 10.3 Review UI

```typescript
interface ReviewItemCardProps {
  item: ReviewItem;
  onAccept: () => void;
  onEdit: (text: string) => void;
  onReject: () => void;
  onSkip: () => void;
}
```

---

## 11. Toast Notifications

### 11.1 Toast Types

```typescript
type ToastType = 'success' | 'error' | 'warning' | 'info';

interface Toast {
  id: string;
  type: ToastType;
  title: string;
  message: string;
  duration: number;         // ms, default 5000
  action?: {
    label: string;
    onClick: () => void;
  };
}
```

### 11.2 Toast API

```typescript
interface ToastAPI {
  show(toast: Omit<Toast, 'id'>): string;  // returns toast id
  success(message: string, title?: string): string;
  error(message: string, title?: string): string;
  warning(message: string, title?: string): string;
  info(message: string, title?: string): string;
  dismiss(id: string): void;
  dismissAll(): void;
}
```

---

## 12. Modal System

### 12.1 Modal Props

```typescript
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  closable?: boolean;
  maskClosable?: boolean;
  footer?: React.ReactNode;
}
```

### 12.2 Modal Variants

```typescript
interface ConfirmModalProps extends ModalProps {
  content: string;
  onConfirm: () => void;
  onCancel: () => void;
  confirmText?: string;
  cancelText?: string;
  danger?: boolean;
}

interface ImportModalProps extends ModalProps {
  onImport: (files: File[]) => void;
  accept: string[];
}

interface ExportModalProps extends ModalProps {
  onExport: (format: 'json' | 'pdf' | 'xlsx') => void;
}
```

---

## 13. Error Handling

### 13.1 Error Types

```typescript
type AppErrorCode = 
  | 'DB_CONNECTION_FAILED'
  | 'DB_QUERY_FAILED'
  | 'FILE_NOT_FOUND'
  | 'PDF_LOAD_FAILED'
  | 'OCR_FAILED'
  | 'OCR_TIMEOUT'
  | 'AI_SERVICE_UNAVAILABLE'
  | 'AI_RESPONSE_FAILED'
  | 'NETWORK_ERROR'
  | 'PERMISSION_DENIED'
  | 'VALIDATION_FAILED';

interface AppError {
  code: AppErrorCode;
  message: string;
  details?: any;
  timestamp: string;
}
```

### 13.2 Error Display

```typescript
interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback: React.ComponentType<{ error: AppError; reset: () => void }>;
}

interface ErrorToastProps {
  error: AppError;
  onDismiss: () => void;
  onRetry?: () => void;
}
```

---

## 14. Loading States

### 14.1 Skeleton Components

```typescript
interface SkeletonProps {
  variant?: 'text' | 'circular' | 'rectangular';
  width?: number | string;
  height?: number | string;
  animation?: 'pulse' | 'wave' | 'none';
}

// Specific skeletons
const DocumentCardSkeleton: React.FC = () => (
  <div className="skeleton-card">
    <Skeleton variant="rectangular" height={80} />
    <Skeleton variant="text" width="60%" />
    <Skeleton variant="text" width="40%" />
  </div>
);
```

### 14.2 Progress Indicators

```typescript
interface ImportProgress {
  stage: 'scanning' | 'ocr' | 'indexing' | 'complete';
  current: number;
  total: number;
  currentFile?: string;
  message?: string;
}

interface ProgressBarProps {
  value: number;       // 0-100
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'success' | 'error';
}
```

---

## 15. Acceptance Criteria

- [ ] Tat ca components co props interface day du
- [ ] Loading states cho tat ca async operations
- [ ] Error boundaries tai moi component chinh
- [ ] Keyboard shortcuts duoc ghi ro
- [ ] Debounce/throttle cho search/typing
- [ ] Workspace components cho bookmark/note/contradiction/draft duoc dinh nghia ro

---

**STATUS: SPECIFICATION DEFINED.**
