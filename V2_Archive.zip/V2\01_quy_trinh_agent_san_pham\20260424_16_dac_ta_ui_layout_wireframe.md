# UI LAYOUT VA WIREFRAME SPEC

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Dinh nghia vi tri, kich thuoc, va quan he giua cac panel tren man hinh.
Nguon prompt: Tu yeu cau nguoi dung ve giao dien web-like, nhieu panel, hieu ung muot.

---

## 1. Window Layout Overview

```
┌────────────────────────────────────────────────────────────────────┐
│  [Title Bar - Native Windows Controls]                               │
├─────────────┬──────────────────────────────────────────────────────┤
│             │  [Toolbar: Search | Filters | Sort | Import | Export] │
│   SIDEBAR   ├──────────────────────────────────────────────────────┤
│  (Collapsible)│                                                     │
│             │                                                      │
│  - Cases    │              MAIN CONTENT AREA                        │
│  - Search   │                                                     │
│  - Dossier  │  ┌─────────────────────┬────────────────────────┐   │
│  - AI       │  │                     │                        │   │
│  - Review   │  │   DOCUMENT LIST     │   DOCUMENT VIEWER      │   │
│             │  │   (scrollable)     │   (PDF/image)          │   │
│             │  │                     │                        │   │
│             │  │                     │   [Citation Panel]    │   │
│             │  │                     │   [Entity Panel]      │   │
│             │  └─────────────────────┴────────────────────────┘   │
├─────────────┴──────────────────────────────────────────────────────┤
│  [Status Bar: DB Status | OCR Queue | AI Status | Version]          │
└────────────────────────────────────────────────────────────────────┘
```

---

## 2. Dimension Specifications

### 2.1 Screen Regions

| Region | Min Width | Max Width | Default Width | Height |
|--------|----------|-----------|---------------|--------|
| Sidebar | 240px | 400px | 280px | Full height |
| Document List | 300px | 50% | 35% | Flex |
| Document Viewer | 400px | 100% | 65% | Flex |
| Toolbar | 100% | - | 100% | 48px |
| Status Bar | 100% | - | 100% | 24px |
| Citation Panel | 300px | 400px | 320px | Collapsible |

### 2.2 Spacing System

```css
:root {
  /* Base spacing */
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 16px;
  --space-lg: 24px;
  --space-xl: 32px;
  --space-2xl: 48px;

  /* Component spacing */
  --component-padding: var(--space-md);
  --component-gap: var(--space-sm);
  --section-gap: var(--space-lg);

  /* Layout spacing */
  --sidebar-padding: var(--space-md);
  --content-padding: var(--space-lg);
}
```

### 2.3 Breakpoints

```css
:root {
  /* Desktop */
  --breakpoint-lg: 1400px;
  
  /* Tablet */
  --breakpoint-md: 1024px;
  
  /* Mobile */
  --breakpoint-sm: 768px;
}

/* Responsive behavior */
@media (max-width: 1024px) {
  .sidebar {
    position: absolute;
    z-index: 100;
    transform: translateX(-100%);
  }
  
  .sidebar.open {
    transform: translateX(0);
  }
}
```

---

## 3. Sidebar Components

### 3.1 Case List Panel

```
┌─────────────────────────┐
│  [Search in cases...]   │
├─────────────────────────┤
│ ┌─────────────────────┐ │
│ │ 📁 Case 001        │ │ ← Selected (highlighted)
│ │   15 tài liệu     │ │
│ └─────────────────────┘ │
│ ┌─────────────────────┐ │
│ │ 📁 Case 002        │ │
│ │   23 tài liệu     │ │
│ └─────────────────────┘ │
│ ┌─────────────────────┐ │
│ │ 📁 Case 003        │ │
│ │   8 tài liệu      │ │
│ └─────────────────────┘ │
├─────────────────────────┤
│ [+ New Case]           │
└─────────────────────────┘
```

### 3.2 Navigation

```
┌─────────────────────────┐
│ ◉ Tất cả case         │
│ ◎ Tìm kiếm            │
│ ◎ Hồ sơ đối tượng     │
│ ◎ Workbench           │
│ ◎ Trợ lý AI           │
├─────────────────────────┤
│ ⚠ Review (3)          │ ← Badge for pending items
│ ⚙ Cài đặt             │
└─────────────────────────┘
```

---

## 4. Document List Panel

### 4.1 List Header

```
┌──────────────────────────────────────────────────────────────┐
│ Name ↑    │ Loại      │ Ngày   │ Trang │ Dấu │ Chữ ký │ 🔍 │
├──────────────────────────────────────────────────────────────┤
│ Sortable │ Filter    │ Filter │ Sort  │ ✓  │   ✓    │     │
│ columns  │ dropdown │ range  │       │     │        │     │
└──────────────────────────────────────────────────────────────┘
```

### 4.2 Document Card

```
┌─────────────────────────────────────────────────────────────┐
│ 📄                                    ┌──────────┐       │
│                                       │    🅐    │ ← Seal │
│  Biên bản phiên ...                   │    🖊    │ ← Sig  │
│  2024-01-25-08-48-50-01.pdf          └──────────┘       │
│                                       ⚠ Cần review       │
├─────────────────────────────────────────────────────────────┤
│  Loại: Biên bản | 3 trang | Độ tin: 95%                   │
│  "Biên bản kiểm sát tại hiện trường..." ← Preview snippet   │
└─────────────────────────────────────────────────────────────┘
```

### 4.3 Document Card States

| State | Visual |
|-------|--------|
| Default | White background, subtle shadow |
| Hover | Elevated shadow, slight scale(1.01) |
| Selected | Blue border-left, light blue bg |
| Needs Review | Orange left border, warning icon |
| OCR Failed | Red left border, error icon |

---

## 5. Document Viewer Panel

### 5.1 Viewer Layout

```
┌──────────────────────────────────────────────────────────────┐
│ ◀ │ ▶ │  1/3  │ ━━━●━━━━  │ 🔍 │ 🔄 │ 📥 │ ⋮  │
│ Prev│Next│ Page │    Zoom     │Fit │ Rot │Dwn │More│
├──────────────────────────────────────────────────────────────┤
│                                                              │
│                    ┌───────────────────┐                   │
│                    │                   │   ┌─────────────┐  │
│                    │                   │   │ Citations   │  │
│                    │   PDF CONTENT     │   │ ───────────│  │
│                    │                   │   │ Trích đoạn │  │
│                    │                   │   │ 1. Tr.25   │  │
│                    │                   │   │ 2. Tr.3    │  │
│                    │                   │   └─────────────┘  │
│                    │                   │                   │
│                    └───────────────────┘                   │
│                                                              │
├──────────────────────────────────────────────────────────────┤
│ [Sidebar: Citations] [Entities] [Metadata]                     │
└──────────────────────────────────────────────────────────────┘
```

### 5.2 Toolbar Actions

| Icon | Action | Shortcut | Description |
|------|--------|----------|-------------|
| ◀ | Previous Page | Left Arrow | Navigate to previous page |
| ▶ | Next Page | Right Arrow | Navigate to next page |
| 🔍 | Zoom In | Ctrl + = | Increase zoom level |
| 🔍- | Zoom Out | Ctrl + - | Decrease zoom level |
| ↔ | Fit Width | Ctrl + 0 | Fit to viewer width |
| 🔄 | Rotate | R | Rotate 90 degrees |
| 📥 | Download | Ctrl + S | Download original file |
| ⋮ | More | - | Show more options |

### 5.3 Viewer Side Panel (Collapsible)

```
┌────────────────────────────────┐
│ [Citations] [Entities] [Metadata] │
├────────────────────────────────┤
│ TRÍCH ĐOẠN                      │
│ ──────────────────────────────── │
│ ┌────────────────────────────┐  │
│ │ "Biên bản kiểm sát tại"  │  │
│ │ hiện trường...           │  │
│ │ ─ Trang 1, Dòng 5-7     │  │
│ │ [Copy] [View]            │  │
│ └───────────────────────────���┘  │
│ ┌────────────────────────────┐  │
│ │ "Lê Thành Công, sinh..."  │  │
│ │ ─ Trang 2, Dòng 12       │  │
│ │ [Copy] [View]            │  │
│ └────────────────────────────┘  │
├────────────────────────────────┤
│ [Export All Citations]           │
└────────────────────────────────┘
```

---

## 6. Search Panel

### 6.1 Search Layout

```
┌──────────────────────────────────────────────────────────────┐
│  🔍 [Tìm kiếm tài liệu...                    ] [Tìm] [✕] │
├──────────────────────────────────────────────────────────────┤
│ FILTERS                                                    │
│ ┌──────────────────────────────────────────────────────┐  │
│ │ Loại: [▼ Biên bản    ] [+]  │ Ngày: [Từ...→Đến...] │  │
│ │ Dấu: [○ Tất cả ○ Có ○ Không]                          │  │
│ │ Chữ ký: [○ Tất cả ○ Có ○ Không]                        │  │
│ │ Độ tin: [━━━━━━━━●━━] 70%                              │  │
│ │ Review: [○ Tất cả ○ Cần review]                         │  │
│ └──────────────────────────────────────────────────────┘  │
├──────────────────────────────────────────────────────────────┤
│ KẾT QUẢ (15)                                               │
│ ──────────────────────────────────────────────────────────  │
│ ┌─────────────────────────────────────────────────────┐    │
│ │ 📄 Biên bản phiên...                                 │    │
│ │ Match: "kiểm sát" trong nội dung...                 │    │
│ │ Trang 1, Dòng 5 │ Độ tin: 95%                       │    │
│ └─────────────────────────────────────────────────────┘    │
│ ┌─────────────────────────────────────────────────────┐    │
│ │ 📄 Lệnh điều tra...                                  │    │
│ │ Match: "kiểm sát" trong tiêu đề...                  │    │
│ │ Trang 1 │ Độ tin: 92%                                │    │
│ └─────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────┘
```

---

## 7. AI Panel

### 7.1 AI Panel Layout

```
┌──────────────────────────────────────────────────────────────┐
│  🤖 TRỢ LÝ AI                                  [−] [✕]   │
├──────────────────────────────────────────────────────────────┤
│  [📄 Tài liệu hiện tại] [📁 Case hiện tại] [🌐 Toàn bộ]   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Chào Kiểm sát viên! Tôi có thể giúp gì cho anh/chị?    │  │
│  │                                                      │  │
│  │ Có thể:                                             │  │
│  │ • Tóm tắt tài liệu                                 │  │
│  │ • Trả lời câu hỏi về hồ sơ                         │  │
│  │ • Tạo hồ sơ đối tượng                              │  │
│  │ • So sánh các tài liệu                              │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
├──────────────────────────────────────────────────────────────┤
│  [Nhập câu hỏi...                               ] [Gửi] │
├──────────────────────────────────────────────────────────────┤
│  [📄 Tóm tắt] [❓ Hỏi đáp] [📊 So sánh] [👤 Hồ sơ]     │
└──────────────────────────────────────────────────────────────┘
```

### 7.2 AI Response with Citations

```
┌─────────────────────────────────────────────────────────────┐
│ Câu hỏi: Ai là người có mặt tại hiện trường?              │
├─────────────────────────────────────────────────────────────┤
│ Theo hồ sơ, những người có mặt tại hiện trường gồm:       │
│                                                              │
│ 1. **Lê Thành Công** - Người bị hại                          │
│ 2. **Nguyễn Văn B** - Nhân chứng                             │
│ 3. **Đặng Thị C** - Kiểm sát viên                          │
│                                                              │
│ ─── Trích dẫn nguồn ───────────────────────────────────     │
│ [1] Biên bản, Tr.1: "Có mặt tại hiện trường..."         │
│ [2] CBien phạm nhân, Tr.2: "Lê Thành Công, sinh năm..."    │
│                                                              │
│ ⚠️ Độ chính xác: 85% | Xem thêm tài liệu liên quan →      │
└─────────────────────────────────────────────────────────────┘
```

---

## 8. Review Queue Panel

### 8.1 Review Queue Layout

```
┌──────────────────────────────────────────────────────────────┐
│  ⚠️ HÀNG CHỜ REVIEW (3)                                    │
├──────────────────────────────────────────────────────────────┤
│ Filter: [▼ Tất cả       ]  Sort: [▼ Mới nhất   ] [☑ Batch]  │
├──────────────────────────────────────────────────────────────┤
│ ┌──────────────────────────────────────────────────────┐    │
│ │ ⚠️ [LOW CONFIDENCE]                                 │    │
│ │ File: 2024-01-25-09-33-23-01.pdf                    │    │
│ │ Vấn đề: Độ tin chỉ 45%                             │    │
│ │ ┌────────────────────┐  ┌────────────────────────┐  │    │
│ │ │   [Preview ảnh]     │  │ OCR: "Biên bản kiểm..." │  │    │
│ │ │                    │  │ Sửa: [____________]    │  │    │
│ │ └────────────────────┘  └────────────────────────┘  │    │
│ │ [✓ Chấp nhận] [✏ Sửa] [✕ Từ chối] [⏭ Bỏ qua]      │    │
│ └──────────────────────────────────────────────────────┘    │
│ ┌──────────────────────────────────────────────────────┐    │
│ │ ⚠️ [SEAL NOT DETECTED]                               │    │
│ │ ...                                                  │    │
│ └──────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────┘
```

---

## 9. Modal Dialogs

### 9.1 Import Case Modal

```
┌──────────────────────────────────────────────────────────────┐
│  📁 NHẬP CASE MỚI                                 [✕]    │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  📂 Chọn thư mục chứa hồ sơ:                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │                                                      │    │
│  │     [📁] D:\Hồ sơ\2024\LeThanhCong-134             │    │
│  │                                                      │    │
│  │     📄 2024-01-25-08-48-50-01.pdf                  │    │
│  │     📄 2024-01-25-08-48-57-01.pdf                  │    │
│  │     ... (68 files)                                  │    │
│  │                                                      │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                              │
│  ☑ Tự động OCR sau khi nhập                                 │
│  ☐ Giữ nguyên thứ tự file                                   │
│                                                              │
│  Progress: ━━━━━━━━━━━━━━━━━━━░░░░░░░░ 67%                  │
│           Đang xử lý: 2024-01-25-09-15-57-01.pdf            │
│                                                              │
│                  [Hủy]          [Bắt đầu nhập]           │
└──────────────────────────────────────────────────────────────┘
```

### 9.2 Export Modal

```
┌──────────────────────────────────────────────────────────────┐
│  📤 XUẤT DỮ LIỆU                                   [✕]    │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Chọn định dạng:                                            │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  ○ 📄 JSON (.json)                                   │    │
│  │    - Dữ liệu thô, dùng cho backup/restore           │    │
│  │                                                      │    │
│  │  ○ 📊 Excel (.xlsx)                                  │    │
│  │    - Danh sách tài liệu, metadata, trích dẫn        │    │
│  │                                                      │    │
│  │  ○ 📑 PDF Report (.pdf)                              │    │
│  │    - Báo cáo có định dạng, in ấn                    │    │
│  │                                                      │    │
│  │  ○ 📦 Archive (.zip)                                 │    │
│  │    - Toàn bộ case + file gốc                          │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                              │
│  Phạm vi xuất:                                               │
│  ○ Case hiện tại                                             │
│  ○ Case đã chọn (3)                                          │
│  ○ Tất cả case                                                │
│                                                              │
│                  [Hủy]           [Xuất]                   │
└──────────────────────────────────────────────────────────────┘
```

---

## 10. Status Bar

### 10.1 Status Bar Layout

```
┌──────────────────────────────────────────────────────────────┐
│ 🗄️ SQLite: OK │ 📄 68 tài liệu │ ⚠️ 3 cần review │ 🤖 AI: sẵn sàng │ v1.0.0 │
└──────────────────────────────────────────────────────────────┘
```

### 10.2 Status Indicators

| Indicator | States | Color |
|-----------|--------|-------|
| Database | OK (green) / Error (red) / Syncing (yellow) | Icon |
| Documents | Count + status | Text |
| Review Queue | Count (badge) | Warning |
| AI Service | Ready / Busy / Offline | Icon |
| Version | v1.0.0 | Muted text |

---

## 11. Animation Specifications

### 11.1 Panel Transitions

| Animation | Duration | Easing | Description |
|-----------|----------|--------|-------------|
| Sidebar open/close | 300ms | spring(300, 30) | Slide from left |
| Viewer sidebar | 200ms | ease-out | Slide from right |
| Modal appear | 200ms | ease-out | Fade + scale(0.95→1) |
| Modal dismiss | 150ms | ease-in | Fade + scale(1→0.95) |
| Toast enter | 300ms | spring | Slide from bottom |
| Toast exit | 200ms | ease-in | Fade + slide down |

### 11.2 List Animations

| Animation | Stagger | Duration | Description |
|-----------|---------|----------|-------------|
| Document list load | 50ms | 200ms | Fade + slide up |
| Search results | 30ms | 150ms | Faster stagger |
| Card hover | - | 100ms | Scale + shadow |
| Card select | - | 150ms | Border color change |

---

## 12. Dark Mode Colors

```css
:root {
  /* Light Mode */
  --bg-primary: #ffffff;
  --bg-secondary: #f5f5f5;
  --text-primary: #1a1a1a;
  --text-secondary: #666666;
  --border-color: #e0e0e0;
  --accent-color: #2196F3;
}

:root[data-theme="dark"] {
  /* Dark Mode */
  --bg-primary: #1a1a1a;
  --bg-secondary: #2d2d2d;
  --text-primary: #ffffff;
  --text-secondary: #b0b0b0;
  --border-color: #404040;
  --accent-color: #64B5F6;
}
```

---

## 13. Acceptance Criteria

- [ ] Tat ca khu vuc co dimension ro rang
- [ ] Responsive tren 1024px+
- [ ] Animation dung Framer Motion
- [ ] Dark/Light mode ho tro day du
- [ ] Keyboard navigation hoat dong
- [ ] Workbench/continue reading/co doi chieu tai lieu duoc hien trong layout

---

**STATUS: SPECIFICATION DEFINED.**
