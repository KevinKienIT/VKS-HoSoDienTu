# DATA FLOW VA ERROR HANDLING

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Dinh nghia luong du lieu va xu ly loi cho tat ca cac tac vu chinh.
Nguon prompt: Tu yeu cau nguoi dung ve he thong on dinh, xu ly loi tot.

---

## 1. Luong Du Lieu Tong The

### 1.1 Main Data Flow

```
┌─────────────┐
│ PDF Files   │ ← Nguoi dung import folder
└─────┬───────┘
      │
      ▼
┌─────────────────────────────────────────────────┐
│              LAYER 1: INGEST                    │
│  1. Scan folder                                │
│  2. Hash files (trung lap check)                │
│  3. Sort by timestamp                         │
│  4. Create case record                        │
│  5. Create document records                  │
└─────┬───────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────┐
│              LAYER 2: SPLIT                     │
│  1. PDF → Images (Poppler, 300 DPI)            │
│  2. Create page records                       │
│  3. Store images in cache                    │
└─────┬───────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────┐
│              LAYER 3: OCR (Parallel)           │
│  1. Preprocess (denoise, contrast)             │
│  2. PaddleOCR detection                      │
│  3. PaddleOCR recognition                    │
│  4. Seal detection (if configured)          │
│  5. Classify confidence                       │
│  6. Mark for review if < 0.7                  │
└─────┬───────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────┐
│              LAYER 4: METADATA                  │
│  1. Extract title from OCR text               │
│  2. Extract date patterns                    │
│  3. Extract person names                     │
│  4. Classify document type                   │
│  5. Generate display_name                    │
│  6. Generate summary_short                  │
└─────┬───────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────┐
│              LAYER 5: INDEX                     │
│  1. Build FTS5 full-text search index        │
│  2. Build entity graph                       │
│  3. Build citation graph                     │
│  4. Update search results cache             │
└─────┬───────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────┐
│              OUTPUT: QUERYABLE DATA              │
│  - SQLite records                             │
│  - Full-text search index                     │
│  - Citation/citation graph                   │
│  - Review queue items                       │
└─────────────────────────────────────────────────┘
```

### 1.2 User Action Flows

#### Flow: Import Case
```
User clicks Import
    ↓
Show folder dialog
    ↓
User selects folder
    ↓
Backend: scan folder, list files
    ↓
Show preview (file count, size)
    ↓
User confirms
    ↓
Show progress dialog
    ↓
Backend: ingest loop (per file):
    ├─ Read PDF
    ├─ Split pages
    ├─ OCR each page
    ├─ Extract metadata
    └─ Index
    ↓
Progress: 0% → 100%
    ↓
Complete: show case, document list
```

#### Flow: Search Documents
```
User types in search bar
    ↓
Debounce: 300ms
    ↓
Apply filters (if any)
    ↓
Query SQLite FTS5:
    - Full-text match
    - Filter by type/date/confidence
    - Sort by relevance/date/name
    ↓
Return results + metadata
    ↓
UI: render list with snippets
    ↓
User clicks result
    ↓
Open document, jump to page/line
```

#### Flow: AI Query
```
User submits question
    ↓
Collect context (current doc/case)
    ↓
Retrieve relevant documents (FTS5 + rerank)
    ↓
Build prompt with citations
    ↓
Send to Ollama (local LLM)
    ↓
Stream response
    ↓
Extract citations from response
    ↓
Display answer + citations
    ↓
User clicks citation
    ↓
Jump to source document/page
```

---

## 2. Error Handling Matrix

### 2.1 Import/Ingest Errors

| Error Code | Condition | User Message | Action |
|------------|-----------|-------------|--------|
| `INGEST_FOLDER_NOT_FOUND` | Folder doesn't exist | "Không tìm thấy thư mục" | Show dialog to reselect |
| `INGEST_PERMISSION_DENIED` | No read permission | "Không có quyền đọc thư mục" | Show permission dialog |
| `INGEST_PDF_CORRUPT` | PDF file is corrupt | "File bị hỏng: {filename}" | Skip, log, continue |
| `INGEST_PDF_ENCRYPTED` | PDF is password-protected | "File được bảo vệ bằng mật khẩu" | Skip or prompt password |
| `INGEST_DUPLICATE` | File hash exists | "File đã tồn tại: {filename}" | Skip or reimport option |
| `INGEST_NO_PAGES` | PDF has no pages | "File trống: {filename}" | Skip and log |

### 2.2 OCR Errors

| Error Code | Condition | User Message | Action |
|------------|-----------|-------------|--------|
| `OCR_INIT_FAILED` | PaddleOCR fails to load | "Không thể khởi tạo OCR" | Retry or fallback |
| `OCR_IMAGE_FAILED` | Image processing fails | "Xử lý ảnh thất bại" | Retry with different preprocessing |
| `OCR_TIMEOUT` | Processing > 60s per page | "Xử lý quá thời gian" | Cancel, mark for manual |
| `OCR_LOW_QUALITY` | Result confidence < 50% | "Chất lượng thấp, cần review" | Auto-add to review queue |
| `OCR_PYTHON_CRASH` | Python process crashes | "OCR gặp lỗi bất ngờ" | Restart Python, retry |

### 2.3 Database Errors

| Error Code | Condition | User Message | Action |
|------------|-----------|-------------|--------|
| `DB_INIT_FAILED` | SQLite cannot initialize | "Không thể khởi tạo CSDL" | Restart app, repair DB |
| `DB_QUERY_FAILED` | SQL execution fails | "Truy vấn CSDL thất bại" | Log error, show user message |
| `DB_CONSTRAINT` | Unique constraint violation | "Dữ liệu trùng lặp" | Show duplicates, allow merge |
| `DB_FULL` | Disk space low | "Hết dung lượng đĩa" | Alert user, suggest cleanup |

### 2.4 AI Service Errors

| Error Code | Condition | User Message | Action |
|------------|-----------|-------------|--------|
| `AI_SERVICE_DOWN` | Ollama not running | "Dịch vụ AI không hoạt động" | Offer start Ollama |
| `AI_MODEL_NOT_FOUND` | Model not downloaded | "Model AI chưa được cài đặt" | Offer download model |
| `AI_TIMEOUT` | Response > 30s | "AI phản hồi quá chậm" | Cancel, offer retry |
| `AI_NO_CONTEXT` | No relevant documents | "Không tìm thấy tài liệu liên quan" | Suggest broader query |
| `AI_RESPONSE_INVALID` | Malformed response | "Phản hồi AI không hợp lệ" | Retry or fallback to extractive |

### 2.5 UI Errors

| Error Code | Condition | User Message | Action |
|------------|-----------|-------------|--------|
| `UI_PDF_LOAD_FAILED` | PDF.js cannot render | "Không thể hiển thị PDF" | Show original file path |
| `UI_MEMORY_HIGH` | RAM usage > 90% | "Bộ nhớ thấp, đóng tabs" | Show memory warning |
| `UI_NETWORK` | (Future: sync failed) | "Lỗi kết nối" | Retry button |

---

## 3. Retry Strategies

### 3.1 Retry Matrix

| Operation | Max Retries | Delay | Backoff |
|-----------|------------|-------|---------|
| Database query | 3 | 1s | Linear |
| OCR processing | 2 | 5s | None |
| AI request | 3 | 2s | Exponential |
| File read | 5 | 500ms | Linear |
| Image load | 3 | 1s | Linear |

### 3.2 Retry Logic (Pseudocode)

```typescript
async function withRetry<T>(
  operation: () => Promise<T>,
  maxRetries: number,
  delayMs: number,
  backoff: 'linear' | 'exponential' | 'none'
): Promise<T> {
  let lastError: Error;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      
      if (i < maxRetries - 1) {
        const delay = backoff === 'exponential' 
          ? delayMs * Math.pow(2, i)
          : backoff === 'linear'
            ? delayMs * (i + 1)
            : delayMs;
        
        await sleep(delay);
      }
    }
  }
  
  throw lastError;
}
```

---

## 4. Error Recovery

### 4.1 Recovery Strategies

| Scenario | Recovery Action |
|----------|---------------|
| Import fails mid-way | Resume from last successful file |
| OCR fails for some pages | Continue, mark failed pages |
| Database corruption | Auto-backup before writes, restore option |
| App crash | Persist state, restore on restart |
| Low disk space | Pause imports, alert user |

### 4.2 State Persistence

```typescript
interface AppRecoveryState {
  lastOpenedCase: string | null;
  lastOpenedDocument: string | null;
  lastPageIndex: number;
  importProgress: {
    caseId: string | null;
    currentFile: number;
    totalFiles: number;
    status: 'paused' | 'failed';
  } | null;
  pendingReviewItems: string[];
  timestamp: string;
}
```

---

## 5. Logging Specification

### 5.1 Log Levels

| Level | Usage | Example |
|-------|-------|---------|
| `ERROR` | Failures that need attention | OCR crash, DB failure |
| `WARN` | Recoverable issues | Low confidence, retry needed |
| `INFO` | Normal operations | Import started, search executed |
| `DEBUG` | Detailed debugging | SQL queries, API calls |

### 5.2 Log Format

```typescript
interface LogEntry {
  timestamp: string;          // ISO 8601
  level: 'ERROR' | 'WARN' | 'INFO' | 'DEBUG';
  component: string;         // Module name
  operation: string;        // Function/feature
  message: string;         // Human-readable
  context?: {
    userId?: string;
    caseId?: string;
    documentId?: string;
    errorCode?: string;
    stack?: string;
  };
}
```

### 5.3 Log Storage

```typescript
const LOG_CONFIG = {
  maxFileSize: 10 * 1024 * 1024,  // 10MB
  maxFiles: 5,
  directory: 'logs/',
  filenamePattern: 'vks-ecms-{date}.log'
};
```

---

## 6. User Feedback

### 6.1 Error Display

| Severity | UI Element | Duration |
|----------|-----------|----------|
| Info | Toast (info) | 5s auto-dismiss |
| Warning | Toast (warning) | 8s, requires dismiss |
| Error | Modal (error) | Until user action |
| Critical | Full-screen overlay | Until resolved |

### 6.2 Progress Feedback

```typescript
interface ProgressFeedback {
  stage: 'scanning' | 'importing' | 'ocr' | 'indexing';
  current: number;         // Current item
  total: number;          // Total items
  currentItem?: string;   // Filename being processed
  estimatedTime?: number; // Seconds remaining
  canCancel: boolean;
  canPause: boolean;
}
```

---

## 7. Data Validation

### 7.1 Input Validation

| Field | Rules |
|-------|-------|
| Case name | Non-empty, max 255 chars |
| Document filename | Valid filename chars, max 260 chars |
| OCR text | Max 1MB per page |
| Search query | Max 500 chars, trimmed |
| AI question | Max 2000 chars |

### 7.2 Business Rule Validation

```typescript
interface BusinessRules {
  maxDocumentsPerCase: 10000;
  maxPagesPerDocument: 1000;
  maxFileSizeMB: 100;
  minOCRConfidence: 0.3;
  autoReviewThreshold: 0.7;
}
```

---

## 8. Acceptance Criteria

- [ ] Tat ca loi co ma code ro rang
- [ ] Loi hien thi message tieng Viet
- [ ] Recovery tu dong cho loi nhe
- [ ] Critical loi can user action
- [ ] Logging day du cho debug
- [ ] Retry logic cho operations chinh

---

**STATUS: SPECIFICATION DEFINED.**