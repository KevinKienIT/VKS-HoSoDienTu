# EVENT BUS VA STATE MANAGEMENT PATTERNS

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Dinh nghia event bus, pub/sub pattern, va state synchronization giua cac components.
Nguon prompt: Tu yeu cau nguoi dung ve giao dien nhieu lop, dong bo trang thai.

---

## 1. Event Bus Architecture

### 1.1 Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     EVENT BUS (Pub/Sub)                     │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐                │
│  │Emitter 1│    │Emitter 2│    │Emitter 3│                │
│  └────┬────┘    └────┬────┘    └────┬────┘                │
│       │              │              │                        │
│       ▼              ▼              ▼                        │
│  ┌─────────────────────────────────────────┐              │
│  │            Event Channel                  │              │
│  └─────────────────────────────────────────┘              │
│       │              │              │                        │
│       ▼              ▼              ▼                        │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐                │
│  │Listener1│    │Listener2│    │Listener3│                │
│  └─────────┘    └─────────┘    └─────────┘                │
└─────────────────────────────────────────────────────────────┘
```

Nguyen tac chuan:

- Store la source of truth cho UI state.
- Event bus chi dung de phat su kien thong bao va dieu phoi nhe.
- Service khong duoc tu y mutate store truc tiep.

### 1.2 Event Types

```typescript
// Core App Events
type AppEvent = 
  // Navigation
  | 'NAVIGATION_CHANGED'
  | 'VIEW_CHANGED'
  
  // Case Events
  | 'CASE_SELECTED'
  | 'CASE_CREATED'
  | 'CASE_DELETED'
  | 'CASE_UPDATED'
  
  // Document Events
  | 'DOCUMENT_SELECTED'
  | 'DOCUMENT_OPENED'
  | 'DOCUMENT_CLOSED'
  | 'DOCUMENT_UPDATED'
  
  // Import Events
  | 'IMPORT_STARTED'
  | 'IMPORT_PROGRESS'
  | 'IMPORT_COMPLETED'
  | 'IMPORT_FAILED'
  
  // OCR Events
  | 'OCR_STARTED'
  | 'OCR_PROGRESS'
  | 'OCR_COMPLETED'
  | 'OCR_FAILED'
  
  // Search Events
  | 'SEARCH_STARTED'
  | 'SEARCH_COMPLETED'
  | 'SEARCH_CLEARED'
  
  // AI Events
  | 'AI_QUERY_SENT'
  | 'AI_RESPONSE_RECEIVED'
  | 'AI_ERROR'
  
  // Review Events
  | 'REVIEW_ITEM_ADDED'
  | 'REVIEW_ITEM_RESOLVED'
  
  // UI Events
  | 'SIDEBAR_TOGGLED'
  | 'THEME_CHANGED'
  | 'TOAST_SHOWN'
  
  // System Events
  | 'APP_STARTED'
  | 'APP_ERROR'
  | 'STATE_PERSISTED';
```

---

## 2. Event Definitions

### 2.1 Navigation Events

```typescript
// NAVIGATION_CHANGED
interface NavigationChangedEvent {
  type: 'NAVIGATION_CHANGED';
  payload: {
    from: ViewType;
    to: ViewType;
  };
}

// VIEW_CHANGED
interface ViewChangedEvent {
  type: 'VIEW_CHANGED';
  payload: {
    view: ViewType;
    params?: Record<string, any>;
  };
}
```

### 2.2 Case Events

```typescript
// CASE_SELECTED
interface CaseSelectedEvent {
  type: 'CASE_SELECTED';
  payload: {
    caseId: string;
    previousCaseId?: string;
  };
}

// CASE_CREATED
interface CaseCreatedEvent {
  type: 'CASE_CREATED';
  payload: {
    case: Case;
    sourceFolder: string;
  };
}
```

### 2.3 Document Events

```typescript
// DOCUMENT_SELECTED
interface DocumentSelectedEvent {
  type: 'DOCUMENT_SELECTED';
  payload: {
    documentId: string;
    caseId: string;
  };
}

// DOCUMENT_OPENED
interface DocumentOpenedEvent {
  type: 'DOCUMENT_OPENED';
  payload: {
    documentId: string;
    pageIndex: number;
  };
}
```

### 2.4 Import Events

```typescript
// IMPORT_PROGRESS
interface ImportProgressEvent {
  type: 'IMPORT_PROGRESS';
  payload: {
    caseId: string;
    current: number;
    total: number;
    currentFile: string;
    stage: 'scanning' | 'importing' | 'ocr' | 'indexing';
  };
}

// IMPORT_COMPLETED
interface ImportCompletedEvent {
  type: 'IMPORT_COMPLETED';
  payload: {
    caseId: string;
    documentsImported: number;
    pagesProcessed: number;
    ocrSuccessRate: number;
    reviewItemsCount: number;
  };
}
```

### 2.5 Search Events

```typescript
// SEARCH_STARTED
interface SearchStartedEvent {
  type: 'SEARCH_STARTED';
  payload: {
    query: string;
    filters: SearchFilters;
  };
}

// SEARCH_COMPLETED
interface SearchCompletedEvent {
  type: 'SEARCH_COMPLETED';
  payload: {
    query: string;
    resultsCount: number;
    duration: number;
  };
}
```

### 2.6 AI Events

```typescript
// AI_QUERY_SENT
interface AIQuerySentEvent {
  type: 'AI_QUERY_SENT';
  payload: {
    question: string;
    mode: 'summary' | 'qa' | 'compare' | 'dossier';
    contextScope: 'document' | 'case' | 'all';
  };
}

// AI_RESPONSE_RECEIVED
interface AIResponseReceivedEvent {
  type: 'AI_RESPONSE_RECEIVED';
  payload: {
    response: AIResponse;
    duration: number;
  };
}
```

---

## 3. Event Bus Implementation

### 3.1 Event Bus (TypeScript)

```typescript
// src/lib/eventBus.ts
type EventCallback<T = any> = (payload: T) => void;

class EventBus {
  private listeners: Map<string, Set<EventCallback>> = new Map();
  
  // Subscribe
  on<T>(event: string, callback: EventCallback<T>): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    
    // Return unsubscribe function
    return () => this.off(event, callback);
  }
  
  // Unsubscribe
  off<T>(event: string, callback: EventCallback<T>): void {
    this.listeners.get(event)?.delete(callback);
  }
  
  // Emit
  emit<T>(event: string, payload: T): void {
    this.listeners.get(event)?.forEach(callback => {
      try {
        callback(payload);
      } catch (error) {
        console.error(`Event handler error in ${event}:`, error);
      }
    });
  }
  
  // Once
  once<T>(event: string, callback: EventCallback<T>): void {
    const wrappedCallback = (payload: T) => {
      callback(payload);
      this.off(event, wrappedCallback);
    };
    this.on(event, wrappedCallback);
  }
  
  // Clear all listeners for event
  clear(event?: string): void {
    if (event) {
      this.listeners.delete(event);
    } else {
      this.listeners.clear();
    }
  }
}

export const eventBus = new EventBus();
```

### 3.2 React Hook for Event Bus

```typescript
// src/hooks/useEventBus.ts
export function useEventBus<T>(event: string, callback: EventCallback<T>) {
  useEffect(() => {
    const unsubscribe = eventBus.on(event, callback);
    return unsubscribe;
  }, [event, callback]);
}
```

### 3.3 Usage Example

```typescript
// Component A - Emits event
function ImportButton() {
  const handleImport = async () => {
    const caseId = await importCase(folderPath);
    eventBus.emit('CASE_CREATED', { case, sourceFolder: folderPath });
  };
  
  return <Button onClick={handleImport}>Import Case</Button>;
}

// Component B - Listens to event
function CaseList() {
  useEventBus<CaseCreatedEvent>('CASE_CREATED', ({ payload }) => {
    toast.success(`Case "${payload.case.case_display_name}" đã được tạo`);
  });
  
  // ...
}
```

---

## 4. Zustand Store Events Integration

### 4.1 Store with Event Emission

```typescript
// src/store/caseStore.ts
import { create } from 'zustand';
import { eventBus } from '../lib/eventBus';

interface CaseStore {
  cases: Case[];
  currentCaseId: string | null;
  
  setCases: (cases: Case[]) => void;
  selectCase: (caseId: string) => void;
  addCase: (case: Case) => void;
}

export const useCaseStore = create<CaseStore>((set, get) => ({
  cases: [],
  currentCaseId: null,
  
  setCases: (cases) => set({ cases }),
  
  selectCase: (caseId) => {
    const previousCaseId = get().currentCaseId;
    set({ currentCaseId: caseId });
    
    // Emit event
    eventBus.emit('CASE_SELECTED', {
      caseId,
      previousCaseId
    });
  },
  
  addCase: (case) => {
    set(state => ({
      cases: [...state.cases, case]
    }));
    
    eventBus.emit('CASE_CREATED', { case });
  }
}));
```

### 4.2 Combined Store (Flat)

```typescript
// src/store/index.ts
export const useAppStore = create<CombinedState>()(
  (set, get) => ({
    // Navigation
    currentView: 'case',
    setCurrentView: (view) => set({ currentView: view }),
    
    // Case
    cases: [],
    currentCaseId: null,
    setCases: (cases) => set({ cases }),
    selectCase: (caseId) => set({ 
      currentCaseId: caseId,
      currentView: 'case'
    }),
    
    // Document
    documents: [],
    currentDocumentId: null,
    currentPageIndex: 0,
    setDocuments: (docs) => set({ documents: docs }),
    selectDocument: (docId, pageIndex = 0) => set({
      currentDocumentId: docId,
      currentPageIndex: pageIndex
    }),
    
    // Search
    searchQuery: '',
    searchResults: [],
    isSearching: false,
    setSearchQuery: (query) => set({ searchQuery: query }),
    setSearchResults: (results) => set({ 
      searchResults: results,
      isSearching: false
    }),
    
    // UI State
    sidebarOpen: true,
    sidebarWidth: 280,
    theme: 'light',
    toggleSidebar: () => set(s => ({ sidebarOpen: !s.sidebarOpen })),
    setSidebarWidth: (width) => set({ sidebarWidth: width }),
    setTheme: (theme) => set({ theme }),
    
    // Import
    importProgress: null,
    setImportProgress: (progress) => set({ importProgress: progress }),
    
    // Review
    reviewItems: [],
    setReviewItems: (items) => set({ reviewItems: items }),
    
    // AI
    aiState: 'idle',
    aiResponse: null,
    setAIState: (state) => set({ aiState: state }),
    setAIResponse: (response) => set({ aiResponse: response })
  })
);
```

---

## 5. Composition Layer Va Service Coordination

### 5.1 Service Pattern with Events

```typescript
// src/services/caseService.ts
import { eventBus } from '../lib/eventBus';

export const caseService = {
  async getAll(): Promise<Case[]> {
    try {
      return await db.query<Case>('SELECT * FROM cases ORDER BY created_at DESC');
    } catch (error) {
      eventBus.emit('APP_ERROR', {
        code: 'DB_QUERY_FAILED',
        message: 'Không thể lấy danh sách case'
      });
      throw error;
    }
  },
  
  async create(data: CreateCaseInput): Promise<Case> {
    const caseId = generateId();
    
    await db.execute(`
      INSERT INTO cases (case_id, case_code, source_folder_name, created_at)
      VALUES (?, ?, ?, ?)
    `, [caseId, data.caseCode, data.sourceFolder, new Date().toISOString()]);
    
    const newCase = await db.queryOne<Case>(
      'SELECT * FROM cases WHERE case_id = ?',
      [caseId]
    );
    
    return newCase;
  },
  
  async delete(caseId: string): Promise<void> {
    await db.execute('DELETE FROM cases WHERE case_id = ?', [caseId]);
  }
};
```

Cap nhat store phai xay ra o composition layer hoac hook:

```typescript
const cases = await caseService.getAll();
useAppStore.getState().setCases(cases);
```

### 5.2 OCR Service with Events

```typescript
// src/services/ocrService.ts
import { invoke } from '@tauri-apps/api/core';
import { eventBus } from '../lib/eventBus';
import { useAppStore } from '../store';

export const ocrService = {
  async processDocument(pdfPath: string, caseId: string): Promise<OCRResult[]> {
    eventBus.emit('OCR_STARTED', { caseId, pdfPath });
    
    try {
      // Start progress reporting
      const progressInterval = setInterval(() => {
        const progress = useAppStore.getState().importProgress;
        eventBus.emit('OCR_PROGRESS', progress);
      }, 500);
      
      const results = await invoke<OCRResult[]>('ocr_document', { pdfPath });
      
      clearInterval(progressInterval);
      
      // Emit completion
      const successRate = results.filter(r => r.avg_confidence > 0.7).length / results.length;
      eventBus.emit('OCR_COMPLETED', { 
        caseId, 
        resultsCount: results.length,
        successRate 
      });
      
      return results;
    } catch (error) {
      eventBus.emit('OCR_FAILED', { 
        caseId, 
        error: (error as Error).message 
      });
      throw error;
    }
  }
};
```

---

## 6. Component Communication Patterns

### 6.1 Parent-Child (Props)

```typescript
// Parent passes data and callbacks to child
<DocumentList
  documents={documents}
  selectedId={selectedId}
  onSelect={(id) => caseStore.selectDocument(id)}
  onDoubleClick={(doc) => viewerStore.openDocument(doc.id)}
/>
```

### 6.2 Sibling-to-Sibling (Event Bus or Store)

```typescript
// DocumentList updates store, Viewer reads from store
function DocumentList() {
  const { documents, selectDocument } = useAppStore();
  
  return documents.map(doc => (
    <DocumentCard
      onClick={() => selectDocument(doc.id)}
    />
  ));
}

function DocumentViewer() {
  const { currentDocumentId } = useAppStore();
  
  // Automatically reacts to currentDocumentId change
  useEffect(() => {
    if (currentDocumentId) {
      loadDocument(currentDocumentId);
    }
  }, [currentDocumentId]);
}
```

### 6.3 Cross-Component (Event Bus)

```typescript
// Search triggers case selection
function SearchPanel() {
  const handleResultClick = (result: SearchResult) => {
    eventBus.emit('DOCUMENT_SELECTED', {
      documentId: result.documentId,
      caseId: result.caseId
    });
  };
}

function DocumentList() {
  useEventBus<DocumentSelectedEvent>('DOCUMENT_SELECTED', ({ payload }) => {
    useAppStore.getState().selectCase(payload.caseId);
    useAppStore.getState().selectDocument(payload.documentId);
  });
}
```

---

## 7. State Persistence Pattern

### 7.1 Persistence Middleware

```typescript
// src/store/persistence.ts
import { persist, createJSONStorage } from 'zustand/middleware';

const storage = createJSONStorage(() => tauriFileStorage);

export const persistedStore = create(
  persist(
    (set, get) => ({ ...initialState }),
    {
      name: 'vks-ecms-state',
      storage,
      partialize: (state) => ({
        // Only persist these fields
        lastOpenedCase: state.lastOpenedCase,
        lastOpenedDocument: state.lastOpenedDocument,
        sidebarWidth: state.sidebarWidth,
        theme: state.theme,
        fontSize: state.fontSize,
        recentSearches: state.recentSearches
      }),
      onRehydrateStorage: () => (state) => {
        // Emit after rehydration
        eventBus.emit('STATE_PERSISTED', state);
      }
    }
  )
);
```

### 7.2 Recovery on App Start

```typescript
// src/App.tsx
function App() {
  const [rehydrated, setRehydrated] = useState(false);
  
  useEffect(() => {
    // Initialize app
    async function init() {
      await initDatabase();
      await caseService.getAll();
      setRehydrated(true);
      
      // Restore last opened case after persisted state rehydration
      const lastOpenedCase = useAppStore.getState().lastOpenedCase;
      if (lastOpenedCase) {
        useAppStore.getState().selectCase(lastOpenedCase);
      }
    }
    
    init();
  }, []);
  
  if (!rehydrated) {
    return <LoadingScreen />;
  }
  
  return <AppLayout />;
}
```

---

## 8. Debugging Tools

### 8.1 Event Logger

```typescript
// src/lib/eventLogger.ts
if (import.meta.env.DEV) {
  eventBus.on('*', (type, payload) => {
    console.log(`[Event] ${type}`, payload);
  });
}
```

### 8.2 State Inspector

```typescript
// Dev-only state inspection
if (import.meta.env.DEV) {
  (window as any).__store = useAppStore;
  (window as any).__eventBus = eventBus;
}
```

---

## 9. Acceptance Criteria

- [ ] Event bus cho phep pub/sub giua cac components
- [ ] Store dong bo voi events
- [ ] State persistence hoat dong
- [ ] Recovery on app restart
- [ ] Debug logging cho DEV mode
- [ ] No circular dependencies

---

**STATUS: SPECIFICATION DEFINED.**
