# Ban Do Dau Ra Bo Dac Ta Cho OpenCode

Ngay tao: 2026-04-24
Ngay cap nhat gan nhat: 2026-04-24
Sua boi agent: Codex
Muc dich: Chot danh sach file dau ra ma OpenCode phai tao khi xu ly goi yeu cau dac ta lon theo phase.
Nguon prompt: `V2/00_prompt_tho/20260424_05_lenh_opencode_tao_bo_dac_ta_tong_the_theo_phase.md`

## Muc Luc

1. Muc tieu
2. Danh sach file dau ra
3. Nhom theo phase
4. So do quan he giua cac file
5. Quy tac cho agent

## 1. Muc Tieu

Tai lieu nay duoc lap ra de:

- chan viec OpenCode hoi lai scope tong quat,
- chot ro file nao phai duoc tao,
- chot ro file nao lam entry point cho nhom data/UI/AI,
- tranh de model tao file lung tung ngoai map.

## 2. Danh Sach File Dau Ra

OpenCode phai tao dung cac file sau trong `V2/05_tai_lieu_mo_ta`:

1. `20260424_13_ke_hoach_phan_ra_phase_va_gate_trien_khai.md`
2. `20260424_14_ban_do_thuoc_tinh_metadata_va_schema_nghiep_vu.md`
3. `20260424_15_ban_do_giao_dien_tong_the_va_dieu_huong_chinh.md`
4. `20260424_16_dac_ta_man_hinh_quan_ly_trang_va_viewer.md`
5. `20260424_17_dac_ta_man_hinh_quan_ly_ho_so_va_khoi_ho_so.md`
6. `20260424_18_dac_ta_man_hinh_doc_text_citation_va_review.md`
7. `20260424_19_dac_ta_quan_ly_tai_khoan_nguoi_dung_va_phan_quyen.md`
8. `20260424_20_ban_do_luong_chuc_nang_end_to_end.md`
9. `20260424_21_dac_ta_luong_scan_ocr_ai_danh_gia_chat_luong.md`
10. `20260424_22_dac_ta_tach_file_ingest_db_metadata.md`
11. `20260424_23_dac_ta_profile_bi_can_luoc_su_va_xet_hoi.md`
12. `20260424_24_ban_do_lien_ket_giua_file_thong_tin_thuc_the_su_kien.md`
13. `20260424_25_ban_do_tri_thuc_man_hinh_tom_tat_bi_can.md`

## 3. Nhom Theo Phase

### Phase 0

- `20260424_13_ke_hoach_phan_ra_phase_va_gate_trien_khai.md`

### Phase 1

- `20260424_14_ban_do_thuoc_tinh_metadata_va_schema_nghiep_vu.md`
- `20260424_21_dac_ta_luong_scan_ocr_ai_danh_gia_chat_luong.md`
- `20260424_22_dac_ta_tach_file_ingest_db_metadata.md`
- `20260424_24_ban_do_lien_ket_giua_file_thong_tin_thuc_the_su_kien.md`

### Phase 2

- `20260424_15_ban_do_giao_dien_tong_the_va_dieu_huong_chinh.md`
- `20260424_16_dac_ta_man_hinh_quan_ly_trang_va_viewer.md`
- `20260424_17_dac_ta_man_hinh_quan_ly_ho_so_va_khoi_ho_so.md`
- `20260424_18_dac_ta_man_hinh_doc_text_citation_va_review.md`
- `20260424_19_dac_ta_quan_ly_tai_khoan_nguoi_dung_va_phan_quyen.md`

### Phase 3

- `20260424_20_ban_do_luong_chuc_nang_end_to_end.md`

### Phase 4

- `20260424_23_dac_ta_profile_bi_can_luoc_su_va_xet_hoi.md`
- `20260424_25_ban_do_tri_thuc_man_hinh_tom_tat_bi_can.md`

## 4. So Do Quan He Giua Cac File

```text
20260424_13_ke_hoach_phan_ra_phase_va_gate_trien_khai
  -> chi dao thu tu tao file
  -> khoa docs gate

20260424_14_ban_do_thuoc_tinh_metadata_va_schema_nghiep_vu
  -> cap field cho
     -> 20260424_21_dac_ta_luong_scan_ocr_ai_danh_gia_chat_luong
     -> 20260424_22_dac_ta_tach_file_ingest_db_metadata
     -> 20260424_24_ban_do_lien_ket_giua_file_thong_tin_thuc_the_su_kien
     -> 20260424_23_dac_ta_profile_bi_can_luoc_su_va_xet_hoi

20260424_15_ban_do_giao_dien_tong_the_va_dieu_huong_chinh
  -> chia vao
     -> 20260424_16_dac_ta_man_hinh_quan_ly_trang_va_viewer
     -> 20260424_17_dac_ta_man_hinh_quan_ly_ho_so_va_khoi_ho_so
     -> 20260424_18_dac_ta_man_hinh_doc_text_citation_va_review
     -> 20260424_19_dac_ta_quan_ly_tai_khoan_nguoi_dung_va_phan_quyen
     -> 20260424_25_ban_do_tri_thuc_man_hinh_tom_tat_bi_can

20260424_20_ban_do_luong_chuc_nang_end_to_end
  -> noi luong giua data, UI, OCR, AI, review, report

20260424_23_dac_ta_profile_bi_can_luoc_su_va_xet_hoi
  + 20260424_24_ban_do_lien_ket_giua_file_thong_tin_thuc_the_su_kien
  -> tao nen 20260424_25_ban_do_tri_thuc_man_hinh_tom_tat_bi_can
```

## 5. Quy Tac Cho Agent

- Khong tao file ngoai danh sach nay neu chua co ly do ro rang.
- Neu can them file phu, phai ghi ro vao nhat ky va map truoc.
- Neu OpenCode bat dau hoi lai pham vi tong quat, quay lai file prompt goc trong `00_prompt_tho`.
- Sau khi tao xong bo file tren, moi du dieu kien de doi UI/backend/data/AI bat dau scaffold.
