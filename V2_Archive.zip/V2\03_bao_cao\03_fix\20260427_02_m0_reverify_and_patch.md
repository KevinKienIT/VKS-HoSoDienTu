# BAO CAO M0 RE-VERIFY + PATCH (ROO CODE LEADER)

- Thoi gian: 2026-04-27 01:59 GMT+7
- Pham vi: Dong lai M0 (Phase 1 end-to-end) theo lenh Roo Leader
- Nen tang: Tauri Desktop (offline), khong test bang browser workflow

## 1) Muc tieu xu ly

1. Re-verify gate D1 tren codebase hien tai.
2. Sua cac mismatch nho service↔command de bao dam runtime flow.
3. Cap nhat NEXT_ACTION + task board de phan anh dung source-of-truth.

## 2) Patch da ap dung

### 2.1 Python OCR help stability
- File: `PhanMem/python/ocr/ocr_pipeline.py`
- Patch: doi sang lazy import dependency OCR (`paddleocr`, `opencv-python`, `numpy`) qua `load_ocr_dependencies()` de `--help` khong bi phu thuoc import nang.

### 2.2 Frontend import arg mapping
- File: `PhanMem/src/services/importService.ts`
- Patch: map invoke args sang `folder_path` (snake_case) de khop command Rust `import_folder`.

### 2.3 Search DTO + UI filter/sort
- Files:
  - `PhanMem/src-tauri/src/commands/search_cmd.rs`
  - `PhanMem/src/services/searchService.ts`
  - `PhanMem/src/App.tsx`
- Patch:
  - Mo rong `SearchResult` backend/frontend them `document_type`, `created_at`.
  - `SearchFallback` them filter theo loai tai lieu va sort theo relevance/date/name.

## 3) Verify commands va ket qua

1. Rust backend
   - Command: `cargo check -j 1` (cwd `PhanMem/src-tauri`)
   - Ket qua: PASS (0 errors, con dead_code warnings trong `db/schema.rs`)

2. Frontend build
   - Command: `npm run build` (cwd `PhanMem`)
   - Ket qua: PASS (tsc + vite build thanh cong)

3. Python OCR scripts
   - Command: `python -m ocr.pdf_to_images --help` (cwd `PhanMem/python`) -> PASS
   - Command: `python -m ocr.ocr_pipeline --help` (cwd `PhanMem/python`) -> PASS
   - Command: `python -m ocr.summarizer --help` (cwd `PhanMem/python`) -> PASS

4. Tauri runtime gate
   - Command: `npm run tauri:dev` (cwd `PhanMem`)
   - Ket qua: PASS launch (`target\debug\vks-ecms.exe`, co log DB PRAGMA foreign_keys)

## 4) Ket luan milestone

- M0 (dong Phase 1 E2E) da re-verify PASS.
- Status docs da duoc dong bo:
  - `V2/NEXT_ACTION.md`
  - `V2/04_case_dang_lam_viec/20260426_03_task_board_phase1.md`
- Risk con ton:
  - `NotesFallback` trong `App.tsx` van dung localStorage fallback (duoc ghi debt; khong coi la production workflow nghiep vu cho Notes/AI module).

