# BAO CAO UI-REDESIGN (FALLBACK IMPLEMENTATION) — ROO CODE LEADER

- Thoi gian: 2026-04-27 02:53 GMT+7
- Milestone: UI-REDESIGN theo `V2/NEXT_ACTION.md`
- Owner: Roo Code Leader

## 1) Pham vi da lam

### 1.1 Refactor App shell + routing
- Refactor `PhanMem/src/App.tsx`:
  - Sidebar theo điều hướng mới (Dashboard/Hồ sơ/Tài liệu/Tìm kiếm/Review Queue/Import Job/Cài đặt)
  - Header có Global Search
  - Hotkey `Ctrl+K` focus search
  - Routes chính:
    - `/`
    - `/cases`
    - `/cases/:caseId`
    - `/cases/:caseId/docs/:docId`
    - `/documents`
    - `/search`
    - `/reviews`
    - `/import`
    - `/settings`

### 1.2 Tách page components
Đã tạo các file trong `PhanMem/src/components/pages/`:
- `common.tsx`
- `DashboardPage.tsx`
- `CaseListPage.tsx`
- `CaseDetailPage.tsx`
- `DocumentViewerPage.tsx`
- `DocumentListPage.tsx`
- `SearchPage.tsx`
- `ReviewQueuePage.tsx`
- `ImportJobPage.tsx`
- `SettingsPage.tsx`

### 1.3 Notes debt xử lý theo ràng buộc
- Bỏ localStorage cho notes nghiệp vụ.
- Tạo service mới `PhanMem/src/services/appSettingService.ts` dùng:
  - `get_app_settings`
  - `set_app_setting`
- `CaseDetailPage` tab `notes` lưu ghi chú theo key `case_notes::<caseId>` qua SQLite/Tauri command.

### 1.4 Search → Viewer linking
- Backend `fts_search` mở rộng trả `case_id`:
  - `PhanMem/src-tauri/src/commands/search_cmd.rs`
- Frontend DTO cập nhật:
  - `PhanMem/src/services/searchService.ts`
- `SearchPage` và global search điều hướng vào:
  - `/cases/:caseId/docs/:docId`

## 2) Verify

1. Frontend build
- Command: `npm run build` (cwd `PhanMem`)
- Kết quả: PASS

2. Rust backend check
- Command: `cargo check -j 1` (cwd `PhanMem/src-tauri`)
- Kết quả: PASS (chỉ warning dead_code schema constants)

3. Tauri runtime launch
- Command: `npm run tauri:dev` (cwd `PhanMem`)
- Kết quả: PASS launch (`target\\debug\\vks-ecms.exe`, có log DB PRAGMA)

4. localStorage/sessionStorage scan
- Search code trong `PhanMem/src/*.tsx`
- Kết quả: không còn `localStorage/sessionStorage` trong TSX frontend pages sau refactor.

## 3) Scope chưa hoàn tất (đã ghi nhận)

- Một số phần spec advanced đang ở fallback:
  - OCR panel command theo trang (ví dụ `get_page_ocr`) chưa có command thật
  - Review queue dedicated backend command/filter confidence thật chưa có
  - Workspace advanced (`reading_queue`, `bookmark_page`, `contradiction_board`, ...) chưa full

## 4) Kết luận

- UI-REDESIGN fallback đã hoàn tất theo hướng đúng nền tảng Tauri desktop, routes chính đầy đủ, không localStorage cho nghiệp vụ notes, và các gate kỹ thuật chính PASS.
- Sẵn sàng chuyển Codex QA checklist, sau đó đi tiếp M1/M2.

