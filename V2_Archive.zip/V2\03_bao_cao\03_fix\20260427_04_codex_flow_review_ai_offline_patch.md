# 20260427_04 - Codex flow review + AI offline Tier 1 patch

Ngay: 2026-04-27
Agent: Codex
Pham vi: review luong code hien tai, doi chieu V2 reports, va tich hop ngay AI offline toi thieu vao Case Notes.

---

## Ket luan ngan

Huong san pham dang dung: Tauri desktop, SQLite local, offline-first, co shell UI, routes, case/document/search/review/import/settings.

Nhung cac report dang ghi DONE hoi manh hon thuc te code. He thong hien moi o muc khung + fallback UI. Chua nen coi la E2E xu ly ho so that cho den khi dong Import -> OCR -> pages -> FTS -> viewer OCR -> review queue duoc noi kin.

## Phat hien uu tien

### P0 - Import/OCR chua E2E that

- `PhanMem/src-tauri/src/commands/import_cmd.rs:304` dat PDF `page_count = 0`; khong tach PDF thanh pages, khong goi OCR pipeline, khong insert `pages`/`ocr_results`.
- `PhanMem/src/components/pages/ImportJobPage.tsx:37-44` goi `import_folder` xong chuyen step `ocr -> review -> complete` lien tuc, nen UI tao cam giac da xu ly OCR nhung backend chua lam.
- Anh huong: search/AI/review se thieu OCR text, FTS khong co noi dung nghiep vu that.

### P0 - Viewer OCR/Citation panel dang placeholder

- `PhanMem/src/components/pages/DocumentViewerPage.tsx:75-82` tu ghi TODO `get_page_ocr`, hien metadata thay OCR text.
- Chua co frontend service/backend command `get_page_ocr`.
- Anh huong: KSV chua doc duoc OCR theo trang, chua note/citation gan vao doan text that.

### P1 - Review Queue chua co hanh dong nghiep vu

- `PhanMem/src/components/pages/ReviewQueuePage.tsx:20-23` lay document list roi loc status, chua dung bang `review_queue`.
- `PhanMem/src/components/pages/ReviewQueuePage.tsx:41-48` confidence chi la mapping fallback theo status.
- `PhanMem/src/components/pages/ReviewQueuePage.tsx:111-118` cac nut Approve/Edit/Reject/Skip chua co handler.
- Anh huong: khong co audit trail phe duyet/tu choi, khong dong review loop.

### P1 - Notes dung duoc nhung chua dung schema dai han

- `PhanMem/src/components/pages/CaseDetailPage.tsx:61-68` luu notes vao `app_settings` voi key `case_notes::<caseId>`.
- Schema da co cac bang phu hop hon cho work product/audit/citation, nen can chuyen notes sang work product co loai note/question/issue/contradiction va co source anchor.
- Anh huong: agent AI co the doc notes fallback, nhung chua truy vet citation/audit tot.

### P2 - Search snippet can render an toan hon

- `PhanMem/src/components/pages/SearchPage.tsx:145` dung `dangerouslySetInnerHTML` cho snippet FTS.
- SQLite snippet hien duoc sinh tu DB local, rui ro thap hon web input, nhung nen render highlight bang escaped parts de tranh thoi quen nguy hiem.

## UI/UX gop y theo muc tieu "smart nhung lazy click"

1. Nen gom nghiep vu gan nhau theo workspace:
   - Left: case/document list.
   - Center: viewer/page.
   - Right: OCR text + notes + AI Notebook + review action.
2. Notes phai nam sat tai lieu/OCR/citation, khong tach thanh mot page xa. Patch hien tai da dat AI Notebook canh notes trong Case Detail.
3. Dashboard nen co "Continue Working" that tu last opened/import/review queue thay vi card tinh.
4. Import page can hien job progress that tu `import_jobs`, khong nhay step neu OCR chua chay.
5. Review action can dat ngay canh bang chung: source page, OCR excerpt, confidence, approve/reject/edit/skip, audit event.

## Patch da thuc hien

Them AI offline Tier 1, khong goi network ngoai may:

- `PhanMem/src-tauri/src/commands/ai_cmd.rs`
  - `ai_check_status`: chi check `127.0.0.1:11434` de biet Ollama local co dang nghe khong.
  - `ai_summarize_case`: tom tat extractive tu SQLite: case, notes, documents, pages OCR.
  - `ai_ask_case`: keyword match offline tren notes/metadata/OCR, tra ve cau tra loi + sources.
- `PhanMem/src-tauri/src/commands/mod.rs`: register module `ai_cmd`.
- `PhanMem/src-tauri/src/main.rs`: register 3 Tauri commands AI.
- `PhanMem/src/services/aiService.ts`: safeInvoke wrapper cho AI commands.
- `PhanMem/src/components/pages/AiNotebookPanel.tsx`: panel AI Notebook offline.
- `PhanMem/src/components/pages/CaseDetailPage.tsx`: tab Notes thanh 2 cot, notes ben trai va AI Notebook ben phai.

Gioi han hien tai: day la Tier 1 extractive offline SQLite, chua goi local LLM de sinh cau tra loi tu Ollama. Tuy nhien no da dung yeu cau offline va co source de agent/KSV xem lai.

## Verify

- `cargo check -j 1` trong `PhanMem/src-tauri`: PASS, con 46 warning dead_code cu trong schema constants.
- `npm run build` trong `PhanMem`: PASS, con warning chunk size/pdf worker cu.

## Lenh tiep theo cho Roo Code Leader

1. Khoa Phase B lam truoc Phase A neu muon AI/search/review co gia tri: them `get_page_ocr`, noi OCR pipeline vao import, insert `pages`/`ocr_results`, rebuild FTS.
2. Sau khi OCR co data that, lam Review Queue bang `review_queue` + commands approve/reject/edit/skip + audit_events.
3. Di chuyen notes tu `app_settings` sang work product/citation-aware schema, giu migration/backward compatibility doc key `case_notes::<caseId>`.
4. Cuoi cung moi polish keyboard/zoom/viewer controls de tranh lam dep tren data gia.
