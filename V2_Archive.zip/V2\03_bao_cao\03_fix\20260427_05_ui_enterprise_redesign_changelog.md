# UI ENTERPRISE REDESIGN — CHANGELOG & GUIDE

Ngày: 2026-04-27 12:14 GMT+7
Agent: Antigravity
Verify: `npm run build` ✅ PASS (90 modules, 623ms)
Files đã sửa: **10 files** (3 CSS + 7 TSX)

---

## TÓM TẮT

Nâng cấp toàn bộ giao diện từ mức prototype lên **enterprise-grade desktop workspace**.
Nguyên tắc: dense-but-readable, lazy form (ít click), professional indigo palette, không gradient trên card, không emoji lạm dụng.

---

## FILES ĐÃ SỬA (10 files)

### 1. `src/styles/variables.css` — ĐÃ SỬA HOÀN TOÀN

**Trước**: 92 dòng, thiếu ghost/surface color variants, shadow limited.
**Sau**: ~110 dòng enterprise design tokens.

| Thay đổi | Chi tiết |
|----------|---------|
| Thêm `--color-primary-ghost`, `--color-primary-surface` | Dùng cho hover/selected states |
| Thêm `--color-*-surface` cho success/warning/danger/info | Background màu nhạt cho badges |
| Thêm `--color-bg-muted`, `--color-bg-selected` | Cho table header, selected rows |
| Thêm `--color-border-strong` | Cho hover borders |
| Thêm `--color-text-link` | Link color riêng |
| Thêm `--text-2xs: 10px`, `--text-3xl: 28px` | Mở rộng scale typography |
| Thêm `--space-0_5`, `--space-1_5`, `--space-2_5`, `--space-12` | Micro spacing |
| Sidebar thu hẹp: `220px` → `52px` collapsed | Compact hơn |
| Header thu hẹp: `48px` → `44px` | Tiết kiệm vertical space |
| Footer thu hẹp: `28px` → `26px` | Tiết kiệm vertical space |
| Thêm `--shadow-xs`, `--shadow-xl`, `--shadow-ring` | Ring focus cho accessibility |
| Transitions nhanh hơn: `120ms` → `100ms` | Responsive feel |

### 2. `src/styles/layout.css` — ĐÃ SỬA HOÀN TOÀN

**Trước**: 441 dòng, basic layout + card + table + badge.
**Sau**: ~550 dòng enterprise layout system.

| Module CSS | Thay đổi |
|-----------|---------|
| **Header** | Thêm `.header-brand`, `.header-brand-icon`, `.header-search` (command palette style với icon + hint Ctrl+K), `.header-action-btn` |
| **Sidebar** | Thêm `.sidebar-item-badge` (notification count), `.sidebar-item.active::before` (accent-line indicator) |
| **Cards** | Thêm `.card-interactive` (hover border + shadow), `.card-subtitle`, `.stat-card` với `::before` accent-top border, `.stat-value`, `.stat-label`, `.stat-change` |
| **Buttons** | Thêm `.btn-success`, `.btn-danger`, `.btn-ghost`, `.btn-lg`, `.btn-icon`, `:active` scale, `:focus-visible` ring |
| **Tables** | Table header sticky, `.data-table tbody tr.selected`, vertical-align middle |
| **Badges** | Thêm `.badge-primary`, dùng `--radius-sm` thay vì full-round |
| **Forms** | MỚI: `.form-input`, `.form-textarea`, `.form-select`, `.form-label`, `.form-group`, `.form-hint` — enterprise form system |
| **Tabs** | MỚI: `.tab-bar`, `.tab-item`, `.tab-item.active` — underline tab system |
| **Toolbar** | MỚI: `.toolbar`, `.toolbar-separator`, `.toolbar-spacer` |
| **Viewer** | MỚI: `.viewer-empty-state` |
| **Animation** | Thêm `.slide-in`, fadeIn giảm từ 4px → 3px |
| **Utilities** | MỚI: `.text-muted`, `.text-secondary`, `.text-xs`, `.text-sm`, `.text-mono`, `.font-semibold`, `.font-bold`, `.mt-*`, `.mb-*`, `.gap-*`, `.flex`, `.flex-col`, `.items-center`, `.justify-between`, `.grid`, `.truncate` |

### 3. `src/styles/dossier-nav.css` — ĐÃ SỬA HOÀN TOÀN

**Trước**: 223 dòng, dossier tab stacking effect + fold animation.
**Sau**: ~120 dòng clean rail navigation.

| Thay đổi | Chi tiết |
|----------|---------|
| Bỏ stacking indent (`nth-child` margin) | Gây lệch visual |
| Bỏ `::after` fold effect | Quá decorative |
| Bỏ `::before` right border | Không cần |
| Active tab: accent-line 3px bên trái (amber) | Thay vì background bleed |
| Icon opacity reduced: 0.6 default, 1.0 active | Subtler |
| Page number: ẩn mặc định, chỉ hiện khi hover | Bớt noise |
| Collapsed state: đơn giản hơn, không box-shadow | Cleaner |

### 4. `src/App.tsx` — ĐÃ SỬA HOÀN TOÀN

**Trước**: 191 dòng, emoji icons, inline search style, basic footer.
**Sau**: ~170 dòng enterprise shell.

| Thay đổi | Chi tiết |
|----------|---------|
| Nav icons: emoji → Unicode symbols | `📊` → `◫`, `📁` → `◰`, `🔍` → `⌕`, `📝` → `☑`, `📥` → `⇩` |
| Bỏ `page` number trong nav items | Không cần |
| Header: thêm `.header-brand` với icon | Enterprise branding |
| Search: inline style → `.header-search-input` + icon + hint | Command palette look |
| Search logic: tách thành `handleSearch()` function | Clean code |
| Footer: "Online"/"Offline" → "Desktop Runtime"/"Browser Preview" | Rõ nghĩa hơn |
| Footer: statusText hiện "Tauri v2" / "No Tauri API" | Rõ nghĩa hơn |
| Thêm notification bell button | Enterprise element |

### 5. `src/components/pages/DashboardPage.tsx` — ĐÃ SỬA HOÀN TOÀN

**Trước**: 66 dòng, 3 stat cards + empty continue reading + empty workspace card.
**Sau**: ~115 dòng enterprise dashboard.

| Thay đổi | Chi tiết |
|----------|---------|
| 4 stat cards với accent-top border | Hồ sơ (primary), Tài liệu (info), Catalog (success), Chờ review (warning) |
| Stat cards link to pages | Click → navigate |
| Recent documents list | Load 5 tài liệu gần nhất, click → viewer |
| Quick actions panel | 4 action buttons (Import, Hồ sơ, Tìm kiếm, Review) |
| Bỏ EmptyCard "milestone kế tiếp" | Thay bằng content thật |
| Import `documentService` | Load doc count + recent docs |

### 6. `src/components/pages/CaseDetailPage.tsx` — ĐÃ SỬA HOÀN TOÀN

**Trước**: 199 dòng, button tabs in card, inline styles for everything.
**Sau**: ~195 dòng enterprise tabs + cleaner layout.

| Thay đổi | Chi tiết |
|----------|---------|
| Tabs: `btn btn-sm` in card → `.tab-bar` + `.tab-item` | Underline tab system |
| Tab label "Ghi chú" → "Ghi chú & AI" | Rõ nghĩa hơn |
| Overview: single text → stat grid (3 cols) | Status badge + doc count + page count |
| Documents table: thêm column widths | Fixed widths cho Loại/Trang/Trạng thái/Ngày |
| Status badges: text → `.badge` with color | reviewed=success, error=danger |
| Dossier: smaller avatar (100px), grid layout | Cleaner |
| Notes textarea: inline style → `.form-textarea` | Enterprise form |
| Back button: "← Danh sách hồ sơ" → "← Danh sách" | Shorter |

---

### 7. `src/components/pages/CaseListPage.tsx` — ĐÃ SỬA HOÀN TOÀN

| Thay đổi | Chi tiết |
|----------|--------|
| Thêm status filter toolbar | Tất cả / Đang xử lý / Lưu trữ / Đã đóng |
| Status badges với color mapping | active=success, closed=neutral, archived=warning |
| Case code dùng `text-mono` | Monospace font cho mã vụ án |
| Table flush (card padding 0) | Clean table edge |
| Column widths fixed | Mã(120), Trạng thái(90), Tài liệu(60), Ngày(140) |
| Filter count + empty filter message | "X/Y hồ sơ" |

### 8. `src/components/pages/ImportJobPage.tsx` — ĐÃ SỬA HOÀN TOÀN

| Thay đổi | Chi tiết |
|----------|--------|
| Step indicator (StepIndicator component) | Numbered circles + connecting lines, green check khi done |
| Centered empty state | Icon + text + large CTA button |
| Spinner khi importing | module-spinner + text |
| Result stat grid | Job ID, Total files, Case ID — monospace |
| File result table | Tên, Ext badge, Size (KB), Pages |
| Link "Mở hồ sơ vừa import" | Navigate sau complete |
| Bỏ fake progress bar % | Dùng step indicator thay thế |

### 9. `src/components/pages/ReviewQueuePage.tsx` — ĐÃ SỬA HOÀN TOÀN

| Thay đổi | Chi tiết |
|----------|--------|
| Toolbar thay card wrapper | `.toolbar` với `.form-select` |
| Item count | "X/Y items" bên phải toolbar |
| Status badges tiếng Việt | Lỗi(danger), Đã xử lý(info), Chờ xử lý(warning), Đã duyệt(success) |
| Two-line doc cell | Display name + document_type |
| Color-coded action buttons | Duyệt(success), Sửa(ghost), Từ chối(danger) |
| Column widths | Loại(40), Trang(50), Trạng thái(100), Hành động(220) |

### 10. `src/components/pages/SearchPage.tsx` — ĐÃ SỬA HOÀN TOÀN

| Thay đổi | Chi tiết |
|----------|--------|
| Safe snippet rendering | `safeSnippet()` escapes HTML, restores `<mark>` for FTS highlight |
| Toolbar search bar | `.form-input` + `.form-select` trong `.toolbar` |
| Card-based results | Thay table bằng card list, hover effect |
| Score + type badges | `.badge-primary` cho score, `.badge-neutral` cho type |
| Empty state centered | Icon + title + description |
| Bỏ `dangerouslySetInnerHTML` không safe | Dùng `safeSnippet()` |

### 11. `src/components/pages/AiNotebookPanel.tsx` — ĐÃ SỬA HOÀN TOÀN

| Thay đổi | Chi tiết |
|----------|--------|
| Status badge | `.badge-success`/`.badge-neutral` thay plain text |
| `.form-textarea` | Thay inline border styles |
| Answer code-block style | Background muted + border + padding |
| Source cards compact | Flat background, small border, no nested cards |
| "Nguồn tham chiếu" label | `.stat-label` uppercase |

---

## FILES CHƯA SỬA GIAO DIỆN (cần sửa tiếp)

| File | Trạng thái | Ghi chú |
|------|-----------|--------|
| `DocumentListPage.tsx` | ⬜ Chưa sửa | Cần dùng `.data-table` mới, toolbar |
| `DocumentViewerPage.tsx` | ⬜ Chưa sửa | Cần dùng `.toolbar`, `.card` mới |
| `DocumentViewer.tsx` | ⬜ Chưa sửa | PDF toolbar cần dùng `.toolbar` class |
| `SettingsPage.tsx` | ⬜ Chưa sửa | Toggle CSS cần extract ra class, dùng `.form-group` |
| `common.tsx` | ⬜ Chưa sửa | Có thể thêm common components |

---

## HƯỚNG DẪN CHO AGENT TIẾP THEO

### Nguyên tắc khi sửa UI các page còn lại:

1. **Dùng CSS classes** đã có trong `layout.css`, KHÔNG viết inline styles mới trừ layout grid cụ thể
2. **Badges cho status**: dùng `.badge-success` (reviewed), `.badge-warning` (pending), `.badge-danger` (error), `.badge-neutral` (mặc định)
3. **Forms**: dùng `.form-input`, `.form-textarea`, `.form-select`, `.form-label`, `.form-group`
4. **Tables**: card wrapper `padding: 0; overflow: hidden`, table dùng `.data-table`, header sticky
5. **Tabs**: dùng `.tab-bar` + `.tab-item` + `.tab-item.active`
6. **Buttons**: `.btn` mặc định, `.btn-primary` cho action chính, `.btn-ghost` cho secondary, `.btn-sm` cho compact, `.btn-icon` cho icon-only
7. **Stat cards**: `.card.stat-card` + `data-accent="primary|success|warning|danger|info"`
8. **Icons**: Unicode symbols thay vì emoji (◫ ◰ ▤ ⌕ ☑ ⇩ ⚙)
9. **Utilities**: `.text-muted`, `.text-xs`, `.truncate`, `.mb-3`, `.mt-2` etc.
10. **Spacing**: Ưu tiên `var(--space-*)`, không hardcode px

### Build verify:
```bash
npm run build
```
Phải PASS trước và sau mỗi file sửa.

---

## ĐẶC TẢ CHO CÁC PAGE CÒN LẠI

### DocumentListPage
- Table: `.data-table` trong `.card` padding 0
- Giống CaseListPage nhưng cho documents
- Toolbar: filter by type, sort by date/name
- Group by case (collapse/expand nếu có thể)

### DocumentViewerPage
- Split panel: `.toolbar` cho viewer controls (zoom, page nav)
- OCR panel: `.card` với `.card-title`, confidence `.badge`
- Mode toggle: `.btn-ghost` group cho view mode

### DocumentViewer (PDF viewer component)
- Toolbar controls: `.toolbar` class thay inline styles
- Page counter: `.text-mono`
- Zoom buttons: `.btn-icon`

### SettingsPage
- Toggle CSS: extract inline switch styles ra `.toggle-switch` class
- Module cards: dùng `.form-group` layout
- Version badge: `.badge-info`

---

## CODEx UPDATE — SMART DASHBOARD OPTIMIZATION

Ngày: 2026-04-27
Agent: Codex
Verify: `npm run build` ✅ PASS
Files sửa thêm:

- `src/components/pages/DashboardPage.tsx`
- `src/styles/layout.css`

### Mục tiêu

Tối ưu màn hình chính theo hướng **smart nhưng lazy click**: nhiều thông tin nghiệp vụ nằm ngay trên dashboard, ưu tiên việc cần xử lý, hạn chế phải đi qua nhiều menu.

### Thay đổi chính

| Khu vực | Thay đổi |
|---------|----------|
| Tiếp tục xử lý | Tự chọn tài liệu cần xử lý ưu tiên từ `status != reviewed`; nếu chưa có thì dẫn import |
| Tín hiệu hệ thống | Hiện số item cần review, catalog chưa import, trạng thái AI offline/local |
| Stat grid | Từ 4 card lên 6 card: hồ sơ, tài liệu, tổng trang, chờ review, catalog, backlog |
| Worklist ưu tiên | Danh sách 6 tài liệu cần xử lý, click thẳng vào viewer |
| Quick actions | Import, hồ sơ, tìm kiếm, review đặt trong panel compact 2x2 |
| Loại tài liệu | Hiển thị nhóm tài liệu từ `getDocumentGroups()` ngay trên dashboard |
| Hồ sơ gần đây | Bảng compact 5 hồ sơ gần nhất, click vào case |
| Tài liệu gần đây | 6 tài liệu gần nhất, click vào viewer |
| CSS | Thêm dashboard layout classes responsive, không tiếp tục tăng inline style |

### Nguồn dữ liệu đang dùng

- `caseService.listCases()`
- `documentService.listDocuments()`
- `documentService.getDocumentGroups()`
- `useCatalogStore.fetchStats()`
- `aiService.checkAiStatus()`

### Giới hạn còn lại

- Chưa có `last_viewed` thật vì chưa có command/session persistence; dashboard dùng tài liệu cần review hoặc tài liệu mới nhất làm "Tiếp tục xử lý".
- Chưa có import job summary thật vì `list_import_jobs/get_import_job` chưa được làm.
- Review count vẫn dựa trên document status, chưa phải bảng `review_queue` thật.
