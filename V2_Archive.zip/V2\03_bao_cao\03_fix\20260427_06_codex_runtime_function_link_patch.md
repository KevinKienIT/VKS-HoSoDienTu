# 20260427_06 - Codex runtime guard + function link patch

Ngay: 2026-04-27
Agent: Codex
Pham vi: sua loi can ban de UI/Tauri compile, chan sai huong browser preview, noi cac function co san vao SQLite/Tauri command.

---

## Ket qua

- Frontend build: `npm run build` PASS.
- Backend check: `cargo check -j 1` PASS.
- NPM outdated: `{}` sau khi nang cac package npm len latest theo registry.
- `npm run dev` da bi chan chu dong, in canh bao sai huong va exit 1.

## Sua loi nen tang

### 1. Chan sai huong browser preview

- `package.json`
  - `dev` khong con chay Vite truc tiep.
  - Them `dev:tauri-vite` cho Tauri internal dev server.
  - Them `dev:ui-preview` chi de xem CSS/layout, co warning ro.
- `src-tauri/tauri.conf.json`
  - `beforeDevCommand` doi sang `npm run dev:tauri-vite`.
- Them:
  - `PhanMem/scripts/deny-browser-dev.mjs`
  - `PhanMem/scripts/warn-ui-preview.mjs`
- `App.tsx`
  - Runtime detection dung `__TAURI_INTERNALS__`, khong con coi browser import duoc `@tauri-apps/api` la runtime that.
  - Hien banner canh bao "Sai huong chay: Browser Preview" khi khong co Tauri runtime.

### 2. Noi Review Queue action toi SQLite

- Them Rust command `update_document_status` trong `doc_cmd.rs`.
- Register command trong `main.rs`.
- Them frontend wrapper `documentService.updateDocumentStatus`.
- `ReviewQueuePage`:
  - Nut `Duyet` cap nhat document status thanh `reviewed`.
  - Nut `Tu choi` cap nhat status thanh `error`.
  - Nut `Sua` mo viewer.
  - Command ghi them `audit_events` voi actor `desktop-ui`.

Gioi han: day la fallback document-status review. Chua thay the bang bang `review_queue` that. Phase sau van phai lam `review_cmd.rs`/`reviewService.ts`.

### 3. Noi Viewer OCR panel toi SQLite

- Them Rust command `get_page_ocr(document_id, page_index)`.
- Register command trong `main.rs`.
- Them frontend wrapper `documentService.getPageOcr`.
- `DocumentViewer` them `onPageChange`.
- `DocumentViewerPage` doc OCR theo trang hien tai va hien confidence/but_luc/transcription_state neu DB co data.

Gioi han: OCR pipeline van chua fill text that. Panel da noi command, nhung can Phase OCR ghi `pages.ocr_text`.

## Version modules

### NPM

Da nang cac package outdated len latest registry:

- `react` / `react-dom`: 19.2.5
- `react-router-dom`: 7.14.2
- `framer-motion`: 12.38.0
- `zustand`: 5.0.12
- `pdfjs-dist`: 5.6.205
- `typescript`: 6.0.3
- `@types/node`: 25.6.0
- `@types/react`: 19.2.14
- `@types/react-dom`: 19.2.3

`npm outdated --json` hien tra `{}`.

### Rust/Cargo

- `tauri`: 2.10.3
- `lopdf`: 0.40.0
- `rusqlite`: 0.32.1

`rusqlite` latest la 0.39.0, nhung khong the dung trong project hien tai vi xung dot native `libsqlite3-sys` voi `tauri-plugin-sql/sqlx`. Ban moi nhat compile duoc voi graph hien tai la `rusqlite 0.32.1` cung `libsqlite3-sys 0.30.1`.

## Viec con lai

1. Lam OCR pipeline that: Python OCR -> `pages.ocr_text` + `ocr_results` + FTS rebuild.
2. Lam Review Queue that: `review_cmd.rs`, `reviewService.ts`, dung bang `review_queue`.
3. Bo cac prompt/alert browser-style o cac page quan tri va thay bang Tauri dialog/modal/toast.
4. Chay `npm run tauri:dev` de test chuc nang trong WebView, khong dung browser.
