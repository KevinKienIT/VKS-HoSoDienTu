# Kế hoạch đóng gói và triển khai giao diện VKS ECMS

Tôi đã xử lý toàn bộ các lỗi ngăn cản quá trình đóng gói (build) ứng dụng. Hiện tại, cả Frontend và Backend đều đã sẵn sàng để tạo file cài đặt (.exe).

## 1. Các lỗi đã xử lý
- **Frontend (TypeScript)**:
  - Khắc phục lỗi `baseUrl` bị phản đối trong `tsconfig.json`.
  - Tạo `src/vite-env.d.ts` để định nghĩa kiểu cho các file CSS và tài sản Vite, sửa lỗi "Cannot find module" khi import CSS.
- **Backend (Rust/Tauri)**:
  - Giải quyết xung đột phiên bản `libsqlite3` giữa `tauri-plugin-sql` và `rusqlite` bằng cách hạ cấp `rusqlite` về bản ổn định `0.31`.
  - Loại bỏ các định nghĩa trùng lặp của `PageOcrResult` và `get_page_ocr` trong `doc_cmd.rs`.
  - Dọn dẹp `main.rs` để loại bỏ các tham chiếu đến module chưa tồn tại (`review_cmd`), đảm bảo code compile thành công.

## 2. Trạng thái hiện tại
- **Frontend Build**: ✅ PASS (`npm run build` thành công)
- **Backend Check**: ✅ PASS (`cargo check` thành công với 0 lỗi)

## 3. Cách chạy / Build ứng dụng lên

Để xem giao diện thực tế và kiểm tra chức năng trong môi trường Tauri, bạn hãy chạy lệnh sau trong terminal:

```powershell
# Chạy ở chế độ Development (mở cửa sổ ứng dụng desktop)
npm run tauri dev
```

Để tạo bản cài đặt chính thức (.exe):

```powershell
# Đóng gói ứng dụng thành file .exe (mất khoảng 5-10 phút)
npm run tauri build
```

## 4. Giao diện Dashboard mới (Codex Update)
Dashboard đã được tối ưu hóa theo hướng **"Smart & Lazy Click"**:
- **Tiếp tục xử lý**: Tự động gợi ý tài liệu ưu tiên.
- **Tín hiệu hệ thống**: Hiển thị số lượng Review còn thiếu, trạng thái AI và Catalog.
- **Quick Actions**: Bảng điều hướng nhanh 2x2 (Import, Case, Search, Review).
- **Recent Items**: Danh sách Hồ sơ và Tài liệu mới nhất ngay trên màn hình chính.

---
**Lưu ý**: Do đây là ứng dụng Desktop (Tauri), việc xem qua trình duyệt web sẽ bị hạn chế chức năng. Hãy luôn dùng `npm run tauri dev` để có trải nghiệm đầy đủ nhất.
