# ROO CODE — PLAN REVIEW TRUOC KHI IMPLEMENT (PHASE 3-5)

Ngay: 2026-04-27
Muc tieu: Co plan review code truoc khi lam, ve map giao dien + luong code, xac dinh bug-risk va gate verify.

---

## 1) CODE REVIEW CHECKLIST (PRE-IMPLEMENT)

1. Kiem tra ranh gioi Tauri desktop:
   - Frontend chi goi `invoke` qua safe pattern, khong dung browser data APIs cho nghiep vu.
   - Runtime test bang `npm run tauri dev` (khong dung browser-only de test logic).
2. Kiem tra schema truoc khi viet query:
   - `ocr_results`: cot text la `raw_text` (khong phai `ocr_text`), khong co `document_id`.
   - `review_queue`: schema object-based (`object_type`, `object_id`, `reason`, `status`), khong phai layout `review_type/document_id` thuần.
   - `audit_events`: action_type bi rang buoc enum (`approve/reject/update/...`).
3. Kiem tra invoke registration:
   - Command moi phai co trong `commands/mod.rs` va `main.rs`.
4. Kiem tra frontend wiring:
   - Service TS + page/component phai dong bo payload snake_case/camelCase theo Tauri.
5. Kiem tra fallback & error handling:
   - Moi service phai fallback null/[] khong crash UI.

---

## 2) UI MAP (MAN HINH + LUONG DIEU HUONG)

```
App Shell
├─ Dashboard
├─ Cases
│  └─ Case Detail
│     └─ Document Viewer (/cases/:caseId/docs/:docId)
│        ├─ Viewer panel (PDF/Image)
│        └─ OCR panel (get_page_ocr theo currentPage)
├─ Documents
│  └─ Catalog/Index tools
├─ Search
├─ Review Queue
│  ├─ list_review_queue
│  └─ review_action (approve/reject/skip)
├─ Import
└─ Settings
```

---

## 3) CODE FLOW MAP (RUST ↔ TS ↔ UI)

### 3.1 Import/OCR/FTS flow

```
ImportJobPage -> importService.importFolder()
  -> Tauri command import_folder (import_cmd.rs)
     -> insert documents
     -> insert pages
     -> insert ocr_results placeholder (pending)
     -> insert fts_documents row
     -> create review_queue entry
  -> SQLite updated
  -> SearchPage / Viewer read data that
```

### 3.2 Viewer OCR flow

```
DocumentViewerPage (docId + currentPage)
  -> documentService.getPageOcr(docId, page)
  -> command get_page_ocr (doc_cmd.rs)
  -> query pages + ocr_results
  -> return ocr_text/confidence/engine
  -> render OCR panel
```

### 3.3 Review Queue flow

```
ReviewQueuePage
  -> reviewService.listReviewQueue(status?)
  -> command list_review_queue (review_cmd.rs)
  -> query review_queue JOIN documents/pages
  -> render queue rows

Action button
  -> reviewService.reviewAction(reviewId, action, note)
  -> command review_action
  -> update review_queue.status + resolved_at
  -> insert audit_events
  -> reload queue
```

---

## 4) BUG-RISK FORECAST + FIX STRATEGY

1. **Schema mismatch risk** (`ocr_text` vs `raw_text`, review schema drift):
   - Fix bang query/insert dung ten cot schema 001.
2. **Invoke mismatch risk**:
   - Soat lai command name 1-1 giua Rust handler va TS service.
3. **UI stale state risk**:
   - Sau action review, reload queue thay vi optimistic-only.
4. **FTS drift risk**:
   - Insert vao `fts_documents` ngay khi import + giu command rebuild cho truong hop full sync.

---

## 5) GATE VERIFY SAU IMPLEMENT

1. Rust gate: `cargo check -j 1`
2. Frontend gate: `npm run build`
3. Rust test gate: `cargo test -j 1 --lib`
4. Runtime gate: `npm run tauri dev` (xac nhan command invoke + OCR panel + review action)

---

Trang thai: **Plan review da co, du dieu kien implement theo thu tu Task 13-33.**

