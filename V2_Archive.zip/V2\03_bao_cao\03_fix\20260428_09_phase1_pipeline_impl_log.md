# 20260428_09 — Phase 1 Pipeline Foundation Implementation Log

## Scope confirmation
- Time: 2026-04-28T11:50:00+07:00 (approx)
- Scope locked to Phase 1 foundation only:
  - DB migration tables: `pipeline_jobs`, `pipeline_tasks`, `pipeline_events`, `pipeline_checkpoints`
  - Rust command scaffolding lifecycle APIs
  - Register commands
  - Frontend `scanService` scaffolding (DTO + safe invoke wrappers)
  - Structured logs + `pipeline_events` persistence on major transitions
  - Verification commands and output logging

## Work trace

### Step 1
- Timestamp: 2026-04-28T11:51:21+07:00
- Files changed:
  - `PhanMem/src-tauri/migrations/004_pipeline_phase1.sql`
- Reason:
  - Create Phase 1 DB schema foundation for async scan pipeline lifecycle and audit trail.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added `pipeline_jobs`, `pipeline_tasks`, `pipeline_events`, `pipeline_checkpoints`.
  - Added status constraints, relational FKs, and supporting indexes.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 2
- Timestamp: 2026-04-28T11:51:34+07:00
- Files changed:
  - `PhanMem/src-tauri/src/db/mod.rs`
- Reason:
  - Register migration `004_pipeline_phase1.sql` in DB init flow.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added `MIGRATION_004` include.
  - Added execution of migration 004 in init sequence.
  - Added migration test asserting content contains `pipeline_jobs`.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 3
- Timestamp: 2026-04-28T11:52:08+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Add Phase 1 lifecycle API scaffolding + structured Rust logging + `pipeline_events` persistence.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added DTO structs: `PipelineJob`, `PipelineJobListItem`, `PipelineFooterStatus`.
  - Added helper persistence function to write major transitions into `pipeline_events`.
  - Added lifecycle commands:
    - `start_pipeline_job`
    - `get_pipeline_job`
    - `list_pipeline_jobs`
    - `pause_pipeline_job`
    - `resume_pipeline_job`
    - `cancel_pipeline_job`
    - `get_pipeline_footer_status`
  - Added Rust logs (`info/warn/error`) with `job_id` and transition traces.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 4
- Timestamp: 2026-04-28T11:52:18+07:00
- Files changed:
  - `PhanMem/src-tauri/src/main.rs`
- Reason:
  - Register new pipeline commands in Tauri invoke handler.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added all 7 pipeline Phase 1 command registrations.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 5
- Timestamp: 2026-04-28T11:52:30+07:00
- Files changed:
  - `PhanMem/src/services/scanService.ts`
- Reason:
  - Add frontend typed DTOs and `safeInvoke` wrappers for pipeline lifecycle APIs.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added TS interfaces: `PipelineJob`, `PipelineJobListItem`, `PipelineFooterStatus`.
  - Added wrappers:
    - `startPipelineJob`
    - `getPipelineJob`
    - `listPipelineJobs`
    - `pausePipelineJob`
    - `resumePipelineJob`
    - `cancelPipelineJob`
    - `getPipelineFooterStatus`
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 6
- Timestamp: 2026-04-28T11:52:59+07:00
- Files changed:
  - N/A (verification run)
- Reason:
  - Validate Rust compile state for Phase 1 changes.
- Command run:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`)
- Output summary:
  - Initial run failed with Rust borrow checker error `E0505` in `scan_cmd.rs`.
  - Root cause: returning `get_pipeline_job(db, job_id)` while DB mutex guard still alive.
- Issues encountered:
  - `cannot move out of db because it is borrowed` at `start/pause/resume/cancel` command return paths.
- Fix applied:
  - Added internal helper `load_pipeline_job(&Connection, &str)` and switched return paths to use the same locked connection.

### Step 7
- Timestamp: 2026-04-28T11:54:03+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Apply borrow-check fix and re-validate build.
- Command run:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`)
- Output summary:
  - Success. `Finished dev profile` without errors.
- Issues encountered:
  - None after fix.
- Fix applied:
  - N/A.

### Step 8
- Timestamp: 2026-04-28T11:58:10+07:00
- Files changed:
  - N/A (verification run)
- Reason:
  - Verify full Tauri production build path (frontend build + Rust release + bundle).
- Command run:
  - `npm run tauri:build` (cwd: `PhanMem`)
- Output summary:
  - Success.
  - Vite build completed.
  - Rust `release` build completed.
  - NSIS installer created at:
    - `PhanMem/src-tauri/target/release/bundle/nsis/VKS - Hồ Sơ Điện Tử_1.0.0_x64-setup.exe`
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

## Verification
- `cargo check -j 1` in `PhanMem/src-tauri` → PASS
- `npm run tauri:build` in `PhanMem` → PASS

---

# 20260428_14 — Regression targeted hardening (file-lock + OCR env)

## Scope confirmation
- Time: 2026-04-28T14:50:00+07:00 (approx)
- Scope locked to minimal safe hardening only:
  - Windows-friendly file-lock retry/backoff at critical FS ops (purge/rename/export)
  - OCR runtime environment validation + richer diagnostics in Rust bridge
  - Structured diagnostics fields for file-lock and OCR env
  - Re-verify build gates (`cargo check -j 1`, `npm run tauri:build`)

## Exact changed files
- `PhanMem/src-tauri/src/commands/case_cmd.rs`
- `PhanMem/src-tauri/src/commands/doc_cmd.rs`
- `PhanMem/src-tauri/src/commands/export_cmd.rs`
- `V2/03_bao_cao/03_fix/20260428_09_phase1_pipeline_impl_log.md`
- `V2/03_bao_cao/03_fix/20260428_10_phase_next_task_checklist.md`

## What was hardened

### 1) File-lock handling hardening
- `case_cmd.rs`:
  - Added retry-with-backoff wrappers for file and cache-dir deletion paths in purge lifecycle.
  - Added lock detection for Windows error codes (`32`, `33`).
  - Added non-destructive fallback on locked-file delete: deferred marker `*.lockdelete.pending` written instead of hard destructive failure.
  - Added structured error payload strings in `errors[]` including: `path`, `op`, `attempt`, `wait_ms`, `final_error`.
- `doc_cmd.rs`:
  - Added retry-with-backoff rename wrapper for dossier document rename path.
  - Added structured lock error code for rename failures (`RENAME_FILE_LOCKED`) with operation metadata.
- `export_cmd.rs`:
  - Added retry-with-backoff wrapper when saving export output PDF.
  - Added structured lock error code (`EXPORT_SAVE_FILE_LOCKED`) with operation metadata.

### 2) OCR environment hardening
- `doc_cmd.rs` (`run_python_json` path):
  - Added preflight script presence validation for Python modules used by OCR bridge (`ocr.pdf_to_images`, `ocr.ocr_pipeline`).
  - Added language configuration validation (`vie|eng|vie+eng`) for OCR invocations.
  - Enforced UTF-8 execution env (`PYTHONUTF8=1`, `PYTHONIOENCODING=utf-8`) with explicit diagnostics retained.
  - Added explicit structured diagnostics in errors for missing executable/script/lang mismatch and execution/parse failures:
    - `python_path`, `script_path`, `lang`, `stderr_snippet`, `exit_status`.
  - Added timeout-like symptom signalization via warning logs when stderr contains `timeout/timed out`.
- OCR API contract remained backward compatible (`run_ocr_for_document*` signatures unchanged).

### 3) Diagnostic logging fields added
- File-lock diagnostics emitted in warning logs and/or structured error strings with fields:
  - `path`, `op`, `attempt`, `wait_ms`, `final_error`.
- OCR env diagnostics emitted in error payloads and warnings with fields:
  - `python_path`, `script_path`, `lang`, `stderr_snippet`, `exit_status`.

## Verification output summary
- `cargo check -j 1` (cwd `PhanMem/src-tauri`) → PASS
  - `Finished dev profile [unoptimized + debuginfo] target(s) in 6.69s`
- `npm run tauri:build` (cwd `PhanMem`) → PASS (confirmed from active build terminal completion)

## Residual risks
- Deferred-delete marker files (`*.lockdelete.pending`) require later cleanup pass/maintenance policy to fully remove locked artifacts.
- Timeout diagnostics currently infer from stderr text patterns; if Python toolchain emits non-standard timeout text, classification may be partial (error still surfaced with structured details).

## Final status
- Completed for approved Phase 1 scope only.
- No Phase 2+ concurrency engine work started.

---

# 20260428_15 — Dossier create/import/sort + OCR metadata auto-sync fix

## Scope confirmation
- Time: 2026-04-28T16:20:00+07:00 (approx)
- Scope locked to requested fixes only:
  - Create dossier UX/logic completion in dossier list
  - Import entry point + bind import to selected dossier (`case_id`)
  - Sortable dossier columns (`Tên hồ sơ`, `Loại hồ sơ`, `Bút lục`)
  - Auto-metadata visibility from OCR extracted fields with pending state

## Changed files
- `PhanMem/src-tauri/src/commands/case_cmd.rs`
- `PhanMem/src/services/caseService.ts`
- `PhanMem/src/components/pages/CaseListPage.tsx`

## Implementation notes
- Backend [`CaseSummary`](PhanMem/src-tauri/src/commands/case_cmd.rs:21) extended with:
  - `case_type`, `dossier_type`, `but_luc`, `ocr_state`.
- Backend [`list_cases()`](PhanMem/src-tauri/src/commands/case_cmd.rs:532) and [`get_case_summary_by_id()`](PhanMem/src-tauri/src/commands/case_cmd.rs:87) now compute:
  - dominant dossier type from `documents.document_type`
  - top OCR `bút lục` from `document_extracted_fields(field_name='but_luc')`
  - OCR pending/done/none state from `documents.status`.
- Frontend [`CaseSummary`](PhanMem/src/services/caseService.ts:4) updated to consume new metadata fields.
- Dossier list UI [`CaseListPage`](PhanMem/src/components/pages/CaseListPage.tsx:12) updated with:
  - stronger create feedback (loading + success toast)
  - explicit per-dossier import action using [`importMultipleFiles()`](PhanMem/src/services/importService.ts:76) with selected `case_id`
  - sortable columns for name/type/bút lục and local sort state
  - pending OCR indicator when `bút lục` chưa có (`ocr_state='pending'`).

## Verification
- `cargo check -j 1` (cwd `PhanMem/src-tauri`) → PASS.
- `npm run tauri:build` (cwd `PhanMem`) → RUNNING (terminal active; awaiting completion status).

---

# 20260428_13 — Settings Secure Purge Imported Dossier

## Scope confirmation
- Time: 2026-04-28T13:45:00+07:00 (approx)
- Scope locked to secure dossier purge flow only:
  - Settings dangerous UI section for purge
  - Strict double confirmation (exact dossier identity + `OK`)
  - Rust purge command by `case_code` with transactional DB cleanup
  - Filesystem cleanup for dossier artifacts only
  - Frontend service wiring via `caseService` safe invoke
  - Verification commands and report update

## Work trace

### Step 1
- Timestamp: 2026-04-28T13:43:00+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/case_cmd.rs`
- Reason:
  - Add secure backend purge command for imported dossier.
- Output summary:
  - Added payload DTO: `PurgeImportedDossierInput`.
  - Added response DTO: `PurgeImportedDossierSummary`.
  - Added command `purge_imported_dossier` with strict checks:
    - reject empty `case_code`
    - require exact token `OK`
    - require exact dossier identity string `"{case_code} - {case_display_name}"`
  - Transactional DB cleanup for dossier-scoped tables and dependent rows.
  - Filesystem cleanup for collected artifact paths (`documents.file_path`, `pages.image_path`, `scan_jobs.original_scan_path`) and safe parent empty-dir cleanup.
  - Summary returns per-table deleted row counts, deleted files count, and non-fatal file errors.

### Step 2
- Timestamp: 2026-04-28T13:43:20+07:00
- Files changed:
  - `PhanMem/src-tauri/src/main.rs`
- Reason:
  - Register new Tauri command for frontend invoke.
- Output summary:
  - Added `commands::case_cmd::purge_imported_dossier` to invoke handler.

### Step 3
- Timestamp: 2026-04-28T13:43:40+07:00
- Files changed:
  - `PhanMem/src/services/caseService.ts`
- Reason:
  - Add typed frontend service wrapper using safe invoke pattern.
- Output summary:
  - Added interfaces `PurgeImportedDossierInput`, `PurgeImportedDossierSummary`.
  - Added `purgeImportedDossier(input)` wrapper on command `purge_imported_dossier`.

### Step 4
- Timestamp: 2026-04-28T13:44:10+07:00
- Files changed:
  - `PhanMem/src/components/pages/SettingsPage.tsx`
- Reason:
  - Add dangerous purge section and strict confirmation UX.
- Output summary:
  - Added “Vùng nguy hiểm” section in Settings.
  - Added inputs:
    - dossier `case_code`
    - exact identity string input (must match displayed dossier label)
    - final token input (`OK`)
  - Added irreversible warning text.
  - Delete action disabled until all validations pass.
  - Wired action to backend purge command and summary feedback display.

## Verification
- `cargo check -j 1` (cwd `PhanMem/src-tauri`) → PASS.
- `npm run tauri:build` (cwd `PhanMem`) → FAIL (pre-existing TypeScript unused-variable errors in [`DocumentViewerPage.tsx`](PhanMem/src/components/pages/DocumentViewerPage.tsx)).

## Notes during verification
- Fixed one Rust compile blocker unrelated to purge scope in [`doc_cmd.rs`](PhanMem/src-tauri/src/commands/doc_cmd.rs): changed immutable `args` vector to mutable to satisfy push operations in OCR PDF conversion path.

---

# 20260428_12 — Phase 3/4/5 (partial executable) Continuation Log

## Scope confirmation
- Time: 2026-04-28T12:25:00+07:00 (approx)
- Scope executed in this run:
  - Phase 3: progress UX backend aggregation + frontend global footer status wiring.
  - Phase 4: process mode settings (manual/full-auto + autoscan/autosave/autoname/autosummary/autoclassify).
  - Phase 5 partial executable: replace placeholder transitions with feasible real hooks now, explicit deferred stubs with status codes for non-ready actions.
  - Keep offline architecture (no internet dependency added).

## Work trace

### Step 1
- Timestamp: 2026-04-28T12:27:00+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Add backend contracts for progress aggregation and process mode settings.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added DTOs: `PipelineProgressStatus`, `PipelineProcessModeSettings`.
  - Added commands:
    - `get_pipeline_progress_status`
    - `get_pipeline_process_mode_settings`
    - `save_pipeline_process_mode_settings`
  - Added helpers:
    - process mode parser from `app_settings`
    - current phase resolver
    - task completion helper with result JSON.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 2
- Timestamp: 2026-04-28T12:29:00+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Apply Phase 4/5 logic into scheduler/tick path with minimal safe increments.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added `import_scanned_file_core(...)` reusable internal function.
  - `start_pipeline_job(...)` now seeds payload with process mode metadata.
  - `pipeline_execution_tick(...)` now applies manual gate pause for phases `import/ocr/ai/persist` when `process_mode=manual`.
  - Replaced placeholder executor call with `execute_phase_action(...)`:
    - `discover`: real completion hook.
    - `import`: real import hook when payload has `source_file` + `case_id`.
    - `import`: explicit deferred status code `IMPORT_INPUT_MISSING` when inputs absent.
    - `ocr`: explicit deferred status code `OCR_DOCUMENT_ID_MISSING` or `OCR_EXECUTION_REQUIRES_APPHANDLE`.
  - Kept non-ready actions explicit via result JSON status codes/TODO note.
- Issues encountered:
  - One early patch mismatch while refactoring import function signature.
- Fix applied:
  - Re-read exact region and reapplied targeted patch chunks.

### Step 3
- Timestamp: 2026-04-28T12:30:00+07:00
- Files changed:
  - `PhanMem/src-tauri/src/main.rs`
- Reason:
  - Register new Tauri invoke endpoints for Phase 3/4.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added command registrations:
    - `get_pipeline_progress_status`
    - `get_pipeline_process_mode_settings`
    - `save_pipeline_process_mode_settings`
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 4
- Timestamp: 2026-04-28T12:31:00+07:00
- Files changed:
  - `PhanMem/src/services/scanService.ts`
  - `PhanMem/src/store/uiStore.ts`
  - `PhanMem/src/App.tsx`
- Reason:
  - Wire frontend service/store/global footer status for progress UX integration.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added TS interfaces + wrappers:
    - `PipelineProgressStatus`
    - `PipelineProcessModeSettings`
    - `getPipelineProgressStatus(...)`
    - `getPipelineProcessModeSettings(...)`
    - `savePipelineProcessModeSettings(...)`
  - Extended UI store with:
    - `pipelineFooter`
    - `pipelineProgress`
    - `refreshPipelineStatus()` polling source.
  - App footer now shows global process status fields:
    - active/paused jobs
    - current phase and processed/total with percent.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 5
- Timestamp: 2026-04-28T12:32:00+07:00
- Files changed:
  - `PhanMem/src/components/pages/SettingsPage.tsx`
- Reason:
  - Add Settings controls for process mode with persistence.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added process mode settings card/UI:
    - `manual` / `full_auto`
    - toggles: `autoscan`, `autosave`, `autoname`, `autosummary`, `autoclassify`.
  - Load + save integrated with new backend commands.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 6 — Verification
- Timestamp: 2026-04-28T12:35:00+07:00
- Files changed:
  - N/A (verification runs)
- Reason:
  - Validate compile/build integrity after Phase 3/4/5 partial integration.
- Command run:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`)
  - `npm run tauri:build` (cwd: `PhanMem`)
- Output summary:
  - `cargo check -j 1` → PASS (`Finished dev profile`).
  - `npm run tauri:build` → PASS (Vite build + Rust release + NSIS bundle).
  - Built installer path:
    - `PhanMem/src-tauri/target/release/bundle/nsis/VKS - Hồ Sơ Điện Tử_1.0.0_x64-setup.exe`
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

## Runnable vs deferred summary
- Runnable now:
  - Progress aggregation contract and global footer status consumption.
  - Process mode settings persistence and gate checks in scheduler.
  - Partial real action path for import when payload contains actionable inputs.
- Deferred (explicit stubs preserved intentionally):
  - OCR execution inside tick path requiring AppHandle-aware runner bridge (`OCR_EXECUTION_REQUIRES_APPHANDLE`).
  - Upstream discovery-to-import payload population for full autonomous import flow (`IMPORT_INPUT_MISSING` when absent).


---

# 20260428_10 — Phase 2 Multi-Core Worker Engine (Scoped) Continuation Log

## Scope confirmation
- Time: 2026-04-28T12:00:00+07:00 (approx)
- Scope locked to Phase 2 (scoped) only:
  - Worker pool sizing policy by CPU cores with safe cap
  - Queue polling tick execution core
  - Placeholder phase chain: `discover -> import -> ocr -> ai -> persist`
  - Retry/backoff handling
  - Pause/cancel aware tick behavior
  - Backpressure guardrails (max inflight + queue high watermark)
  - Structured transition logs + persistence to `pipeline_events`
  - Add Phase 2 command endpoint(s) and TS wrappers
  - Verify by `cargo check -j 1` and `npm run tauri:build`

## Work trace

### Step 1
- Timestamp: 2026-04-28T11:59:30+07:00
- Files inspected:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
  - `PhanMem/src-tauri/migrations/004_pipeline_phase1.sql`
  - `PhanMem/src-tauri/src/main.rs`
  - `PhanMem/src/services/scanService.ts`
- Reason:
  - Confirm Phase 1 baseline lifecycle APIs and table constraints before introducing Phase 2 executor core.
- Command run:
  - N/A (read/search only)
- Output summary:
  - Existing lifecycle commands and `pipeline_events` table already in place.
  - `pipeline_tasks` schema supports `attempt`, `payload_json`, status transitions.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 2
- Timestamp: 2026-04-28T12:01:21+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Implement Phase 2 execution tick core, backpressure controls, placeholder phase runner, retry/backoff and event persistence.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added `PipelineTickResult` DTO.
  - Added worker sizing policy:
    - `derive_worker_pool_size()` from `available_parallelism()` capped by `PIPELINE_MAX_POOL_CAP`.
    - `derive_max_inflight()` capped by `PIPELINE_MAX_INFLIGHT_CAP`.
  - Added queue task helpers:
    - `enqueue_pipeline_task(...)`
    - `parse_not_before_ms(...)`
  - Added structured event helper with meta payload:
    - `pipeline_event_with_meta(...)`
  - Added placeholder phase executor:
    - `execute_phase_placeholder(...)` chaining `discover -> import -> ocr -> ai -> persist`.
  - Added retry/backoff mechanism:
    - `fail_or_retry_task(...)`
    - Exponential backoff with `not_before_epoch_ms` in `payload_json`.
  - Added pause/cancel aware scheduler commands:
    - `pipeline_execution_tick(job_id)`
    - `bootstrap_pipeline_background(job_id, ticks)`
  - Added backpressure guardrails:
    - queue high watermark block
    - inflight cap block
  - Updated `start_pipeline_job(...)` to enqueue initial `discover` seed task.
- Issues encountered:
  - None during patch.
- Fix applied:
  - N/A.

### Step 3
- Timestamp: 2026-04-28T12:01:31+07:00
- Files changed:
  - `PhanMem/src-tauri/src/main.rs`
- Reason:
  - Register new Phase 2 invoke endpoints.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added command registrations:
    - `pipeline_execution_tick`
    - `bootstrap_pipeline_background`
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 4
- Timestamp: 2026-04-28T12:01:38+07:00
- Files changed:
  - `PhanMem/src/services/scanService.ts`
- Reason:
  - Add frontend wrappers for newly added Phase 2 endpoints only.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Added `PipelineTickResult` interface.
  - Added wrappers:
    - `pipelineExecutionTick(jobId)`
    - `bootstrapPipelineBackground(jobId, ticks?)`
  - Kept `safeInvoke` pattern and fallback behavior.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 5
- Timestamp: 2026-04-28T12:02:00+07:00
- Files changed:
  - N/A (verification run)
- Reason:
  - Validate Rust compile state after Phase 2 scoped implementation.
- Command run:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`)
- Output summary:
  - Success.
  - `Finished dev profile` without errors.
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

### Step 6
- Timestamp: 2026-04-28T12:06:08+07:00
- Files changed:
  - N/A (verification run)
- Reason:
  - Verify full Tauri production build path remains healthy.
- Command run:
  - `npm run tauri:build` (cwd: `PhanMem`)
- Output summary:
  - Success.
  - Vite build completed.
  - Rust `release` build completed.
  - NSIS installer created at:
    - `PhanMem/src-tauri/target/release/bundle/nsis/VKS - Hồ Sơ Điện Tử_1.0.0_x64-setup.exe`
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

## Verification
- `cargo check -j 1` in `PhanMem/src-tauri` → PASS
- `npm run tauri:build` in `PhanMem` → PASS

## Phase 2 scoped runtime status
- Runnable now:
  - Start a pipeline job with initial seeded `discover` task.
  - Execute scheduler via single tick command (`pipeline_execution_tick`).
  - Execute bounded loop bootstrap (`bootstrap_pipeline_background`).
  - Auto-chain placeholder phases to terminal `persist`.
  - Pause/cancel aware stop behavior.
  - Retry/backoff scheduling using task payload metadata.
  - Structured transition/event persistence to `pipeline_events`.
  - Backpressure controls (`max_inflight`, queue high watermark).
- Placeholder (intentional, not Phase 3+):
  - Phase bodies currently stubbed (no full OCR/AI/business persistence implementation).
  - No UI redesign or new visualization flow added.

---

# 20260428_11 — OCR Vietnamese Unicode + Layout Preservation Fix Log

## Scope confirmation
- Time: 2026-04-28T12:08:00+07:00 (approx)
- Scope locked exactly to:
  - OCR root-cause diagnosis in Python OCR + PDF image extraction + Rust bridge
  - Vietnamese diacritic-preserving OCR config and UTF-8 propagation
  - Layout-preserving OCR blocks + formatted text while keeping backward compatibility
  - Wire save/view flow to prefer formatted OCR text fallback to plain text
  - Add verification script and run required build validations

## Work trace

### Step 1 — Root-cause audit
- Files inspected:
  - `PhanMem/python/ocr/ocr_pipeline.py`
  - `PhanMem/python/ocr/pdf_to_images.py`
  - `PhanMem/src-tauri/src/commands/doc_cmd.rs`
  - `PhanMem/src/services/documentService.ts`
  - `PhanMem/src/components/pages/DocumentViewerPage.tsx`
- Findings:
  - OCR pipeline defaulted to `lang="vi"` and RapidOCR was initialized without explicit Vietnamese language hint, reducing Vietnamese diacritic fidelity depending on active model.
  - Rust OCR invocation did not pass explicit OCR language to Python, so language selection was implicit/ambiguous.
  - OCR result model returned only flattened line-joined text (`ocr_text`), no persisted structured layout blocks for page geometry reconstruction.
  - Viewer consumed `ocr_text` directly and had no preference path for formatted layout text.

### Step 2 — Python OCR Vietnamese + layout output
- Files changed:
  - `PhanMem/python/ocr/ocr_pipeline.py`
- Changes:
  - Added sorted-line normalization and block grouping by geometry (`_sort_lines`, `_build_layout`).
  - Added output fields: `ocr_formatted_text`, `blocks`, and `lang` in JSON result.
  - Switched CLI default language to `vie`.
  - RapidOCR initialization now tries `RapidOCR(lang="vie")` with compatibility fallback.

### Step 3 — DB migration for formatted/layout OCR
- Files changed:
  - `PhanMem/src-tauri/migrations/005_ocr_layout_utf8.sql`
  - `PhanMem/src-tauri/src/db/mod.rs`
- Changes:
  - Added columns to `pages`: `ocr_formatted_text`, `ocr_layout_blocks`.
  - Registered migration 005 in DB init and added migration test assertion.

### Step 4 — Rust OCR bridge UTF-8 + formatted/layout persistence
- Files changed:
  - `PhanMem/src-tauri/src/commands/doc_cmd.rs`
- Changes:
  - Enforced Python UTF-8 environment in bridge runner (`PYTHONUTF8=1`, `PYTHONIOENCODING=utf-8`).
  - Extended OCR DTO/state with formatted text + layout blocks.
  - Passed explicit OCR language `vie` from Rust to Python OCR command.
  - Persisted `ocr_formatted_text` and `ocr_layout_blocks` into `pages`.
  - Updated `get_page_ocr` query/result mapping to return formatted text and layout blocks.
  - Manual OCR edit now updates `ocr_formatted_text` to keep behavior consistent.

### Step 5 — Frontend compatibility wire-up
- Files changed:
  - `PhanMem/src/services/documentService.ts`
  - `PhanMem/src/components/pages/DocumentViewerPage.tsx`
- Changes:
  - Extended `PageOcrResult` type for formatted/layout fields.
  - Viewer now loads OCR draft using priority:
    1) `ocr_formatted_text`
    2) fallback `ocr_text`
  - Save flow preserves same fallback behavior.

### Step 6 — Verification script
- Files changed:
  - `PhanMem/python/ocr/verify_vietnamese_ocr.py`
- Changes:
  - Added offline script to generate accented Vietnamese sample image, run OCR (`lang=vie`), and report:
    - diacritic presence flag
    - layout block count
    - confidence
    - pass/fail summary

### Step 7 — Validation commands
- Command:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`) → PASS
- Command:
  - `python -m ocr.verify_vietnamese_ocr --json` (cwd: `PhanMem/python`) → PASS (`has_diacritic_chars=true`, `block_count=3`)
- Command:
  - `npm run tauri:build` (cwd: `PhanMem`) → PASS (NSIS bundle generated)

## Final status
- Completed OCR Unicode + layout preservation scope with backward compatibility retained for plain-text consumers.

---

# 20260428_13 — Next phase execution (after Phase 3/4/5-partial)

## Scope confirmation
- Time: 2026-04-28T12:38:00+07:00 (approx)
- Scope executed in this run:
  - Close deferred pipeline gaps from Phase 3/4/5-partial.
  - Implement AppHandle-aware OCR execution bridge in tick flow.
  - Implement autonomous discovery -> import payload materialization for missing `source_file/case_id`.
  - Convert feasible deferred branches to runnable logic.
  - Keep offline/Tauri constraints.

## Work trace

### Step 1 — Pipeline bridge and autonomous payload materialization
- Timestamp: 2026-04-28T12:40:00+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Replace deferred OCR and import gaps with executable logic.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - `pipeline_execution_tick(...)` now receives `AppHandle`.
  - `bootstrap_pipeline_background(...)` now forwards `AppHandle` into tick calls.
  - Added discovery helpers for autonomous import materialization:
    - `discover_ready_file_count(...)`
    - `discover_first_ready_file(...)`
    - `resolve_case_id_for_autonomous_import(...)`
  - `discover` phase now records `ready_count`.
  - `import` phase now auto-populates missing `source_file/case_id` from inbox + settings/current case when possible.
  - `import` missing-input branch now returns terminal deferred result for that task (`Ok(None)`), no forced chain to OCR.
  - OCR phase now executes via AppHandle-aware bridge call and stores runnable result JSON (`ok/error`) instead of always deferred.
- Issues encountered:
  - None during patch.
- Fix applied:
  - N/A.

### Step 2 — Reuse real OCR executor with existing DB connection
- Timestamp: 2026-04-28T12:41:00+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/doc_cmd.rs`
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Ensure pipeline OCR bridge runs actual OCR implementation, not stub behavior.
- Command run:
  - N/A (file edit via patch)
- Output summary:
  - Extracted reusable function:
    - `run_ocr_for_document_with_conn(app, conn, document_id)` in `doc_cmd.rs`.
  - Existing command `run_ocr_for_document(...)` now delegates to reusable function.
  - Pipeline bridge in `scan_cmd.rs` now calls `doc_cmd::run_ocr_for_document_with_conn(...)`.
- Issues encountered:
  - Initial refactor left one stale reference to `db` inside reusable OCR function.
- Fix applied:
  - Replaced stale lock path with provided `conn` usage in no-pages error branch.

### Step 3 — Compile verification and correction loop
- Timestamp: 2026-04-28T12:41:30+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/doc_cmd.rs`
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Resolve compile issue and clean warnings.
- Command run:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`)
- Output summary:
  - First run: FAIL
    - Error: `cannot find value db in this scope` at `doc_cmd.rs` after extraction.
    - Warning: unused import `Manager` in `scan_cmd.rs`.
  - Fixes applied:
    - Removed stale `db` reference; used existing `conn`.
    - Removed unused import `Manager`.
  - Re-run: PASS (`Finished dev profile`).
- Issues encountered:
  - One refactor regression and one lint warning.
- Fix applied:
  - Patched both in-place and re-ran compile check.

### Step 4 — Full build verification
- Timestamp: 2026-04-28T12:46:00+07:00
- Files changed:
  - N/A (verification run)
- Reason:
  - Validate full Tauri build path remains healthy after next-phase execution changes.
- Command run:
  - `npm run tauri:build` (cwd: `PhanMem`)
- Output summary:
  - PASS.
  - Vite build completed.
  - Rust release build completed.
  - NSIS installer generated:
    - `PhanMem/src-tauri/target/release/bundle/nsis/VKS - Hồ Sơ Điện Tử_1.0.0_x64-setup.exe`
- Issues encountered:
  - None.
- Fix applied:
  - N/A.

## Final verification
- `cargo check -j 1` in `PhanMem/src-tauri` → PASS
- `npm run tauri:build` in `PhanMem` → PASS

## Unresolved issues / remaining backlog
- Pipeline auto-case resolution currently selects `scan.ricoh.default_case_id` or latest updated case; no advanced discovery-to-case mapping heuristic yet.
- If no ready file and no resolved case exists, `import` task remains deferred with `IMPORT_INPUT_MISSING` (explicit, traceable behavior).
- OCR execution now runnable in tick flow, but throughput tuning for heavy parallel OCR remains future optimization scope.

---

# 20260428_14 — Complete remaining Phase 5 + Phase 6 hardening + full recheck

## Scope confirmation
- Time: 2026-04-28T12:50:00+07:00 (approx)
- Scope executed in this run:
  - Finish remaining Phase 5 backlog:
    - robust autonomous case-id mapping
    - stronger claim/lock strategy for ready-file race reduction
    - integration checks for `discover -> import -> ocr`
  - Implement Phase 6 hardening:
    - KPI/observability summaries
    - stress-safety checks and rollout guard reporting
  - Recheck Phases 1→6 for regressions:
    - compile/build integrity
    - frontend↔Rust command contract consistency
    - migration compatibility sanity

## Work trace

### Step 1 — Phase 5: robust autonomous case mapping
- Timestamp: 2026-04-28T12:50:40+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Harden case-id auto-resolution beyond simple default/latest fallback.
- Output summary:
  - Updated `resolve_case_id_for_autonomous_import(...)`:
    - verifies `scan.ricoh.default_case_id` exists in `cases`
    - if not, tries alias resolution by joining `app_settings.value` with `cases.case_code` (case-insensitive/trimmed)
    - only then falls back to latest case.

### Step 2 — Phase 5: stronger claim/lock strategy
- Timestamp: 2026-04-28T12:51:10+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- Reason:
  - Reduce concurrent race around autonomous ready-file selection/import.
- Output summary:
  - Added `try_claim_ready_file(...)` using `scan_jobs` as DB-level claim metadata.
  - `import` phase now attempts claim before import.
  - If already claimed/importing/imported/duplicate, task completes deferred with status code `IMPORT_FILE_ALREADY_CLAIMED` and stops chain safely (`Ok(None)`).

### Step 3 — Phase 5: integration checks for chain discover->import->ocr
- Timestamp: 2026-04-28T12:51:35+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
  - `PhanMem/src-tauri/src/main.rs`
  - `PhanMem/src/services/scanService.ts`
- Reason:
  - Add practical, query-based integration checks in current environment.
- Output summary:
  - Added backend command `get_pipeline_integration_check(...)` returning:
    - `discover_completed`
    - `import_completed`
    - `ocr_reached`
    - `chain_ok`
    - diagnostic `notes[]`
  - Registered new command in Tauri invoke handler.
  - Added frontend typed wrapper `getPipelineIntegrationCheck(...)`.

### Step 4 — Phase 6: observability KPI summary
- Timestamp: 2026-04-28T12:52:00+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
  - `PhanMem/src-tauri/src/main.rs`
  - `PhanMem/src/services/scanService.ts`
- Reason:
  - Add aggregated KPI visibility for pipeline operations.
- Output summary:
  - Added `PipelineKpiSummary` DTO + command `get_pipeline_kpi_summary(...)`:
    - job counts by status
    - summed task counts
    - completion rate percentage
    - generation timestamp
  - Registered command in Tauri invoke list.
  - Added frontend wrapper `getPipelineKpiSummary(...)`.

### Step 5 — Phase 6: stress-safety checks + rollout guards
- Timestamp: 2026-04-28T12:52:25+07:00
- Files changed:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
  - `PhanMem/src-tauri/src/main.rs`
  - `PhanMem/src/services/scanService.ts`
- Reason:
  - Provide lightweight practical safety signal set for current environment.
- Output summary:
  - Added `PipelineSafetyReport` DTO + command `get_pipeline_safety_report(...)`:
    - static guard caps (`queue_high_watermark`, worker/inflight caps)
    - dynamic pressure metrics (`blocked_jobs_by_watermark`, `jobs_with_retry_pressure`)
    - unresolved risk notes
    - rollout guard notes.
  - Registered command and frontend wrapper `getPipelineSafetyReport(...)`.

### Step 6 — Regression recheck: compile + contract + migration sanity
- Timestamp: 2026-04-28T12:52:50+07:00
- Files changed:
  - N/A (verification + review)
- Reason:
  - Recheck processed phases for regressions and contract integrity.
- Command run:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`)
- Output summary:
  - PASS (`Finished dev profile`).
  - Rust command registrations include newly added endpoints.
  - TS service wrappers aligned to Rust command names and DTOs.
  - No migration schema changes required; compatibility remains with existing `003_scan_ricoh.sql` + `004_pipeline_phase1.sql`.

### Step 7 — Full build verification
- Timestamp: 2026-04-28T12:53:10+07:00
- Files changed:
  - N/A (verification run)
- Reason:
  - Execute required full Tauri build verification after Phase 5/6 hardening.
- Command run:
  - `npm run tauri:build` (cwd: `PhanMem`)
- Output summary:
  - PASS.
  - Vite build completed.
  - Rust release build + NSIS bundle completed.

## Recheck report summary (Phases 1→6)
- Compile/build command integrity:
  - `cargo check -j 1` PASS.
  - `npm run tauri:build` PASS.
- Frontend↔Rust API contract consistency:
  - New endpoints added and registered in `main.rs`; wrappers added in `scanService.ts` with aligned naming.
- Migration compatibility sanity:
  - No destructive schema change introduced in this run.
  - New logic relies on existing compatible schema (`scan_jobs`, `pipeline_*` tables).

## Remaining risks after this run
- DB-level claim reduces race substantially but is not equivalent to filesystem-level atomic move lock.
- Heavy OCR workloads may still create long-tail runtime in constrained hosts; requires future throughput tuning.

---

# 20260428_14 — Purge follow-up closure (build blocker + backlog recheck)

## Scope confirmation
- Time: 2026-04-28T14:10:00+07:00 (approx)
- Scope locked to requested closure only:
  - Re-read unresolved checklist status in [`20260428_10_phase_next_task_checklist.md`](V2/03_bao_cao/03_fix/20260428_10_phase_next_task_checklist.md)
  - Close remaining TypeScript build blocker in [`DocumentViewerPage`](PhanMem/src/components/pages/DocumentViewerPage.tsx)
  - Re-run mandatory verification commands
  - Update implementation/report tracking files only

## Work trace

### Step 1 — Backlog recheck
- Timestamp: 2026-04-28T14:10:30+07:00
- Files changed:
  - N/A (review)
- Reason:
  - Confirm whether any unchecked phase items remain beyond purge verification.
- Output summary:
  - All backlog/phase items already marked completed.
  - Only remaining unchecked line was build verification status for purge task.

### Step 2 — TypeScript blocker verification
- Timestamp: 2026-04-28T14:12:00+07:00
- Files changed:
  - `PhanMem/src/components/pages/DocumentViewerPage.tsx` (already resolved before this verification pass)
- Reason:
  - Validate TS build blocker closure before full Tauri build.
- Command run:
  - `npx tsc -p tsconfig.json --noEmit` (cwd: `PhanMem`)
- Output summary:
  - PASS (exit code 0; no TS6133 errors).

### Step 3 — Rust verification
- Timestamp: 2026-04-28T14:12:40+07:00
- Files changed:
  - N/A (verification)
- Reason:
  - Reconfirm backend compile integrity after purge-related closure run.
- Command run:
  - `cargo check -j 1` (cwd: `PhanMem/src-tauri`)
- Output summary:
  - PASS (`Finished dev profile`).

### Step 4 — Full Tauri build verification
- Timestamp: 2026-04-28T14:18:30+07:00
- Files changed:
  - N/A (verification)
- Reason:
  - Confirm end-to-end production build path now passes.
- Command run:
  - `npm run tauri:build` (cwd: `PhanMem`)
- Output summary:
  - PASS.
  - Vite production build completed.
  - Rust release build completed.
  - NSIS bundle generated at:
    - `PhanMem/src-tauri/target/release/bundle/nsis/VKS - Hồ Sơ Điện Tử_1.0.0_x64-setup.exe`

## Closure status
- Requested unresolved items for this run are closed.
- No additional feasible unchecked phase tasks remained in the referenced checklist at execution time.

---

# 20260428_16 — Full-scope closure rerun against phase-next checklist

## Scope confirmation
- Time: 2026-04-28T17:26:00+07:00 (approx)
- Source of truth: `V2/03_bao_cao/03_fix/20260428_10_phase_next_task_checklist.md`
- Scope executed exactly as requested:
  - Re-audit unresolved checklist items (`[ ]` or unresolved notes)
  - Close remaining item(s) with minimal safe patch
  - Re-run mandatory verification gates
  - Update checklist + append implementation/verification trace

## Re-audit result
- Found 1 remaining open checkbox in checklist:
  - `npm run tauri:build` in section `20260428_15 — Dossier create/import/sort/OCR metadata flow fix`
- Technical code backlog remaining: none newly found beyond this verification status line.

## Changes applied
- Updated checklist status to closed:
  - File: `V2/03_bao_cao/03_fix/20260428_10_phase_next_task_checklist.md`
  - Change: set build verification from `[ ] RUNNING` to `[x] PASS` with closure rerun note.

## Verification rerun (mandatory)
- Command: `cargo check -j 1` (cwd `PhanMem/src-tauri`)
  - Result: PASS
  - Output: `Finished dev profile [unoptimized + debuginfo] target(s) in 2.35s`
- Command: `npm run tauri:build` (cwd `PhanMem`)
  - Result: PASS
  - Output summary:
    - Vite production build PASS
    - Rust release compile PASS
    - NSIS bundle PASS
    - Artifact: `PhanMem/src-tauri/target/release/bundle/nsis/VKS - Hồ Sơ Điện Tử_1.0.0_x64-setup.exe`

## Blockers
- None.
- No residual open checklist item remains in source-of-truth file after this run.
