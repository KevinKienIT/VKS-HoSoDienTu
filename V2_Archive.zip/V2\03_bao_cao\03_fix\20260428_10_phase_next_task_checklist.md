# 20260428_10 — Phase next task checklist (bug-check traceability)

## Executed tasks

- [x] Implement AppHandle-aware OCR bridge in pipeline tick via [`pipeline_execution_tick()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:1402) and [`run_ocr_for_document_in_pipeline()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:903) calling [`run_ocr_for_document_with_conn()`](PhanMem/src-tauri/src/commands/doc_cmd.rs:1133).  
  Verification note: [`cargo check -j 1`](V2/03_bao_cao/03_fix/20260428_09_phase1_pipeline_impl_log.md) PASS and [`npm run tauri:build`](V2/03_bao_cao/03_fix/20260428_09_phase1_pipeline_impl_log.md) PASS.

- [x] Implement autonomous discovery -> import payload materialization for missing `source_file/case_id` in [`execute_phase_action()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:420) using [`discover_first_ready_file()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:844) and [`resolve_case_id_for_autonomous_import()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:890).  
  Verification note: compile/build pass, deferred branch now only when both auto-resolution inputs are still unavailable.

- [x] Replace feasible deferred branches with runnable logic:
  - OCR branch moved from `OCR_EXECUTION_REQUIRES_APPHANDLE`-only deferred to executable path when AppHandle available in [`execute_phase_action()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:499).
  - Import missing-input branch no longer force-chains to OCR; it closes task with explicit deferred result (`Ok(None)`) in [`execute_phase_action()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:466).
  Verification note: command checks succeeded after refactor fixes.

- [x] Add reusable OCR executor with shared DB connection in [`run_ocr_for_document_with_conn()`](PhanMem/src-tauri/src/commands/doc_cmd.rs:1133) and keep command wrapper compatibility in [`run_ocr_for_document()`](PhanMem/src-tauri/src/commands/doc_cmd.rs:1125).  
  Verification note: no API break for existing invoke command; pipeline reuses same logic.

- [x] Keep offline/Tauri compatibility constraints (no internet calls, no browser dev flow scripts) while implementing incremental changes in Rust command layer only.  
  Verification note: build performed through [`npm run tauri:build`](V2/03_bao_cao/03_fix/20260428_09_phase1_pipeline_impl_log.md) successfully.

## Verification summary

- [x] `cargo check -j 1` (cwd `PhanMem/src-tauri`) — PASS.
- [x] `npm run tauri:build` (cwd `PhanMem`) — PASS.

## Unresolved issues / backlog to watch for bug checks

- [x] Improve case resolution heuristic beyond default-case/latest-case fallback in [`resolve_case_id_for_autonomous_import()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:925).  
  Verification note: now validates configured `default_case_id` existence first, then resolves by `case_code` alias match from settings before falling back to latest-case.
- [x] Add stronger duplicate-avoidance claim/lock for concurrent autonomous import workers around [`discover_first_ready_file()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:879) and [`try_claim_ready_file()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:956).  
  Verification note: import phase now creates DB claim row in `scan_jobs` with `importing` lock semantics; already-claimed files are returned as deferred `IMPORT_FILE_ALREADY_CLAIMED` in [`execute_phase_action()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:537).
- [x] Add dedicated integration checks for phase chain transitions (`discover -> import -> ocr`) in pipeline tick flow via [`get_pipeline_integration_check()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:2062).  
  Verification note: command validates per-job discover/import completion and OCR reachability with chain status + notes.

## Phase 6 hardening completion notes

- [x] Observability/KPI summary endpoint added: [`get_pipeline_kpi_summary()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:2125) and service wrapper [`getPipelineKpiSummary()`](PhanMem/src/services/scanService.ts:288).
- [x] Stress-safety/rollout report added: [`get_pipeline_safety_report()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:2204) and service wrapper [`getPipelineSafetyReport()`](PhanMem/src/services/scanService.ts:292).
- [x] New commands registered in Tauri invoke list: [`main()`](PhanMem/src-tauri/src/main.rs:14).

## Regression recheck (Phase 1→6)

- [x] Rust command compile integrity (`cargo check -j 1`) verified after Phase 5/6 changes.
- [x] Frontend↔Rust contract consistency rechecked for newly added commands/interfaces:
  - Rust: [`get_pipeline_integration_check()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:2062), [`get_pipeline_kpi_summary()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:2125), [`get_pipeline_safety_report()`](PhanMem/src-tauri/src/commands/scan_cmd.rs:2204)
  - TS: [`getPipelineIntegrationCheck()`](PhanMem/src/services/scanService.ts:282), [`getPipelineKpiSummary()`](PhanMem/src/services/scanService.ts:288), [`getPipelineSafetyReport()`](PhanMem/src/services/scanService.ts:292)
- [x] Migration compatibility sanity retained (no schema-breaking migration added; relies on existing [`003_scan_ricoh.sql`](PhanMem/src-tauri/migrations/003_scan_ricoh.sql) + [`004_pipeline_phase1.sql`](PhanMem/src-tauri/migrations/004_pipeline_phase1.sql)).

## Secure purge imported dossier (Settings)

- [x] Added dangerous Settings section for dossier purge in [`SettingsPage`](PhanMem/src/components/pages/SettingsPage.tsx) with irreversible warning text and guarded action state.
- [x] Added strict dual confirmation inputs in [`SettingsPage`](PhanMem/src/components/pages/SettingsPage.tsx):
  - exact dossier identity string (`{case_code} - {case_display_name}`)
  - exact token `OK`
  - delete action disabled until both validations pass.
- [x] Added frontend invoke wrapper in [`caseService`](PhanMem/src/services/caseService.ts): [`purgeImportedDossier()`](PhanMem/src/services/caseService.ts).
- [x] Added backend command [`purge_imported_dossier()`](PhanMem/src-tauri/src/commands/case_cmd.rs) with:
  - input safety checks (non-empty dossier code, exact identity match, exact `OK`)
  - dossier-scoped transactional DB purge (documents/pages/ocr/review/catalog/import/work-product and related data via direct + cascade deletes)
  - dossier-linked filesystem cleanup (original files, page images, scan artifacts)
  - structured return summary (rows by table, deleted files count, errors).
- [x] Registered command in Tauri invoke list at [`main()`](PhanMem/src-tauri/src/main.rs).

## Pending verification for this purge task

- [x] `cargo check -j 1` (cwd `PhanMem/src-tauri`) — PASS.
- [x] `npm run tauri:build` (cwd `PhanMem`) — PASS (TS6133 blocker in [`DocumentViewerPage.tsx`](PhanMem/src/components/pages/DocumentViewerPage.tsx) resolved; full Tauri build + NSIS bundle completed).

## Regression targeted hardening completion (2026-04-28)

- [x] File-lock handling hardening implemented for critical dossier lifecycle filesystem points:
  - purge delete file/cache dir retry-backoff + deferred marker fallback in [`case_cmd.rs`](PhanMem/src-tauri/src/commands/case_cmd.rs)
  - rename retry-backoff + structured locked failure in [`doc_cmd.rs`](PhanMem/src-tauri/src/commands/doc_cmd.rs)
  - export save retry-backoff + structured locked failure in [`export_cmd.rs`](PhanMem/src-tauri/src/commands/export_cmd.rs)
- [x] OCR environment hardening implemented in Rust bridge in [`run_python_json()`](PhanMem/src-tauri/src/commands/doc_cmd.rs):
  - UTF-8 env enforced
  - required script presence validation
  - lang config validation (`vie|eng|vie+eng`)
  - explicit diagnostics for python/script/lang/stderr/exit status
  - timeout-like symptom warning path
- [x] Diagnostic logging fields expanded:
  - file-lock: `path`, `op`, `attempt`, `wait_ms`, `final_error`
  - OCR env: `python_path`, `script_path`, `lang`, `stderr_snippet`, `exit_status`
- [x] Verification rerun:
  - `cargo check -j 1` (cwd `PhanMem/src-tauri`) — PASS
  - `npm run tauri:build` (cwd `PhanMem`) — PASS

### Residual risks
- [x] Deferred-delete marker approach (`*.lockdelete.pending`) prevents destructive failure but requires later cleanup policy.
- [x] Timeout classification depends on stderr text patterns; non-standard toolchain messages may not be tagged as timeout-like while still returning structured error diagnostics.

## 20260428_15 — Dossier create/import/sort/OCR metadata flow fix

- [x] Fix create dossier UX in [`CaseListPage`](PhanMem/src/components/pages/CaseListPage.tsx): loading + success/error feedback + immediate refresh + clear navigation.
- [x] Add explicit dossier-context import action in [`CaseListPage`](PhanMem/src/components/pages/CaseListPage.tsx) via [`importMultipleFiles()`](PhanMem/src/services/importService.ts:76) bound to selected `case_id`.
- [x] Add sortable dossier columns in [`CaseListPage`](PhanMem/src/components/pages/CaseListPage.tsx): `Tên hồ sơ`, `Loại hồ sơ`, `Bút lục`.
- [x] Extend backend dossier list payload in [`CaseSummary`](PhanMem/src-tauri/src/commands/case_cmd.rs:21) with OCR-index aware metadata: `dossier_type`, `but_luc`, `ocr_state`, and `case_type`.
- [x] Auto-population wiring after import+OCR:
  - `dossier_type` resolved from imported docs (`documents.document_type`)
  - `but_luc` resolved from OCR extracted fields (`document_extracted_fields.field_name='but_luc'`)
  - pending state shown when OCR not finished (`ocr_state='pending'`).

### Verification status (this task)
- [x] `cargo check -j 1` (cwd `PhanMem/src-tauri`) — PASS.
- [x] `npm run tauri:build` (cwd `PhanMem`) — PASS (2026-04-28 closure rerun completed: Vite build + Rust release + NSIS bundle).
