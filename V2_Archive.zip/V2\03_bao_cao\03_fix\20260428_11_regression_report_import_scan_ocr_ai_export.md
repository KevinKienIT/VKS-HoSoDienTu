# 20260428_11 — Regression Report (Import → Scan → OCR → AI → Export)

## 1) Scope & Runtime

- Runtime model: Tauri offline only.
- Verified commands:
  - `cargo check -j 1` (PASS)
  - `npm run tauri:build` (PASS)
- Build artifact confirmed:
  - `PhanMem/src-tauri/target/release/bundle/nsis/VKS - Hồ Sơ Điện Tử_1.0.0_x64-setup.exe`

## 2) Regression Matrix

| Flow | Entry Command/API | Expected | Status |
|---|---|---|---|
| Import folder | `import_folder` | Create docs/pages/import jobs | PASS (compile/build + command presence) |
| Scan inbox import | `import_scanned_file`, `import_scanned_batch` | Move cataloged scan files into dossier | PASS (command presence + build) |
| OCR execution | `run_ocr_for_document`, pipeline tick OCR branch | OCR text + layout fields persisted | PASS (compile/build + OCR wiring present) |
| AI summarize/ask | `ai_summarize_case`, `ai_ask_case` | Answer with citations from local DB | PASS (command presence + build) |
| Export PDF | `export_pdf_bundle` | Export dossier/doc bundle | PASS (command presence + build) |
| Pipeline orchestration | `start_pipeline_job` + `pipeline_execution_tick` + status commands | Background progression and status | PASS (command presence + build) |

> Note: this pass is a **regression health check** centered on compile/build/contract integrity and command-level coverage.

## 3) Evidence Snapshot

- Tauri command registry includes full flow in:
  - `PhanMem/src-tauri/src/main.rs` (invoke handler entries for import/scan/ocr/ai/export/pipeline)
- Pipeline status and hardening endpoints present in:
  - `PhanMem/src-tauri/src/commands/scan_cmd.rs`
- OCR command set present in:
  - `PhanMem/src-tauri/src/commands/doc_cmd.rs`
- AI command set present in:
  - `PhanMem/src-tauri/src/commands/ai_cmd.rs`

## 4) Non-blocking Risks Observed

1. Race possibility under high concurrency in autonomous import claim path (reduced but still operational risk).
2. OCR throughput variance on weak machines may enlarge ETA accuracy drift.
3. Export edge cases can still fail on malformed source PDFs or locked files.

## 5) Root-Cause Hypothesis Mapping (5–7 sources)

Potential sources if end users report runtime defects in this flow:

1. File-lock/permission conflicts on source or output paths.
2. OCR engine environment drift (Python package mismatch or missing language assets).
3. Pipeline job state transitions racing under high queue pressure.
4. DB contention under simultaneous write-heavy phases.
5. Incomplete payload materialization for autonomous import in corner cases.
6. Export assembly failure on malformed/unsupported PDF structures.
7. UI polling interval desync causing stale status display.

### Most likely 1–2 sources (current build)

1. **Runtime file access/locking** (Windows lock semantics) during import/export.
2. **OCR environment variance** (local Python/OCR model readiness) affecting quality and latency.

## 6) Logs to Add/Watch for Diagnosis Validation

To validate the top hypotheses quickly, monitor/add structured logs at:

- `scan_cmd.rs` pipeline transitions: `job_id`, `task_id`, `phase`, `attempt`, `error_code`.
- OCR bridge in `doc_cmd.rs`: Python stderr snippet, lang config, elapsed time per page.
- Export in `export_cmd.rs`: source file open failures, write path, locked-file detection.

Minimum fields to include in each log event:

- `job_id`, `case_id`, `document_id`, `phase`, `status_before`, `status_after`, `duration_ms`, `error_code`.

## 7) Severity Summary

- Blocking build/compile regressions: **None found** in this pass.
- Functional risk level: **Medium** (due to runtime environment/file-lock variability, not code compile issues).

## 8) Recommendation Before Fixing Anything

Run one controlled E2E runtime scenario with real dossier sample and capture logs for:

- Import → Scan inbox import → OCR full doc → AI summary → Export bundle.

Then confirm whether observed failures match the two likely root causes above before applying additional fixes.

