# 20260428_12 — Lệnh điều chỉnh task/phase/docs theo code hiện tại

## 1) Mục tiêu

- Đối chiếu task/phase với code đã có.
- Đánh dấu DONE các mục đã xử lý.
- Tách rõ mục còn thiếu function/nút bấm.
- Dọn “rác” tài liệu vận hành cũ theo nguyên tắc lưu trữ an toàn (archive, không xóa thẳng).

## 2) Source of truth (ưu tiên)

1. `V2/03_bao_cao/03_fix/20260428_10_phase_next_task_checklist.md`
2. `V2/03_bao_cao/03_fix/20260428_09_phase1_pipeline_impl_log.md`
3. `PhanMem/src-tauri/src/main.rs` (danh sách command đã wire)
4. `PhanMem/src/services/*.ts` (nút bấm/UI có gọi command hay chưa)

## 3) Kết luận đối chiếu nhanh

- Phase kỹ thuật pipeline/OCR/AI/export trong checklist hiện hành: **đã DONE**.
- Build gate hiện tại: `cargo check -j 1` và `npm run tauri:build` đều PASS theo log gần nhất.
- Các file task board cũ thuộc đợt Phase 0/1 trước đây vẫn còn nhiều `[ ]`, nhưng là lịch sử vận hành, không còn phản ánh trạng thái hiện tại.

## 4) Danh sách cần chỉnh ngay

### A. Đánh dấu DONE / chốt trạng thái

- Cập nhật trạng thái tổng vào `V2/NEXT_ACTION.md` theo mốc hiện tại.
- Giữ `20260428_10_phase_next_task_checklist.md` là checklist active, không tách thêm checklist mới.

### B. Mục còn thiếu cần tạo lệnh mới (nếu muốn làm tiếp)

1. Integration runtime test pack E2E thật (dataset cố định).
2. Chính sách dọn deferred marker `*.lockdelete.pending`.
3. Hardening export edge-cases với file PDF hỏng/locked.

## 5) Danh sách tài liệu đề xuất archive (để tránh rác)

> Chỉ archive sau khi user xác nhận. Không xóa vĩnh viễn.

- `V2/04_case_dang_lam_viec/20260425_phase0_task_board.md`
- `V2/04_case_dang_lam_viec/20260425_01_phase0_catalog_master_task_board.md`
- `V2/04_case_dang_lam_viec/20260426_03_task_board_phase1.md`
- `V2/04_case_dang_lam_viec/20260427_03_micro_task_board_post_redesign.md`
- `V2/04_case_dang_lam_viec/20260427_05_master_100_tasks.md`

## 6) Lệnh vận hành mới (chuẩn hóa)

### 6.1 Lệnh recheck chuẩn mỗi vòng fix

1. `cargo check -j 1`
2. `npm run tauri:build`
3. Cập nhật:
   - `V2/03_bao_cao/03_fix/20260428_09_phase1_pipeline_impl_log.md`
   - `V2/03_bao_cao/03_fix/20260428_10_phase_next_task_checklist.md`

### 6.2 Rule cập nhật task

- Task đã xử lý xong + có verify: `[x]`
- Task chưa có function hoặc chưa wire nút bấm: `[ ]` + ghi rõ file/function thiếu
- Không để trạng thái mơ hồ trong nhiều task board song song.

## 7) Đề xuất cấu trúc sau cleanup

- Active:
  - `V2/NEXT_ACTION.md`
  - `V2/03_bao_cao/03_fix/20260428_09_phase1_pipeline_impl_log.md`
  - `V2/03_bao_cao/03_fix/20260428_10_phase_next_task_checklist.md`
- Archive:
  - chuyển các board lịch sử sang nhánh lưu trữ (không xóa cứng).

## 8) Nguyên tắc lưu trữ hồ sơ bắt buộc

- Không dùng thư mục người dùng chọn làm nơi lưu nghiệp vụ lâu dài.
- Khi import/scan, phần mềm phải copy file vào thư mục dữ liệu nằm cạnh file `.exe` đang chạy.
- Chỉ copy/lưu các định dạng hợp lệ vào kho hồ sơ gốc:
  - PDF: `.pdf`
  - Ảnh scan: `.png`, `.jpg`, `.jpeg`, `.tif`, `.tiff`, `.bmp`
  - Office: `.doc`, `.docx`, `.xls`, `.xlsx`, `.ppt`, `.pptx`, `.rtf`
- Nếu thư mục người dùng đưa vào không có file hợp lệ theo danh sách trên thì không tạo hồ sơ, không tạo import job nghiệp vụ, không copy gì vào kho gốc.
- File ngoài danh sách hợp lệ bị bỏ qua; không scan, không copy, không đưa vào `VKS_ECMS_Data/originals`.
- File Office được lưu gốc như tài liệu hợp lệ, nhưng OCR trực tiếp chỉ áp dụng cho PDF/ảnh scan.
- Thư mục dữ liệu chuẩn: `VKS_ECMS_Data/`
  - `originals/`: hồ sơ gốc đã đưa vào phần mềm.
  - `processed/`: dữ liệu sau xử lý, ảnh OCR, cache xử lý.
  - `exports/`: PDF xuất ra theo yêu cầu người dùng.
- Database chỉ trỏ tới file do phần mềm quản lý trong `VKS_ECMS_Data`, không phụ thuộc đường dẫn nguồn bên ngoài.
- Khi mở danh sách hồ sơ/tài liệu, app phải kiểm tra ngược file vật lý còn tồn tại hay không.
- Nếu file mất, UI phải báo đỏ ở hồ sơ/tài liệu tương ứng và không được giả vờ viewer/OCR/export vẫn hợp lệ.

