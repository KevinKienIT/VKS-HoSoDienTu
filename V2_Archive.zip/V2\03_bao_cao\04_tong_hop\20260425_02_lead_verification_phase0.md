# LEAD VERIFICATION PHASE 0

Ngay tao: 2026-04-25
Nguoi ghi: Codex lead coordinator
Pham vi: Kiem tra cheo ket qua Agent A/B/C, source code `PhanMem`, gate build/test va quy dinh dieu phoi V2.

## 1. Ket luan ngan

Phase 0 chua duoc dong hoan toan vi Rust/Tauri gate chua chay duoc va corpus PDF trong `TaiLieu` can xac minh lai. Tuy nhien cac gate code/frontend co the verify tren may hien tai da pass:

- Schema SQLite: PASS.
- Catalog scanner metadata: PASS trong lan dau voi 68 file; lan kiem tra lai luc 19:58 thay `TaiLieu` khong con PDF nen corpus gate dang BLOCKED.
- Frontend dependency install: PASS.
- Frontend TypeScript/Vite build: PASS.
- npm audit: PASS, 0 vulnerabilities.

Blocker con lai:
- `cargo` va `rustc` chua co tren PATH, nen chua the ket luan Rust compile/Tauri app pass.
- `TaiLieu/15. Lê Thành Công - 134 - Liên` hien rong, nen can khoi phuc/xac minh lai 68 PDF truoc khi dong catalog gate voi du lieu that.

## 2. Loi/rui ro da phat hien va da sua

| Hang muc | Phat hien | Xu ly |
|----------|-----------|-------|
| DB init | `db::init()` chi la stub, khong tao SQLite schema that | Da dung `rusqlite::Connection`, bat `foreign_keys`, chay migration 001 |
| Verify schema | `verify_schema.py` phu thuoc current working directory | Da resolve repo root tu vi tri file |
| Dependency | `vite-plugin-tauri` conflict Tauri v2 va peer `@tauri-apps/cli ^1` | Da go khoi `package.json` va `vite.config.ts` |
| TypeScript strict | Tham so stub trong `catalogService.ts` chua dung lam build fail | Da dua tham so vao log stub |
| npm audit | Vite 5/esbuild va uuid co moderate advisory | Da go `uuid` JS khong dung, nang Vite 8/plugin React 6 |
| Dieu phoi | Lenh V2 chua noi ro log runtime trong `PhanMem/logs` va bat buoc error handling | Da bo sung vao `20260425_01_lenh_3_agent_phase0_va_catalog.md` |

## 3. Lenh verify da chay

| Lenh | Ket qua |
|------|---------|
| `python python/catalog/verify_schema.py` | PASS - 27 tables, 31 indexes |
| `python -m catalog.scanner "d:\JOBS\VKS-HoSoDienTu\TaiLieu"` | PASS lan dau - 68 files; BLOCKED khi re-run vi corpus hien rong |
| `npm install` | PASS sau khi go dependency conflict |
| `npm run build` | PASS |
| `npm audit --audit-level=moderate` | PASS - 0 vulnerabilities |
| `cargo --version; rustc --version` | FAIL/BLOCKED - command not found |

## 4. Danh gia conflict

- Worktree co nhieu file moi/chinh sua tu cac agent truoc; khong revert bat ky thay doi nao.
- Chua thay dau hieu agent sua `TaiLieu`.
- Trang thai trong status A/B/C cu co lech nhau theo thoi diem; `NEXT_ACTION.md` da duoc cap nhat theo ket qua verify moi nhat.

## 5. Chi dao tiep cho 3 agent

### Agent A - Foundation/Environment

1. Cai Rust toolchain hoac sua PATH de `cargo --version` va `rustc --version` pass.
2. Chay `cargo check` trong `PhanMem/src-tauri`.
3. Chay `npm run tauri:dev` trong `PhanMem`.
4. Ghi ket qua vao status A va `PhanMem/logs/20260425_phase0_lead_verification.md`.

### Agent B - Data/DB

1. Review lai `PhanMem/src-tauri/src/db/mod.rs` sau khi da chay migration that.
2. Neu co Rust compile error lien quan schema/migration, chi sua `src-tauri/src/db/**` va migration neu can.
3. Sau khi corpus PDF duoc khoi phuc, chay lai scanner va doi chieu file count/hash.
4. Khong mo OCR, khong import du lieu that.

### Agent C - Coordinator/QA

1. Cap nhat master board theo trang thai moi: frontend/schema pass, Rust gate blocked, corpus PDF can xac minh.
2. Sau khi Agent A/B chay Rust gate, tao bug report neu fail hoac dong Phase 0 neu pass.
3. Chua cho mo Phase 1 den khi `cargo check`, `npm run tauri:dev`, va corpus scanner co ket qua ro.

### Claude - Reserved Critical Review

Chi dung Claude sau khi Agent A/B da co ket qua Rust gate. Nhiem vu phu hop de tiet kiem chi phi:

1. Independent review kien truc Phase 0 truoc khi mo Phase 1.
2. Review data schema + DB init + migration risk.
3. Review security/supply-chain sau khi dependency da on dinh.

## 6. Gate policy cap nhat

Phase 0 chi duoc dong khi:

- `npm run build` PASS.
- `python python/catalog/verify_schema.py` PASS.
- Catalog scanner metadata PASS.
- `cargo check` PASS.
- `npm run tauri:dev` khoi dong app khong loi.
- Corpus `TaiLieu` co PDF va scanner metadata pass lai.
- Log runtime/build/test co trong `PhanMem/logs`.
- Report dieu phoi co trong `V2/03_bao_cao/04_tong_hop`.
