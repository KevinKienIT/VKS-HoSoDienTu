# NEXT ACTION - File Chi Duong Cho Agent

Ngay tao: 2026-04-25
Ngay cap nhat gan nhat: 2026-04-27 14:26 GMT+7
Sua boi agent: Roo Code
Muc dich: File duy nhat de bat ky agent nao doc vao la biet ngay viec can lam tiep theo. Cap nhat file nay sau moi task hoan thanh.

> QUY TAC: Moi agent hoan thanh task xong phai cap nhat file nay truoc khi ket thuc phien.

---

## ⛔ RANG BUOC NEN TANG — DOC TRUOC KHI LAM BAT CU GI

> **DAY LA UNG DUNG TAURI DESKTOP (.exe). KHONG PHAI WEB APP.**
>
> - **KHONG chay `npm run dev` de test chuc nang** — Tauri API khong hoat dong ngoai Tauri runtime.
> - **KHONG tao `dist/` hay deploy len server** — san pham la file `.exe` qua `npm run tauri build`.
> - **KHONG dung `localStorage`/`fetch` cho du lieu nghiep vu** — chi dung SQLite qua Tauri.
> - **Doc bat buoc**: `V2/05_tai_lieu_mo_ta/20260426_01_quyet_dinh_nen_tang_va_cach_chay.md`
> - **Doc bat buoc**: `AGENTS.md` → muc "VKS ECMS — RANG BUOC NEN TANG"

---

## HIEN TAI

| Muc | Gia tri |
|-----|---------|
| Phase hien tai | **Phase 3-5 implementation completed (theo execution order); tiep tuc OCR engine that** |
| Trang thai | **Tasks 13-33 DONE. Gate verify PASS** |
| Task tiep theo | **Phase tiep theo: OCR engine Python offline that (khong placeholder), cap nhat pages.ocr_text + quality/review loop** |
| Owner | Roo Code (implement) · Antigravity (review) · Codex (test) |
| Blocked by | Không |
| **🔴 EXECUTION ORDER** | `V2/04_case_dang_lam_viec/20260427_06_roo_code_execution_order.md` ← **ĐỌC ĐẦU TIÊN** |
| **MASTER TASK BOARD** | `V2/04_case_dang_lam_viec/20260427_05_master_100_tasks.md` |
| **CODE FLOW REVIEW** | `V2/03_bao_cao/03_fix/20260427_04_codex_flow_review_ai_offline_patch.md` |
| **UI CHANGELOG** | `V2/03_bao_cao/03_fix/20260427_05_ui_enterprise_redesign_changelog.md` |
| **RUNTIME/FUNCTION PATCH** | `V2/03_bao_cao/03_fix/20260427_06_codex_runtime_function_link_patch.md` |
| Doc bat buoc | `V2/05_tai_lieu_mo_ta/20260426_01_quyet_dinh_nen_tang_va_cach_chay.md` ← **NEN TANG** |

## TRANG THAI DA XAC THUC

- Agent A DB wiring: `main.rs` da co `mod db` va goi `db::init(&db_path)`.
- Agent B DB init: da sua `db::init()` de mo SQLite bang `rusqlite`, bat `foreign_keys`, va chay migration 001 that.
- Schema verify: PASS, 27 tables va 31 indexes.
- Catalog scanner: PASS. 2026-04-26 quet lai `TaiLieu` tim 136 PDF (68 trong `FileVuAnLonXon`, 68 trong `VU_AN_Le_Thanh_Cong_Dieu134`); corpus hien co OK.
- Frontend dependency: PASS, `npm install` thanh cong.
- Frontend build: PASS, `npm run build` thanh cong.
- Security audit npm: PASS, 0 vulnerabilities sau khi go `vite-plugin-tauri`, go `uuid` JS khong dung, nang Vite/plugin React.
- Rust/Tauri compile: PASS. `cargo`/`rustc` co tren PATH; `cargo check -j 1` tai `PhanMem/src-tauri` PASS 0 errors (con 46 warning `dead_code` trong schema constants, khong chan gate).
- Tauri dev launch: PASS. `npm run tauri:dev` chay Vite, compile backend, launch `target\debug\vks-ecms.exe`, va DB init log co `PRAGMA foreign_keys = ON`.
- Task T2 PDF-to-images: DONE, `python -m ocr.pdf_to_images --help` PASS.
- Task A1 Roo Code backend import/search: DONE, `import_folder` va `fts_search` da register trong `main.rs`; re-verify `cargo check -j 1` PASS va `npm run build` PASS ngay 2026-04-27.
- Task B1 Python OCR: DONE, `ocr_pipeline.py` và `summarizer.py` đã tạo; verify help commands PASS.
- Task C1 Frontend import/search: DONE, da co `importService.ts`, `searchService.ts`, va UI import/search fallback trong `App.tsx`.
- D1 Integration QA: PASS lai bo gate ngay 2026-04-27 01:57 GMT+7 (`cargo check -j 1`, `npm run build`, Python help, `npm run tauri:dev` launch log).
- Roo patch bo sung:
  - Sua `importService.ts` de map dung argument snake_case `folder_path` khi invoke `import_folder`.
  - OCR script `ocr_pipeline.py` doi sang lazy import dependencies de `--help` luon an toan khi thieu model/lib nặng.
  - Mo rong ket qua `fts_search` them `document_type`, `created_at`; frontend Search co filter theo loai va sort theo relevance/date/name.
- Codex review 2026-04-27:
  - UI fallback di dung huong nhung cac report DONE dang vuot qua thuc te E2E.
  - Import hien moi tao case/document/import_job; chua tach PDF thanh pages, chua chay OCR, chua nap OCR vao FTS.
  - Viewer OCR panel, Review Queue actions, confidence/review audit van la fallback.
  - AI Notebook offline Tier 1 da tich hop vao tab Notes cua Case Detail; doc notes/metadata/OCR trong SQLite va tra ve sources cho agent/KSV xem lai.
- Codex runtime/function patch 2026-04-27:
  - `npm run dev` da bi chan de khong mo browser preview sai huong; Tauri internal Vite dung `npm run dev:tauri-vite`.
  - Browser preview hien warning ro: khong test SQLite/import/OCR/search/review/AI ngoai Tauri runtime.
  - Them `get_page_ocr` command/service va wire OCR panel theo current page.
  - Them `update_document_status` command/service va wire nut Duyet/Tu choi/Sua trong Review Queue fallback.
  - NPM packages da len latest (`npm outdated --json` tra `{}`); Rust `tauri` 2.10.3, `lopdf` 0.40.0, `rusqlite` 0.32.1 moi nhat tuong thich voi `tauri-plugin-sql/sqlx`.
- Roo Code implementation/recheck 2026-04-27:
  - Da tao plan review truoc implement: `V2/03_bao_cao/03_fix/20260427_08_roo_plan_review_ui_map_code_flow.md` (checklist + UI map + code flow map).
  - Phase 3 done:
    - `get_page_ocr` tra OCR panel data that tu `pages` + `ocr_results` (dung `raw_text` schema).
    - Import flow tao placeholder OCR (`ocr_results`), tao review entry, va nap `fts_documents` khi import.
    - Viewer OCR panel da wire theo current page, hien engine/confidence/text.
  - Phase 4 done:
    - Them `review_cmd.rs` that: `list_review_queue`, `review_action`.
    - Review Queue UI da dung bang `review_queue` that (khong filter fallback tu documents).
    - Review actions ghi vao `audit_events`.
  - Phase 5 done:
    - Toolbar/polish cho DocumentViewerPage, DocumentViewer, DocumentListPage, SettingsPage.
    - Them `Breadcrumb` trong `common.tsx`.
  - Recheck sau fix bug:
    - `cargo check -j 1` PASS
    - `npm run build` PASS
    - `cargo test -j 1` PASS (4 tests)
    - `npm run tauri:dev` da launch runtime (terminal active)

## TASK TIEP THEO BAT BUOC

⚠️ **UU TIEN CAO NHAT: NOI DATA THAT CHO CAC MAN HINH FALLBACK**

1. **Phase B+ (Nang cap tiep OCR that, khong placeholder)**:
    - Rust/Tauri command goi Python OCR offline qua shell/plugin dung nen tang desktop.
    - Import PDF -> pages -> OCR text/confidence -> `ocr_results`/`pages.ocr_text` with real OCR payload.
    - Rebuild/sync FTS sau OCR batch.
2. **Notes/AI work product**:
    - Di chuyen notes tu `app_settings` sang work product/citation-aware schema, giu backward compatibility key `case_notes::<caseId>`.
    - Nang AI Notebook tu Tier 1 extractive len local LLM neu Ollama localhost co model offline.
3. **Sau khi OCR that chay duoc** tiep tuc E2E data-quality gates va manual review loop.

## CAP NHAT MOI NHAT (UI-REDESIGN IMPLEMENTED)

- `App.tsx` đã được tách về app shell + routes + sidebar đúng nhóm điều hướng chính.
- Đã tạo nhóm page components trong `src/components/pages/`:
  - `DashboardPage.tsx`
  - `CaseListPage.tsx`
  - `CaseDetailPage.tsx` (tabs: overview/documents/timeline/citations/dossier/notes)
  - `DocumentViewerPage.tsx`
  - `DocumentListPage.tsx`
  - `SearchPage.tsx`
  - `ReviewQueuePage.tsx`
  - `ImportJobPage.tsx`
  - `SettingsPage.tsx`
  - `common.tsx`
- Notes workflow đã bỏ `localStorage`, chuyển sang SQLite qua `set_app_setting/get_app_settings` bằng service mới `src/services/appSettingService.ts`.
- Search flow đã link được sang viewer route `/cases/:caseId/docs/:docId`.
- Header có global search và phím tắt `Ctrl+K`.
- Rust search DTO đã mở rộng thêm `case_id` để hỗ trợ điều hướng từ search/global search.
- Verify mới nhất:
  - `npm run build` PASS
  - `cargo check -j 1` PASS
  - `npm run tauri:dev` launch PASS
- Codex patch 2026-04-27:
  - Them `ai_cmd.rs`, `aiService.ts`, `AiNotebookPanel.tsx`.
  - Case Notes hien co AI Notebook offline canh ghi chu de agent/KSV xem lai source.
  - Verify: `cargo check -j 1` PASS; `npm run build` PASS.

## LICH SU CAP NHAT

| Ngay | Agent | Tu | Sang | Ghi chu |
|------|-------|----|------|---------|
| 2026-04-25 | Antigravity | Phase -1 done | Phase 0 task 0.1 | Tao file NEXT_ACTION, task board, prompt scaffold |
| 2026-04-25 | Agent C (Coordinator) | Phase 0 task 0.1 | Phase 0 gate verification + DB init coordination | Reconciled status A/B, updated board, ghi blockers |
| 2026-04-25 | Antigravity (B) | B verification #1 | B verification #2 done | Re-verify schema+scanner OK. Blocker: main.rs chua wire mod db |
| 2026-04-25 | Codex lead | Gate blocked cu | Frontend/schema pass, Rust gate blocked | Sua DB init stub, verify script, dependency conflict, TS strict, audit |
| 2026-04-25 | Codex lead | Agent reply scattered | Bat buoc response log chung | Them `20260425_01_agent_response_log_phase0.md`; agent thi cong append, master leader tong hop |
| 2026-04-26 | Agent L (Cline Leader) | Rust/corpus/Tauri blocked | Phase 0 PASS, ready for Phase 1 | Verified Rust toolchain on PATH, fixed target attr/file-lock workflow, `cargo check -j 1` PASS, scanner 136 PDF, `npm run tauri:dev` launch PASS |
| 2026-04-26 | Antigravity | Nham lan web/desktop | Thong nhat Tauri desktop | Tao `20260426_01_quyet_dinh_nen_tang_va_cach_chay.md`. Chot: Tauri .exe, khong phai web app. `npm run dev` chi dung de xem UI, khong test chuc nang |
| 2026-04-27 | Codex | Phase 1 board stale | Roo Code Leader order ready | Tao `20260427_01_roo_code_master_orchestrator_order.md`; cap nhat next task thanh B1+C1, D1 blocked; Roo se dieu phoi OpenClaw/Codex/Antigravity den het cac phase |
| 2026-04-27 | Roo Code Leader | Status tu khai DONE nhung con mismatch | Re-verified + patched + closed M0 | Sua `importService` arg map, lam an toan lazy import OCR help, mo rong FTS search DTO + Search UI filter/sort, chay lai D1 gates PASS va cap nhat board/log |
| 2026-04-27 | Roo Code Leader | UI-REDESIGN IN_PROGRESS | UI-REDESIGN fallback DONE + gate PASS | Tu implement full page split + routing/sidebar/header search + notes SQLite via app settings, verify build/check/tauri launch PASS |
| 2026-04-27 | Codex | UI fallback DONE nhung E2E chua that | Flow review + AI offline Tier 1 | Them report `20260427_04_codex_flow_review_ai_offline_patch.md`; tich hop AI Notebook offline vao Case Notes; verify cargo/build PASS |
| 2026-04-27 | Codex | Browser preview de bi chay sai + function hở | Runtime guard + function link patch | Chan `npm run dev`, them warning browser, wire `get_page_ocr`, wire review status actions, nang dependencies, verify cargo/build PASS |
| 2026-04-27 | Roo Code | Task 13+ pending | Tasks 13-33 complete + recheck gates | Tao plan review/map, hoan tat Phase 3/4/5 (OCR panel + review_queue that + UI polish), fix schema mismatch (`raw_text`), verify `cargo check`, `npm run build`, `cargo test`, `tauri dev` |
