# agents.md

Behavioral guidelines to reduce common LLM coding mistakes. Merge with project-specific instructions as needed.
Derived from Andrej Karpathy's observations on LLM coding pitfalls.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks, use judgment.

---

## ⛔ VKS ECMS — RÀNG BUỘC NỀN TẢNG

> **ỨNG DỤNG NÀY LÀ TAURI DESKTOP (.exe). KHÔNG PHẢI WEB APP.**
>
> - Chạy `npm run tauri dev` để phát triển, `npm run tauri build` để build sản phẩm.
> - **KHÔNG** chạy `npm run dev` + browser để test chức năng (Tauri API không hoạt động).
> - **KHÔNG** tạo `dist/` để deploy, **KHÔNG** dùng `localStorage`/`fetch` cho dữ liệu nghiệp vụ.
> - **ĐỌC BẮT BUỘC**: `V2/05_tai_lieu_mo_ta/20260426_01_quyet_dinh_nen_tang_va_cach_chay.md`

---

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them - don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

## 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask yourself: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it - don't delete it.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

The test: Every changed line should trace directly to the user's request.

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:
- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

## 5. Supply-Chain Sanity Check

**Don't trust AI-generated dependencies, URLs, or setup steps at a glance.**

When AI suggests code, packages, repositories, installers, endpoints, or download links:
- Skim them before accepting.
- Pay extra attention to new dependencies, unusual package names, postinstall/preinstall scripts, external URLs, and opaque setup commands.
- If something looks unfamiliar or unnecessary, stop and flag it.
- Prefer explicit provenance over convenience.

The test: "Would I be comfortable letting this dependency or URL into a regulated codebase without a second look?" If no, review it first.

---

**These guidelines are working if:** fewer unnecessary changes in diffs, fewer rewrites due to overcomplication, and clarifying questions come before implementation rather than after mistakes.
